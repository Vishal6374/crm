// Simple test script to verify database connections
import { createClient } from '@supabase/supabase-js';
import dotenv from 'dotenv';

// Load environment variables
dotenv.config();

const SUPABASE_URL = process.env.VITE_SUPABASE_URL;
const SUPABASE_PUBLISHABLE_KEY = process.env.VITE_SUPABASE_PUBLISHABLE_KEY;

if (!SUPABASE_URL || !SUPABASE_PUBLISHABLE_KEY) {
  console.error('❌ Environment variables not found. Please check your .env file.');
  process.exit(1);
}

const supabase = createClient(SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY);

async function testDatabaseConnection() {
  console.log('🧪 Testing database connection...\n');

  try {
    // Test 1: Check if we can connect to Supabase
    console.log('1. Testing basic connection...');
    const { data: healthCheck, error: healthError } = await supabase
      .from('leads')
      .select('count', { count: 'exact', head: true });

    if (healthError) {
      console.error('❌ Connection failed:', healthError.message);
      return;
    }
    console.log('✅ Basic connection successful');

    // Test 2: Test leads CRUD operations
    console.log('\n2. Testing leads CRUD operations...');

    // Create a test lead
    const testLead = {
      company_name: 'Test Company',
      contact_name: 'Test Contact',
      email: 'test@example.com',
      phone: '+1234567890',
      status: 'new',
      source: 'website'
    };

    console.log('   Creating test lead...');
    const { data: createdLead, error: createError } = await supabase
      .from('leads')
      .insert(testLead)
      .select()
      .single();

    if (createError) {
      console.error('❌ Create failed:', createError.message);
      return;
    }
    console.log('✅ Lead created successfully:', createdLead.id);

    // Read the lead
    console.log('   Reading test lead...');
    const { data: readLead, error: readError } = await supabase
      .from('leads')
      .select('*')
      .eq('id', createdLead.id)
      .single();

    if (readError) {
      console.error('❌ Read failed:', readError.message);
    } else {
      console.log('✅ Lead read successfully');
    }

    // Update the lead
    console.log('   Updating test lead...');
    const { data: updatedLead, error: updateError } = await supabase
      .from('leads')
      .update({ status: 'contacted' })
      .eq('id', createdLead.id)
      .select()
      .single();

    if (updateError) {
      console.error('❌ Update failed:', updateError.message);
    } else {
      console.log('✅ Lead updated successfully');
    }

    // Delete the test lead
    console.log('   Deleting test lead...');
    const { error: deleteError } = await supabase
      .from('leads')
      .delete()
      .eq('id', createdLead.id);

    if (deleteError) {
      console.error('❌ Delete failed:', deleteError.message);
    } else {
      console.log('✅ Lead deleted successfully');
    }

    // Test 3: Test other tables
    console.log('\n3. Testing other tables...');

    const tables = ['companies', 'contacts', 'employees', 'tasks'];
    for (const table of tables) {
      try {
        const { error } = await supabase
          .from(table)
          .select('count', { count: 'exact', head: true });

        if (error) {
          console.log(`❌ ${table}: ${error.message}`);
        } else {
          console.log(`✅ ${table}: accessible`);
        }
      } catch (err) {
        console.log(`❌ ${table}: ${err.message}`);
      }
    }

    console.log('\n🎉 All tests completed!');

  } catch (error) {
    console.error('❌ Test failed:', error.message);
  }
}

testDatabaseConnection();
