const { Sequelize } = require('sequelize');
const config = require('./config/config.js')['development'];

console.log('🧪 Testing MySQL database connection...\n');

// Create Sequelize instance
const sequelize = new Sequelize(config.database, config.username, config.password, {
  host: config.host,
  port: config.port,
  dialect: 'mysql',
  logging: false
});

async function testDatabaseConnection() {
  try {
    // Test 1: Basic connection
    console.log('1. Testing basic connection...');
    await sequelize.authenticate();
    console.log('✅ Database connection successful');

    // Test 2: Check if database exists
    console.log('\n2. Checking database existence...');
    const [results] = await sequelize.query(`SHOW DATABASES LIKE '${config.database}'`);
    if (results.length > 0) {
      console.log(`✅ Database '${config.database}' exists`);
    } else {
      console.log(`❌ Database '${config.database}' does not exist`);
      console.log('   Please create the database in phpMyAdmin first');
      return;
    }

    // Test 3: Load models
    console.log('\n3. Loading Sequelize models...');
    const db = require('./models');
    console.log('✅ Models loaded successfully');

    // Test 4: Check model associations
    console.log('\n4. Testing model associations...');
    const models = Object.keys(db);
    console.log(`   Found ${models.length} models: ${models.join(', ')}`);

    // Test specific associations
    if (db.User && db.UserRole) {
      console.log('✅ User-UserRole association exists');
    }
    if (db.Company && db.Contact) {
      console.log('✅ Company-Contact association exists');
    }
    if (db.Employee && db.Attendance) {
      console.log('✅ Employee-Attendance association exists');
    }

    // Test 5: Check migrations
    console.log('\n5. Checking migrations...');
    const fs = require('fs');
    const path = require('path');
    const migrationsPath = path.join(__dirname, 'migrations');
    const migrations = fs.readdirSync(migrationsPath).filter(file => file.endsWith('.js'));
    console.log(`✅ Found ${migrations.length} migration files`);

    // Test 6: Check seeders
    console.log('\n6. Checking seeders...');
    const seedersPath = path.join(__dirname, 'seeders');
    const seeders = fs.readdirSync(seedersPath).filter(file => file.endsWith('.js'));
    console.log(`✅ Found ${seeders.length} seeder files`);

    console.log('\n🎉 All basic tests passed!');
    console.log('\n📋 Next steps:');
    console.log('1. Run migrations: npm run migrate');
    console.log('2. Run seeders: npm run seed');
    console.log('3. Start server: npm run dev');

  } catch (error) {
    console.error('❌ Test failed:', error.message);
    if (error.original) {
      console.error('   Original error:', error.original.message);
    }
  } finally {
    await sequelize.close();
  }
}

testDatabaseConnection();
