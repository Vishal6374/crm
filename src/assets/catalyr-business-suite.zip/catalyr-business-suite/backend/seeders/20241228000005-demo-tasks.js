'use strict';

module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.bulkInsert('Tasks', [
      {
        id: '660e8400-e29b-41d4-a716-446655440001',
        title: 'Setup development environment',
        description: 'Install and configure all necessary development tools and dependencies',
        status: 'completed',
        priority: 'high',
        dueDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), // 7 days from now
        assignedTo: '550e8400-e29b-41d4-a716-446655440000', // admin user
        createdBy: '550e8400-e29b-41d4-a716-446655440000', // admin user
        relatedTo: 'deal',
        relatedId: '550e8400-e29b-41d4-a716-446655440010', // first deal
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: '660e8400-e29b-41d4-a716-446655440002',
        title: 'Review contract terms',
        description: 'Review and negotiate contract terms with TechCorp Solutions',
        status: 'in_progress',
        priority: 'high',
        dueDate: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000), // 3 days from now
        assignedTo: '550e8400-e29b-41d4-a716-446655440000', // admin user
        createdBy: '550e8400-e29b-41d4-a716-446655440000', // admin user
        relatedTo: 'deal',
        relatedId: '550e8400-e29b-41d4-a716-446655440010', // first deal
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: '660e8400-e29b-41d4-a716-446655440003',
        title: 'Prepare project proposal',
        description: 'Create detailed project proposal for Global Manufacturing Inc',
        status: 'pending',
        priority: 'medium',
        dueDate: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000), // 14 days from now
        assignedTo: '550e8400-e29b-41d4-a716-446655440000', // admin user
        createdBy: '550e8400-e29b-41d4-a716-446655440000', // admin user
        relatedTo: 'lead',
        relatedId: '550e8400-e29b-41d4-a716-446655440005', // first lead
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: '660e8400-e29b-41d4-a716-446655440004',
        title: 'Follow up with RetailMax',
        description: 'Schedule follow-up meeting with RetailMax Stores management',
        status: 'pending',
        priority: 'low',
        dueDate: new Date(Date.now() + 21 * 24 * 60 * 60 * 1000), // 21 days from now
        assignedTo: '550e8400-e29b-41d4-a716-446655440000', // admin user
        createdBy: '550e8400-e29b-41d4-a716-446655440000', // admin user
        relatedTo: 'company',
        relatedId: '550e8400-e29b-41d4-a716-446655440003', // RetailMax company
        createdAt: new Date(),
        updatedAt: new Date()
      }
    ], {});
  },

  async down(queryInterface, Sequelize) {
    await queryInterface.bulkDelete('Tasks', null, {});
  }
};
