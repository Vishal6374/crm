'use strict';

module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.createTable('Employees', {
      id: {
        type: Sequelize.UUID,
        defaultValue: Sequelize.UUIDV4,
        primaryKey: true,
        allowNull: false
      },
      employeeCode: {
        type: Sequelize.STRING,
        unique: true,
        allowNull: false
      },
      fullName: {
        type: Sequelize.STRING,
        allowNull: false
      },
      email: {
        type: Sequelize.STRING,
        unique: true,
        allowNull: false,
        validate: {
          isEmail: true
        }
      },
      phone: {
        type: Sequelize.STRING
      },
      mobile: {
        type: Sequelize.STRING
      },
      dateOfBirth: {
        type: Sequelize.DATEONLY
      },
      gender: {
        type: Sequelize.STRING,
        validate: {
          isIn: [['male', 'female', 'other']]
        }
      },
      address: {
        type: Sequelize.TEXT
      },
      city: {
        type: Sequelize.STRING
      },
      state: {
        type: Sequelize.STRING
      },
      country: {
        type: Sequelize.STRING
      },
      pincode: {
        type: Sequelize.STRING
      },
      designation: {
        type: Sequelize.STRING
      },
      department: {
        type: Sequelize.STRING
      },
      joiningDate: {
        type: Sequelize.DATEONLY,
        allowNull: false
      },
      salary: {
        type: Sequelize.FLOAT
      },
      status: {
        type: Sequelize.STRING,
        defaultValue: 'active',
        validate: {
          isIn: [['active', 'inactive', 'terminated', 'on_leave']]
        }
      },
      emergencyContactName: {
        type: Sequelize.STRING
      },
      emergencyContactPhone: {
        type: Sequelize.STRING
      },
      bankAccountNumber: {
        type: Sequelize.STRING
      },
      bankName: {
        type: Sequelize.STRING
      },
      ifscCode: {
        type: Sequelize.STRING
      },
      panNumber: {
        type: Sequelize.STRING
      },
      aadharNumber: {
        type: Sequelize.STRING
      },
      userId: {
        type: Sequelize.UUID,
        references: {
          model: 'Users',
          key: 'id'
        },
        onUpdate: 'CASCADE',
        onDelete: 'SET NULL'
      },
      managerId: {
        type: Sequelize.UUID,
        references: {
          model: 'Employees',
          key: 'id'
        },
        onUpdate: 'CASCADE',
        onDelete: 'SET NULL'
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });

    // Add indexes
    await queryInterface.addIndex('Employees', ['employeeCode'], { unique: true });
    await queryInterface.addIndex('Employees', ['email'], { unique: true });
    await queryInterface.addIndex('Employees', ['status']);
    await queryInterface.addIndex('Employees', ['department']);
    await queryInterface.addIndex('Employees', ['designation']);
    await queryInterface.addIndex('Employees', ['userId']);
    await queryInterface.addIndex('Employees', ['managerId']);
    await queryInterface.addIndex('Employees', ['joiningDate']);
  },

  async down(queryInterface, Sequelize) {
    await queryInterface.dropTable('Employees');
  }
};
