module.exports = (sequelize, DataTypes) => {
  const Company = sequelize.define("Company", {
    id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true,
    },
    name: {
      type: DataTypes.STRING,
      allowNull: false
    },
    industry: {
      type: DataTypes.STRING
    },
    website: {
      type: DataTypes.STRING,
      validate: {
        isUrl: true
      }
    },
    phone: {
      type: DataTypes.STRING
    },
    email: {
      type: DataTypes.STRING,
      validate: {
        isEmail: true
      }
    },
    city: {
      type: DataTypes.STRING
    },
    country: {
      type: DataTypes.STRING
    },
    address: {
      type: DataTypes.TEXT
    },
    notes: {
      type: DataTypes.TEXT
    },
    createdBy: {
      type: DataTypes.UUID,
      allowNull: false,
      references: {
        model: 'Users',
        key: 'id'
      }
    }
  }, {
    tableName: 'companies',
    timestamps: true,
    indexes: [
      {
        fields: ['name']
      },
      {
        fields: ['industry']
      },
      {
        fields: ['createdBy']
      }
    ]
  });

  Company.associate = function(models) {
    Company.belongsTo(models.User, { foreignKey: 'createdBy', as: 'creator' });
    Company.hasMany(models.Contact, { foreignKey: 'companyId' });
    Company.hasMany(models.Deal, { foreignKey: 'companyId' });
  };

  return Company;
};
