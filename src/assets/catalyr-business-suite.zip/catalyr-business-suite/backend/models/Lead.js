module.exports = (sequelize, DataTypes) => {
  const Lead = sequelize.define("Lead", {
    id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true,
    },
    companyName: {
      type: DataTypes.STRING,
      allowNull: false
    },
    contactName: {
      type: DataTypes.STRING
    },
    email: {
      type: DataTypes.STRING,
      validate: {
        isEmail: true
      }
    },
    phone: {
      type: DataTypes.STRING
    },
    source: {
      type: DataTypes.STRING,
      defaultValue: 'website'
    },
    status: {
      type: DataTypes.STRING,
      defaultValue: 'new',
      validate: {
        isIn: [['new', 'contacted', 'qualified', 'proposal', 'negotiation', 'won', 'lost']]
      }
    },
    notes: {
      type: DataTypes.TEXT
    },
    value: {
      type: DataTypes.FLOAT
    },
    expectedCloseDate: {
      type: DataTypes.DATE
    },
    assignedTo: {
      type: DataTypes.UUID,
      references: {
        model: 'Users',
        key: 'id'
      }
    },
    createdBy: {
      type: DataTypes.UUID,
      allowNull: false,
      references: {
        model: 'Users',
        key: 'id'
      }
    }
  }, {
    timestamps: true,
    indexes: [
      {
        fields: ['status']
      },
      {
        fields: ['assignedTo']
      },
      {
        fields: ['createdBy']
      }
    ]
  });

  Lead.associate = function(models) {
    Lead.belongsTo(models.User, { foreignKey: 'assignedTo', as: 'assignedUser' });
    Lead.belongsTo(models.User, { foreignKey: 'createdBy', as: 'creator' });
    Lead.hasMany(models.Deal, { foreignKey: 'leadId' });
  };

  return Lead;
};
