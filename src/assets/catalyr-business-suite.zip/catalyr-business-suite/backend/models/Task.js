module.exports = (sequelize, DataTypes) => {
  const Task = sequelize.define("Task", {
    id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true,
    },
    title: {
      type: DataTypes.STRING,
      allowNull: false
    },
    description: {
      type: DataTypes.TEXT
    },
    status: {
      type: DataTypes.STRING,
      defaultValue: 'pending',
      validate: {
        isIn: [['pending', 'in_progress', 'completed', 'cancelled']]
      }
    },
    priority: {
      type: DataTypes.STRING,
      defaultValue: 'medium',
      validate: {
        isIn: [['low', 'medium', 'high', 'urgent']]
      }
    },
    dueDate: {
      type: DataTypes.DATE
    },
    completedAt: {
      type: DataTypes.DATE
    },
    assignedTo: {
      type: DataTypes.UUID,
      references: {
        model: 'Users',
        key: 'id'
      }
    },
    createdBy: {
      type: DataTypes.UUID,
      allowNull: false,
      references: {
        model: 'Users',
        key: 'id'
      }
    },
    relatedTo: {
      type: DataTypes.STRING, // 'deal', 'contact', 'company', 'lead'
      allowNull: true
    },
    relatedId: {
      type: DataTypes.UUID,
      allowNull: true
    }
  }, {
    timestamps: true,
    indexes: [
      {
        fields: ['status']
      },
      {
        fields: ['priority']
      },
      {
        fields: ['assignedTo']
      },
      {
        fields: ['createdBy']
      },
      {
        fields: ['dueDate']
      },
      {
        fields: ['relatedTo', 'relatedId']
      }
    ]
  });

  Task.associate = function(models) {
    Task.belongsTo(models.User, { foreignKey: 'assignedTo', as: 'assignee' });
    Task.belongsTo(models.User, { foreignKey: 'createdBy', as: 'creator' });
  };

  return Task;
};
