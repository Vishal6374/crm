module.exports = (sequelize, DataTypes) => {
  const Attendance = sequelize.define("Attendance", {
    id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true,
    },
    employeeId: {
      type: DataTypes.UUID,
      allowNull: false,
      references: {
        model: 'Employees',
        key: 'id'
      }
    },
    date: {
      type: DataTypes.DATEONLY,
      allowNull: false
    },
    checkIn: {
      type: DataTypes.DATE
    },
    checkOut: {
      type: DataTypes.DATE
    },
    status: {
      type: DataTypes.STRING,
      defaultValue: 'present',
      validate: {
        isIn: [['present', 'absent', 'late', 'half_day', 'on_leave']]
      }
    },
    notes: {
      type: DataTypes.TEXT
    },
    workingHours: {
      type: DataTypes.FLOAT,
      allowNull: true
    },
    breakHours: {
      type: DataTypes.FLOAT,
      defaultValue: 0
    },
    overtimeHours: {
      type: DataTypes.FLOAT,
      defaultValue: 0
    },
    location: {
      type: DataTypes.STRING
    },
    ipAddress: {
      type: DataTypes.STRING
    }
  }, {
    timestamps: true,
    indexes: [
      {
        unique: true,
        fields: ['employeeId', 'date']
      },
      {
        fields: ['employeeId']
      },
      {
        fields: ['date']
      },
      {
        fields: ['status']
      }
    ]
  });

  Attendance.associate = function(models) {
    Attendance.belongsTo(models.Employee, { foreignKey: 'employeeId' });
  };

  return Attendance;
};
