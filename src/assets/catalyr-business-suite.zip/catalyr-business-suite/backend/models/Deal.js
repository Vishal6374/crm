module.exports = (sequelize, DataTypes) => {
  const Deal = sequelize.define("Deal", {
    id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true,
    },
    title: {
      type: DataTypes.STRING,
      allowNull: false
    },
    value: {
      type: DataTypes.FLOAT,
      allowNull: false
    },
    currency: {
      type: DataTypes.STRING,
      defaultValue: 'INR'
    },
    stage: {
      type: DataTypes.STRING,
      defaultValue: 'prospect',
      validate: {
        isIn: [['prospect', 'qualification', 'proposal', 'negotiation', 'closed_won', 'closed_lost']]
      }
    },
    probability: {
      type: DataTypes.INTEGER,
      defaultValue: 0,
      validate: {
        min: 0,
        max: 100
      }
    },
    expectedCloseDate: {
      type: DataTypes.DATEONLY
    },
    actualCloseDate: {
      type: DataTypes.DATEONLY
    },
    description: {
      type: DataTypes.TEXT
    },
    notes: {
      type: DataTypes.TEXT
    },
    source: {
      type: DataTypes.STRING
    },
    priority: {
      type: DataTypes.STRING,
      defaultValue: 'medium',
      validate: {
        isIn: [['low', 'medium', 'high', 'urgent']]
      }
    },
    companyId: {
      type: DataTypes.UUID,
      allowNull: false,
      references: {
        model: 'Companies',
        key: 'id'
      }
    },
    contactId: {
      type: DataTypes.UUID,
      references: {
        model: 'Contacts',
        key: 'id'
      }
    },
    assignedTo: {
      type: DataTypes.UUID,
      references: {
        model: 'Users',
        key: 'id'
      }
    },
    createdBy: {
      type: DataTypes.UUID,
      allowNull: false,
      references: {
        model: 'Users',
        key: 'id'
      }
    }
  }, {
    timestamps: true,
    indexes: [
      {
        fields: ['companyId']
      },
      {
        fields: ['contactId']
      },
      {
        fields: ['assignedTo']
      },
      {
        fields: ['createdBy']
      },
      {
        fields: ['stage']
      },
      {
        fields: ['priority']
      },
      {
        fields: ['expectedCloseDate']
      },
      {
        fields: ['value']
      }
    ]
  });

  Deal.associate = function(models) {
    Deal.belongsTo(models.Company, { foreignKey: 'companyId' });
    Deal.belongsTo(models.Contact, { foreignKey: 'contactId' });
    Deal.belongsTo(models.User, { foreignKey: 'assignedTo', as: 'assignee' });
    Deal.belongsTo(models.User, { foreignKey: 'createdBy', as: 'creator' });
  };

  return Deal;
};
