module.exports = (sequelize, DataTypes) => {
  const LeaveRequest = sequelize.define("LeaveRequest", {
    id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true,
    },
    leaveType: {
      type: DataTypes.STRING,
      allowNull: false,
      validate: {
        isIn: [['annual', 'sick', 'casual', 'maternity', 'paternity', 'emergency', 'unpaid']]
      }
    },
    startDate: {
      type: DataTypes.DATEONLY,
      allowNull: false
    },
    endDate: {
      type: DataTypes.DATEONLY,
      allowNull: false
    },
    totalDays: {
      type: DataTypes.FLOAT,
      allowNull: false
    },
    reason: {
      type: DataTypes.TEXT,
      allowNull: false
    },
    status: {
      type: DataTypes.STRING,
      defaultValue: 'pending',
      validate: {
        isIn: [['pending', 'approved', 'rejected', 'cancelled']]
      }
    },
    approvedBy: {
      type: DataTypes.UUID,
      references: {
        model: 'Users',
        key: 'id'
      }
    },
    approvedAt: {
      type: DataTypes.DATE
    },
    rejectionReason: {
      type: DataTypes.TEXT
    },
    employeeId: {
      type: DataTypes.UUID,
      allowNull: false,
      references: {
        model: 'Employees',
        key: 'id'
      }
    },
    submittedBy: {
      type: DataTypes.UUID,
      allowNull: false,
      references: {
        model: 'Users',
        key: 'id'
      }
    }
  }, {
    timestamps: true,
    indexes: [
      {
        fields: ['employeeId']
      },
      {
        fields: ['status']
      },
      {
        fields: ['leaveType']
      },
      {
        fields: ['startDate']
      },
      {
        fields: ['endDate']
      },
      {
        fields: ['approvedBy']
      },
      {
        fields: ['submittedBy']
      }
    ]
  });

  LeaveRequest.associate = function(models) {
    LeaveRequest.belongsTo(models.Employee, { foreignKey: 'employeeId' });
    LeaveRequest.belongsTo(models.User, { foreignKey: 'submittedBy', as: 'submitter' });
    LeaveRequest.belongsTo(models.User, { foreignKey: 'approvedBy', as: 'approver' });
  };

  return LeaveRequest;
};
