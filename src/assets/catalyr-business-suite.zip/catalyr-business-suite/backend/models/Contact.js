module.exports = (sequelize, DataTypes) => {
  const Contact = sequelize.define("Contact", {
    id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true,
    },
    firstName: {
      type: DataTypes.STRING,
      allowNull: false
    },
    lastName: {
      type: DataTypes.STRING
    },
    email: {
      type: DataTypes.STRING,
      validate: {
        isEmail: true
      }
    },
    phone: {
      type: DataTypes.STRING
    },
    mobile: {
      type: DataTypes.STRING
    },
    position: {
      type: DataTypes.STRING
    },
    department: {
      type: DataTypes.STRING
    },
    linkedin: {
      type: DataTypes.STRING,
      validate: {
        isUrl: true
      }
    },
    twitter: {
      type: DataTypes.STRING
    },
    notes: {
      type: DataTypes.TEXT
    },
    companyId: {
      type: DataTypes.UUID,
      references: {
        model: 'Companies',
        key: 'id'
      }
    },
    createdBy: {
      type: DataTypes.UUID,
      allowNull: false,
      references: {
        model: 'Users',
        key: 'id'
      }
    }
  }, {
    timestamps: true,
    indexes: [
      {
        fields: ['companyId']
      },
      {
        fields: ['email']
      },
      {
        fields: ['createdBy']
      }
    ]
  });

  Contact.associate = function(models) {
    Contact.belongsTo(models.Company, { foreignKey: 'companyId' });
    Contact.belongsTo(models.User, { foreignKey: 'createdBy', as: 'creator' });
    Contact.hasMany(models.Deal, { foreignKey: 'contactId' });
  };

  return Contact;
};
