module.exports = (sequelize, DataTypes) => {
  const Employee = sequelize.define("Employee", {
    id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true,
    },
    employeeCode: {
      type: DataTypes.STRING,
      unique: true,
      allowNull: false
    },
    fullName: {
      type: DataTypes.STRING,
      allowNull: false
    },
    email: {
      type: DataTypes.STRING,
      unique: true,
      allowNull: false,
      validate: {
        isEmail: true
      }
    },
    phone: {
      type: DataTypes.STRING
    },
    mobile: {
      type: DataTypes.STRING
    },
    dateOfBirth: {
      type: DataTypes.DATEONLY
    },
    gender: {
      type: DataTypes.STRING,
      validate: {
        isIn: [['male', 'female', 'other']]
      }
    },
    address: {
      type: DataTypes.TEXT
    },
    city: {
      type: DataTypes.STRING
    },
    state: {
      type: DataTypes.STRING
    },
    country: {
      type: DataTypes.STRING
    },
    pincode: {
      type: DataTypes.STRING
    },
    designation: {
      type: DataTypes.STRING
    },
    department: {
      type: DataTypes.STRING
    },
    joiningDate: {
      type: DataTypes.DATEONLY,
      allowNull: false
    },
    salary: {
      type: DataTypes.FLOAT
    },
    status: {
      type: DataTypes.STRING,
      defaultValue: 'active',
      validate: {
        isIn: [['active', 'inactive', 'terminated', 'on_leave']]
      }
    },
    emergencyContactName: {
      type: DataTypes.STRING
    },
    emergencyContactPhone: {
      type: DataTypes.STRING
    },
    bankAccountNumber: {
      type: DataTypes.STRING
    },
    bankName: {
      type: DataTypes.STRING
    },
    ifscCode: {
      type: DataTypes.STRING
    },
    panNumber: {
      type: DataTypes.STRING
    },
    aadharNumber: {
      type: DataTypes.STRING
    },
    userId: {
      type: DataTypes.UUID,
      references: {
        model: 'Users',
        key: 'id'
      }
    },
    managerId: {
      type: DataTypes.UUID,
      references: {
        model: 'Employees',
        key: 'id'
      }
    }
  }, {
    timestamps: true,
    indexes: [
      {
        unique: true,
        fields: ['employeeCode']
      },
      {
        unique: true,
        fields: ['email']
      },
      {
        fields: ['status']
      },
      {
        fields: ['department']
      },
      {
        fields: ['designation']
      },
      {
        fields: ['userId']
      },
      {
        fields: ['managerId']
      },
      {
        fields: ['joiningDate']
      }
    ]
  });

  Employee.associate = function(models) {
    Employee.belongsTo(models.User, { foreignKey: 'userId' });
    Employee.belongsTo(models.Employee, { foreignKey: 'managerId', as: 'manager' });
    Employee.hasMany(models.Employee, { foreignKey: 'managerId', as: 'subordinates' });
    Employee.hasMany(models.Attendance, { foreignKey: 'employeeId' });
    Employee.hasMany(models.LeaveRequest, { foreignKey: 'employeeId' });
    Employee.hasMany(models.Payroll, { foreignKey: 'employeeId' });
  };

  return Employee;
};
