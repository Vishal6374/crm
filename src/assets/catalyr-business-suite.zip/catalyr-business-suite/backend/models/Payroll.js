module.exports = (sequelize, DataTypes) => {
  const Payroll = sequelize.define("Payroll", {
    id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true,
    },
    month: {
      type: DataTypes.INTEGER,
      allowNull: false,
      validate: {
        min: 1,
        max: 12
      }
    },
    year: {
      type: DataTypes.INTEGER,
      allowNull: false,
      validate: {
        min: 2020,
        max: 2050
      }
    },
    basicSalary: {
      type: DataTypes.FLOAT,
      allowNull: false
    },
    hra: {
      type: DataTypes.FLOAT,
      defaultValue: 0
    },
    conveyance: {
      type: DataTypes.FLOAT,
      defaultValue: 0
    },
    medical: {
      type: DataTypes.FLOAT,
      defaultValue: 0
    },
    lta: {
      type: DataTypes.FLOAT,
      defaultValue: 0
    },
    otherAllowances: {
      type: DataTypes.FLOAT,
      defaultValue: 0
    },
    deductions: {
      type: DataTypes.FLOAT,
      defaultValue: 0
    },
    providentFund: {
      type: DataTypes.FLOAT,
      defaultValue: 0
    },
    professionalTax: {
      type: DataTypes.FLOAT,
      defaultValue: 0
    },
    incomeTax: {
      type: DataTypes.FLOAT,
      defaultValue: 0
    },
    otherDeductions: {
      type: DataTypes.FLOAT,
      defaultValue: 0
    },
    bonus: {
      type: DataTypes.FLOAT,
      defaultValue: 0
    },
    overtime: {
      type: DataTypes.FLOAT,
      defaultValue: 0
    },
    grossSalary: {
      type: DataTypes.FLOAT,
      allowNull: false
    },
    netSalary: {
      type: DataTypes.FLOAT,
      allowNull: false
    },
    status: {
      type: DataTypes.STRING,
      defaultValue: 'pending',
      validate: {
        isIn: [['pending', 'processed', 'paid', 'cancelled']]
      }
    },
    paymentDate: {
      type: DataTypes.DATE
    },
    employeeId: {
      type: DataTypes.UUID,
      allowNull: false,
      references: {
        model: 'Employees',
        key: 'id'
      }
    },
    processedBy: {
      type: DataTypes.UUID,
      references: {
        model: 'Users',
        key: 'id'
      }
    }
  }, {
    timestamps: true,
    indexes: [
      {
        unique: true,
        fields: ['employeeId', 'month', 'year']
      },
      {
        fields: ['employeeId']
      },
      {
        fields: ['status']
      },
      {
        fields: ['month', 'year']
      },
      {
        fields: ['processedBy']
      }
    ]
  });

  Payroll.associate = function(models) {
    Payroll.belongsTo(models.Employee, { foreignKey: 'employeeId' });
    Payroll.belongsTo(models.User, { foreignKey: 'processedBy', as: 'processor' });
  };

  return Payroll;
};
