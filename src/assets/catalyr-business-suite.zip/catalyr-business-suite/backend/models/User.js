module.exports = (sequelize, DataTypes) => {
  const User = sequelize.define("User", {
    id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true,
    },
    email: {
      type: DataTypes.STRING,
      unique: true,
      allowNull: false,
      validate: {
        isEmail: true
      }
    },
    password: {
      type: DataTypes.STRING,
      allowNull: false
    },
    fullName: {
      type: DataTypes.STRING,
      allowNull: false
    },
    isActive: {
      type: DataTypes.BOOLEAN,
      defaultValue: true
    },
    lastLogin: {
      type: DataTypes.DATE
    }
  }, {
    timestamps: true,
    indexes: [
      {
        unique: true,
        fields: ['email']
      }
    ]
  });

  User.associate = function(models) {
    User.hasMany(models.UserRole, { foreignKey: 'userId', as: 'roles' });
    User.hasMany(models.Task, { foreignKey: 'assignedTo', as: 'assignedTasks' });
    User.hasMany(models.Task, { foreignKey: 'createdBy', as: 'createdTasks' });
    User.hasMany(models.Employee, { foreignKey: 'userId' });
    User.hasMany(models.ActivityLog, { foreignKey: 'userId' });
  };

  return User;
};
