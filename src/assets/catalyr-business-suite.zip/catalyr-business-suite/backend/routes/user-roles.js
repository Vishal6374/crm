const express = require('express');
const router = express.Router();
const { UserRole } = require('../models');

// Get all user roles
router.get('/', async (req, res) => {
  try {
    const userRoles = await UserRole.findAll({
      include: [{ model: require('../models').User, as: 'user' }]
    });
    res.json(userRoles);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get user role by id
router.get('/:id', async (req, res) => {
  try {
    const userRole = await UserRole.findByPk(req.params.id, {
      include: [{ model: require('../models').User, as: 'user' }]
    });
    if (!userRole) {
      return res.status(404).json({ error: 'User role not found' });
    }
    res.json(userRole);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Create user role
router.post('/', async (req, res) => {
  try {
    const userRole = await UserRole.create(req.body);
    res.status(201).json(userRole);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// Update user role
router.put('/:id', async (req, res) => {
  try {
    const [updated] = await UserRole.update(req.body, {
      where: { id: req.params.id }
    });
    if (!updated) {
      return res.status(404).json({ error: 'User role not found' });
    }
    const userRole = await UserRole.findByPk(req.params.id);
    res.json(userRole);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// Delete user role
router.delete('/:id', async (req, res) => {
  try {
    const deleted = await UserRole.destroy({
      where: { id: req.params.id }
    });
    if (!deleted) {
      return res.status(404).json({ error: 'User role not found' });
    }
    res.json({ message: 'User role deleted' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;