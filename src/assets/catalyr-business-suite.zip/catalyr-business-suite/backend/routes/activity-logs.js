const express = require('express');
const router = express.Router();
const { ActivityLog } = require('../models');

// Get all activity logs
router.get('/', async (req, res) => {
  try {
    const activityLogs = await ActivityLog.findAll();
    res.json(activityLogs);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get activity log by id
router.get('/:id', async (req, res) => {
  try {
    const activityLog = await ActivityLog.findByPk(req.params.id);
    if (!activityLog) {
      return res.status(404).json({ error: 'Activity log not found' });
    }
    res.json(activityLog);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Create activity log
router.post('/', async (req, res) => {
  try {
    const activityLog = await ActivityLog.create(req.body);
    res.status(201).json(activityLog);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// Update activity log
router.put('/:id', async (req, res) => {
  try {
    const [updated] = await ActivityLog.update(req.body, {
      where: { id: req.params.id }
    });
    if (!updated) {
      return res.status(404).json({ error: 'Activity log not found' });
    }
    const activityLog = await ActivityLog.findByPk(req.params.id);
    res.json(activityLog);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// Delete activity log
router.delete('/:id', async (req, res) => {
  try {
    const deleted = await ActivityLog.destroy({
      where: { id: req.params.id }
    });
    if (!deleted) {
      return res.status(404).json({ error: 'Activity log not found' });
    }
    res.json({ message: 'Activity log deleted' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;
