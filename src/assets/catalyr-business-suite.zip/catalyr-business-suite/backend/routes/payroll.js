const express = require('express');
const router = express.Router();
const { Payroll } = require('../models');

// Get all payroll records
router.get('/', async (req, res) => {
  try {
    const payroll = await Payroll.findAll();
    res.json(payroll);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get payroll by id
router.get('/:id', async (req, res) => {
  try {
    const payroll = await Payroll.findByPk(req.params.id);
    if (!payroll) {
      return res.status(404).json({ error: 'Payroll record not found' });
    }
    res.json(payroll);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Create payroll record
router.post('/', async (req, res) => {
  try {
    const payroll = await Payroll.create(req.body);
    res.status(201).json(payroll);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// Update payroll record
router.put('/:id', async (req, res) => {
  try {
    const [updated] = await Payroll.update(req.body, {
      where: { id: req.params.id }
    });
    if (!updated) {
      return res.status(404).json({ error: 'Payroll record not found' });
    }
    const payroll = await Payroll.findByPk(req.params.id);
    res.json(payroll);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// Delete payroll record
router.delete('/:id', async (req, res) => {
  try {
    const deleted = await Payroll.destroy({
      where: { id: req.params.id }
    });
    if (!deleted) {
      return res.status(404).json({ error: 'Payroll record not found' });
    }
    res.json({ message: 'Payroll record deleted' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;
