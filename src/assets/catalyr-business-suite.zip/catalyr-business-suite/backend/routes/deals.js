const express = require('express');
const router = express.Router();
const { Deal } = require('../models');

// Get all deals
router.get('/', async (req, res) => {
  try {
    const deals = await Deal.findAll();
    res.json(deals);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get deal by id
router.get('/:id', async (req, res) => {
  try {
    const deal = await Deal.findByPk(req.params.id);
    if (!deal) {
      return res.status(404).json({ error: 'Deal not found' });
    }
    res.json(deal);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Create deal
router.post('/', async (req, res) => {
  try {
    const deal = await Deal.create(req.body);
    res.status(201).json(deal);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// Update deal
router.put('/:id', async (req, res) => {
  try {
    const [updated] = await Deal.update(req.body, {
      where: { id: req.params.id }
    });
    if (!updated) {
      return res.status(404).json({ error: 'Deal not found' });
    }
    const deal = await Deal.findByPk(req.params.id);
    res.json(deal);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// Delete deal
router.delete('/:id', async (req, res) => {
  try {
    const deleted = await Deal.destroy({
      where: { id: req.params.id }
    });
    if (!deleted) {
      return res.status(404).json({ error: 'Deal not found' });
    }
    res.json({ message: 'Deal deleted' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;
