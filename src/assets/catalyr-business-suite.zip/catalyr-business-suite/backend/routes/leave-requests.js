const express = require('express');
const router = express.Router();
const { LeaveRequest } = require('../models');

// Get all leave requests
router.get('/', async (req, res) => {
  try {
    const leaveRequests = await LeaveRequest.findAll();
    res.json(leaveRequests);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get leave request by id
router.get('/:id', async (req, res) => {
  try {
    const leaveRequest = await LeaveRequest.findByPk(req.params.id);
    if (!leaveRequest) {
      return res.status(404).json({ error: 'Leave request not found' });
    }
    res.json(leaveRequest);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Create leave request
router.post('/', async (req, res) => {
  try {
    const leaveRequest = await LeaveRequest.create(req.body);
    res.status(201).json(leaveRequest);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// Update leave request
router.put('/:id', async (req, res) => {
  try {
    const [updated] = await LeaveRequest.update(req.body, {
      where: { id: req.params.id }
    });
    if (!updated) {
      return res.status(404).json({ error: 'Leave request not found' });
    }
    const leaveRequest = await LeaveRequest.findByPk(req.params.id);
    res.json(leaveRequest);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// Delete leave request
router.delete('/:id', async (req, res) => {
  try {
    const deleted = await LeaveRequest.destroy({
      where: { id: req.params.id }
    });
    if (!deleted) {
      return res.status(404).json({ error: 'Leave request not found' });
    }
    res.json({ message: 'Leave request deleted' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;
