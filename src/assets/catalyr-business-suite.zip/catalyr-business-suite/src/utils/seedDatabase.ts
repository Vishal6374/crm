import { supabase } from "@/integrations/supabase/client";

export async function seedDatabase(): Promise<{ success: boolean; message: string }> {
  try {
    console.log("Starting database seeding...");

    // Insert departments
    console.log("Inserting departments...");
    const { error: deptError } = await supabase.from("departments").insert([
      { name: "Engineering", description: "Software development and engineering" },
      { name: "Sales", description: "Sales and business development" },
      { name: "Marketing", description: "Marketing and customer acquisition" },
      { name: "HR", description: "Human resources and administration" },
      { name: "Finance", description: "Financial operations and accounting" },
    ]);
    if (deptError) throw new Error(`Departments error: ${deptError.message}`);

    // Insert employees
    console.log("Inserting employees...");
    const { error: empError } = await supabase.from("employees").insert([
      {
        employee_code: "EMP001",
        full_name: "John Smith",
        email: "john.smith@company.com",
        phone: "+91-9876543210",
        department_id: null, // Will be updated after departments are inserted
        designation: "Senior Developer",
        joining_date: "2023-01-15",
        salary: 85000,
        status: "active",
      },
      {
        employee_code: "EMP002",
        full_name: "Sarah Johnson",
        email: "sarah.johnson@company.com",
        phone: "+91-9876543211",
        department_id: null,
        designation: "Sales Manager",
        joining_date: "2023-02-01",
        salary: 75000,
        status: "active",
      },
      {
        employee_code: "EMP003",
        full_name: "Mike Davis",
        email: "mike.davis@company.com",
        phone: "+91-9876543212",
        department_id: null,
        designation: "Full Stack Developer",
        joining_date: "2023-03-10",
        salary: 70000,
        status: "active",
      },
      {
        employee_code: "EMP004",
        full_name: "Emily Chen",
        email: "emily.chen@company.com",
        phone: "+91-9876543213",
        department_id: null,
        designation: "Marketing Specialist",
        joining_date: "2023-04-05",
        salary: 55000,
        status: "active",
      },
      {
        employee_code: "EMP005",
        full_name: "David Wilson",
        email: "david.wilson@company.com",
        phone: "+91-9876543214",
        department_id: null,
        designation: "HR Manager",
        joining_date: "2023-01-20",
        salary: 65000,
        status: "active",
      },
      {
        employee_code: "EMP006",
        full_name: "Lisa Brown",
        email: "lisa.brown@company.com",
        phone: "+91-9876543215",
        department_id: null,
        designation: "Accountant",
        joining_date: "2023-05-12",
        salary: 60000,
        status: "active",
      },
      {
        employee_code: "EMP007",
        full_name: "Tom Anderson",
        email: "tom.anderson@company.com",
        phone: "+91-9876543216",
        department_id: null,
        designation: "Sales Executive",
        joining_date: "2023-06-01",
        salary: 50000,
        status: "active",
      },
      {
        employee_code: "EMP008",
        full_name: "Anna Garcia",
        email: "anna.garcia@company.com",
        phone: "+91-9876543217",
        department_id: null,
        designation: "DevOps Engineer",
        joining_date: "2023-07-15",
        salary: 80000,
        status: "active",
      },
    ]);
    if (empError) throw new Error(`Employees error: ${empError.message}`);

    // Update employee department_ids
    console.log("Updating employee departments...");
    const { data: depts } = await supabase.from("departments").select("id, name");
    const deptMap: { [key: string]: string } = {};
    depts?.forEach((dept) => {
      deptMap[dept.name] = dept.id;
    });

    await supabase
      .from("employees")
      .update({ department_id: deptMap["Engineering"] })
      .in("employee_code", ["EMP001", "EMP003", "EMP008"]);

    await supabase
      .from("employees")
      .update({ department_id: deptMap["Sales"] })
      .in("employee_code", ["EMP002", "EMP007"]);

    await supabase
      .from("employees")
      .update({ department_id: deptMap["Marketing"] })
      .eq("employee_code", "EMP004");

    await supabase
      .from("employees")
      .update({ department_id: deptMap["HR"] })
      .eq("employee_code", "EMP005");

    await supabase
      .from("employees")
      .update({ department_id: deptMap["Finance"] })
      .eq("employee_code", "EMP006");

    // Insert companies
    console.log("Inserting companies...");
    const { error: compError } = await supabase.from("companies").insert([
      {
        name: "TechCorp Solutions",
        industry: "Technology",
        website: "https://techcorp.com",
        phone: "+91-9876543201",
        email: "contact@techcorp.com",
        address: "123 Tech Street",
        city: "Mumbai",
        country: "India",
        notes: "Leading software solutions provider",
      },
      {
        name: "Global Industries",
        industry: "Manufacturing",
        website: "https://globalind.com",
        phone: "+91-9876543202",
        email: "sales@globalind.com",
        address: "456 Industrial Road",
        city: "Delhi",
        country: "India",
        notes: "Manufacturing and distribution",
      },
      {
        name: "Innovate Labs",
        industry: "Healthcare",
        website: "https://innovatelabs.com",
        phone: "+91-9876543203",
        email: "info@innovatelabs.com",
        address: "789 Health Avenue",
        city: "Bangalore",
        country: "India",
        notes: "Medical technology company",
      },
      {
        name: "DataFlow Systems",
        industry: "Technology",
        website: "https://dataflow.com",
        phone: "+91-9876543204",
        email: "support@dataflow.com",
        address: "321 Data Lane",
        city: "Chennai",
        country: "India",
        notes: "Data analytics and AI solutions",
      },
      {
        name: "Green Energy Corp",
        industry: "Energy",
        website: "https://greenenergy.com",
        phone: "+91-9876543205",
        email: "contact@greenenergy.com",
        address: "654 Green Street",
        city: "Pune",
        country: "India",
        notes: "Renewable energy solutions",
      },
    ]);
    if (compError) throw new Error(`Companies error: ${compError.message}`);

    // Insert contacts
    console.log("Inserting contacts...");
    const { data: companies } = await supabase.from("companies").select("id, name");
    const companyMap: { [key: string]: string } = {};
    companies?.forEach((comp) => {
      companyMap[comp.name] = comp.id;
    });

    const { error: contactError } = await supabase.from("contacts").insert([
      {
        company_id: companyMap["TechCorp Solutions"],
        first_name: "Rajesh",
        last_name: "Kumar",
        email: "rajesh.kumar@techcorp.com",
        phone: "+91-9876543218",
        position: "CTO",
        notes: "Technical decision maker",
      },
      {
        company_id: companyMap["TechCorp Solutions"],
        first_name: "Priya",
        last_name: "Sharma",
        email: "priya.sharma@techcorp.com",
        phone: "+91-9876543219",
        position: "CEO",
        notes: "Company founder",
      },
      {
        company_id: companyMap["Global Industries"],
        first_name: "Amit",
        last_name: "Patel",
        email: "amit.patel@globalind.com",
        phone: "+91-9876543220",
        position: "Procurement Manager",
        notes: "Handles vendor relationships",
      },
      {
        company_id: companyMap["Innovate Labs"],
        first_name: "Dr. Sunita",
        last_name: "Verma",
        email: "sunita.verma@innovatelabs.com",
        phone: "+91-9876543221",
        position: "Medical Director",
        notes: "Healthcare expert",
      },
      {
        company_id: companyMap["DataFlow Systems"],
        first_name: "Vikram",
        last_name: "Singh",
        email: "vikram.singh@dataflow.com",
        phone: "+91-9876543222",
        position: "VP Engineering",
        notes: "Technical lead",
      },
      {
        company_id: companyMap["Green Energy Corp"],
        first_name: "Meera",
        last_name: "Nair",
        email: "meera.nair@greenenergy.com",
        phone: "+91-9876543223",
        position: "Operations Director",
        notes: "Project management focus",
      },
    ]);
    if (contactError) throw new Error(`Contacts error: ${contactError.message}`);

    // Insert leads
    console.log("Inserting leads...");
    const { error: leadError } = await supabase.from("leads").insert([
      {
        company_name: "TechCorp Solutions",
        contact_name: "Rajesh Kumar",
        email: "rajesh.kumar@techcorp.com",
        phone: "+91-9876543218",
        source: "Website",
        status: "lost",
        notes: "High-value enterprise client",
        created_at: "2024-12-01T10:00:00Z",
      },
      {
        company_name: "Global Industries",
        contact_name: "Amit Patel",
        email: "amit.patel@globalind.com",
        phone: "+91-9876543220",
        source: "LinkedIn",
        status: "contacted",
        notes: "Manufacturing automation project",
        created_at: "2024-12-02T14:30:00Z",
      },
      {
        company_name: "Innovate Labs",
        contact_name: "Dr. Sunita Verma",
        email: "sunita.verma@innovatelabs.com",
        phone: "+91-9876543221",
        source: "Referral",
        status: "new",
        notes: "Healthcare software implementation",
        created_at: "2024-12-03T09:15:00Z",
      },
      {
        company_name: "DataFlow Systems",
        contact_name: "Vikram Singh",
        email: "vikram.singh@dataflow.com",
        phone: "+91-9876543222",
        source: "Trade Show",
        status: "lost",
        notes: "Big data analytics platform",
        created_at: "2024-12-04T16:45:00Z",
      },
      {
        company_name: "Green Energy Corp",
        contact_name: "Meera Nair",
        email: "meera.nair@greenenergy.com",
        phone: "+91-9876543223",
        source: "Cold Call",
        status: "lost",
        notes: "Solar panel monitoring system",
        created_at: "2024-12-05T11:20:00Z",
      },
      {
        company_name: "StartupXYZ",
        contact_name: "Alex Johnson",
        email: "alex@startupxyz.com",
        phone: "+91-9876543224",
        source: "Website",
        status: "new",
        notes: "SaaS startup looking for CRM",
        created_at: "2024-12-06T13:10:00Z",
      },
      {
        company_name: "MegaCorp",
        contact_name: "Jennifer Lee",
        email: "jennifer@megacorp.com",
        phone: "+91-9876543225",
        source: "Email Campaign",
        status: "contacted",
        notes: "Enterprise digital transformation",
        created_at: "2024-12-07T15:30:00Z",
      },
      {
        company_name: "TechStart Inc",
        contact_name: "Mark Thompson",
        email: "mark@techstart.com",
        phone: "+91-9876543226",
        source: "LinkedIn",
        status: "lost",
        notes: "Mobile app development project",
        created_at: "2024-12-08T10:45:00Z",
      },
      {
        company_name: "FinanceHub",
        contact_name: "Rachel Green",
        email: "rachel@financehub.com",
        phone: "+91-9876543227",
        source: "Referral",
        status: "new",
        notes: "Financial software integration",
        created_at: "2024-12-09T12:00:00Z",
      },
      {
        company_name: "LogisticsPro",
        contact_name: "Steve Rogers",
        email: "steve@logisticspro.com",
        phone: "+91-9876543228",
        source: "Trade Show",
        status: "contacted",
        notes: "Supply chain optimization",
        created_at: "2024-12-10T14:20:00Z",
      },
      {
        company_name: "HealthTech Solutions",
        contact_name: "Dr. Bruce Banner",
        email: "bruce@healthtech.com",
        phone: "+91-9876543229",
        source: "Website",
        status: "lost",
        notes: "Medical records system",
        created_at: "2024-12-11T09:30:00Z",
      },
      {
        company_name: "EduLearn Platform",
        contact_name: "Diana Prince",
        email: "diana@edulearn.com",
        phone: "+91-9876543230",
        source: "Cold Call",
        status: "lost",
        notes: "E-learning platform development",
        created_at: "2024-12-12T16:15:00Z",
      },
      {
        company_name: "RetailMax",
        contact_name: "Tony Stark",
        email: "tony@retailmax.com",
        phone: "+91-9876543231",
        source: "Email Campaign",
        status: "new",
        notes: "E-commerce platform upgrade",
        created_at: "2024-12-13T11:45:00Z",
      },
      {
        company_name: "CloudServices Inc",
        contact_name: "Natasha Romanoff",
        email: "natasha@cloudservices.com",
        phone: "+91-9876543232",
        source: "LinkedIn",
        status: "contacted",
        notes: "Cloud migration project",
        created_at: "2024-12-14T13:20:00Z",
      },
      {
        company_name: "AutoTech Motors",
        contact_name: "Clint Barton",
        email: "clint@autotech.com",
        phone: "+91-9876543233",
        source: "Referral",
        status: "lost",
        notes: "IoT automotive solutions",
        created_at: "2024-12-15T15:10:00Z",
      },
      // November leads
      {
        company_name: "BuildCorp",
        contact_name: "Wanda Maximoff",
        email: "wanda@buildcorp.com",
        phone: "+91-9876543234",
        source: "Website",
        status: "new",
        notes: "Construction management software",
        created_at: "2024-11-01T10:00:00Z",
      },
      {
        company_name: "FoodieApp",
        contact_name: "Sam Wilson",
        email: "sam@foodieapp.com",
        phone: "+91-9876543235",
        source: "Trade Show",
        status: "contacted",
        notes: "Food delivery platform",
        created_at: "2024-11-05T14:30:00Z",
      },
      {
        company_name: "TravelBook",
        contact_name: "Bucky Barnes",
        email: "bucky@travelbook.com",
        phone: "+91-9876543236",
        source: "LinkedIn",
        status: "lost",
        notes: "Travel booking system",
        created_at: "2024-11-10T09:15:00Z",
      },
      {
        company_name: "FitLife Gym",
        contact_name: "Carol Danvers",
        email: "carol@fitlife.com",
        phone: "+91-9876543237",
        source: "Referral",
        status: "lost",
        notes: "Fitness tracking app",
        created_at: "2024-11-15T16:45:00Z",
      },
      {
        company_name: "MusicStream",
        contact_name: "Peter Parker",
        email: "peter@musicstream.com",
        phone: "+91-9876543238",
        source: "Cold Call",
        status: "new",
        notes: "Music streaming platform",
        created_at: "2024-11-20T11:20:00Z",
      },
      // October leads
      {
        company_name: "GameDev Studio",
        contact_name: "Scott Lang",
        email: "scott@gamedev.com",
        phone: "+91-9876543239",
        source: "Website",
        status: "contacted",
        notes: "Mobile game development",
        created_at: "2024-10-01T13:10:00Z",
      },
      {
        company_name: "AgriTech Solutions",
        contact_name: "Hope van Dyne",
        email: "hope@agritech.com",
        phone: "+91-9876543240",
        source: "Email Campaign",
        status: "lost",
        notes: "Agricultural IoT platform",
        created_at: "2024-10-10T15:30:00Z",
      },
      {
        company_name: "RealEstate Pro",
        contact_name: "Stephen Strange",
        email: "stephen@realestatepro.com",
        phone: "+91-9876543241",
        source: "LinkedIn",
        status: "new",
        notes: "Property management system",
        created_at: "2024-10-15T10:45:00Z",
      },
      {
        company_name: "CryptoWallet",
        contact_name: "Thor Odinson",
        email: "thor@cryptowallet.com",
        phone: "+91-9876543242",
        source: "Trade Show",
        status: "contacted",
        notes: "Cryptocurrency wallet app",
        created_at: "2024-10-20T12:00:00Z",
      },
      {
        company_name: "VideoCall Pro",
        contact_name: "Loki Laufeyson",
        email: "loki@videocall.com",
        phone: "+91-9876543243",
        source: "Referral",
        status: "lost",
        notes: "Video conferencing platform",
        created_at: "2024-10-25T14:20:00Z",
      },
    ]);
    if (leadError) throw new Error(`Leads error: ${leadError.message}`);

    // Insert deals
    console.log("Inserting deals...");
    const { data: contacts } = await supabase.from("contacts").select("id, email");
    const contactMap: { [key: string]: string } = {};
    contacts?.forEach((contact) => {
      contactMap[contact.email] = contact.id;
    });

    const { error: dealError } = await supabase.from("deals").insert([
      {
        title: "Enterprise CRM Implementation",
        company_id: companyMap["TechCorp Solutions"],
        contact_id: contactMap["rajesh.kumar@techcorp.com"],
        value: 250000,
        stage: "won",
        expected_close_date: "2024-12-15",
        notes: "Successfully closed enterprise deal",
        created_at: "2024-11-01T10:00:00Z",
        closed_at: "2024-12-10T14:00:00Z",
      },
      {
        title: "Manufacturing Automation",
        company_id: companyMap["Global Industries"],
        contact_id: contactMap["amit.patel@globalind.com"],
        value: 180000,
        stage: "proposal",
        expected_close_date: "2024-12-20",
        notes: "High-value manufacturing project",
        created_at: "2024-11-05T14:30:00Z",
      },
      {
        title: "Healthcare Software Platform",
        company_id: companyMap["Innovate Labs"],
        contact_id: contactMap["sunita.verma@innovatelabs.com"],
        value: 320000,
        stage: "negotiation",
        expected_close_date: "2024-12-25",
        notes: "Medical technology implementation",
        created_at: "2024-11-10T09:15:00Z",
      },
      {
        title: "Data Analytics Platform",
        company_id: companyMap["DataFlow Systems"],
        contact_id: contactMap["vikram.singh@dataflow.com"],
        value: 150000,
        stage: "lost",
        expected_close_date: "2024-12-30",
        notes: "Big data analytics solution",
        created_at: "2024-11-15T16:45:00Z",
      },
      {
        title: "Solar Monitoring System",
        company_id: companyMap["Green Energy Corp"],
        contact_id: contactMap["meera.nair@greenenergy.com"],
        value: 95000,
        stage: "lead",
        expected_close_date: "2025-01-15",
        notes: "Renewable energy monitoring",
        created_at: "2024-11-20T11:20:00Z",
      },
      {
        title: "SaaS CRM Integration",
        value: 75000,
        stage: "proposal",
        expected_close_date: "2024-12-18",
        notes: "Startup CRM implementation",
        created_at: "2024-11-25T13:10:00Z",
      },
      {
        title: "Digital Transformation",
        value: 500000,
        stage: "negotiation",
        expected_close_date: "2025-01-10",
        notes: "Large enterprise transformation",
        created_at: "2024-11-30T15:30:00Z",
      },
      {
        title: "Mobile App Development",
        value: 120000,
        stage: "lost",
        expected_close_date: "2024-12-22",
        notes: "Cross-platform mobile app",
        created_at: "2024-12-01T10:45:00Z",
      },
      {
        title: "Financial Software Integration",
        value: 85000,
        stage: "lead",
        expected_close_date: "2025-01-05",
        notes: "Banking software integration",
        created_at: "2024-12-02T12:00:00Z",
      },
      {
        title: "Supply Chain Optimization",
        value: 200000,
        stage: "won",
        expected_close_date: "2024-12-10",
        notes: "Logistics optimization platform",
        created_at: "2024-11-20T14:20:00Z",
        closed_at: "2024-12-08T10:30:00Z",
      },
      {
        title: "Medical Records System",
        value: 175000,
        stage: "proposal",
        expected_close_date: "2024-12-28",
        notes: "Electronic health records",
        created_at: "2024-12-03T09:30:00Z",
      },
      {
        title: "E-commerce Platform",
        value: 135000,
        stage: "lost",
        expected_close_date: "2025-01-08",
        notes: "E-commerce solution upgrade",
        created_at: "2024-12-04T11:45:00Z",
      },
      {
        title: "Cloud Migration Project",
        value: 280000,
        stage: "negotiation",
        expected_close_date: "2025-01-20",
        notes: "Full cloud infrastructure migration",
        created_at: "2024-12-05T13:20:00Z",
      },
      {
        title: "IoT Automotive Solutions",
        value: 160000,
        stage: "lead",
        expected_close_date: "2025-02-01",
        notes: "Connected vehicle platform",
        created_at: "2024-12-06T15:10:00Z",
      },
      {
        title: "Construction Management",
        value: 110000,
        stage: "won",
        expected_close_date: "2024-12-08",
        notes: "Construction project management",
        created_at: "2024-11-15T10:00:00Z",
        closed_at: "2024-12-06T16:00:00Z",
      },
      {
        title: "Food Delivery Platform",
        value: 90000,
        stage: "proposal",
        expected_close_date: "2024-12-24",
        notes: "Restaurant delivery system",
        created_at: "2024-12-07T14:30:00Z",
      },
    ]);
    if (dealError) throw new Error(`Deals error: ${dealError.message}`);

    // Insert tasks
    console.log("Inserting tasks...");
    const today = new Date().toISOString().split('T')[0];
    const tomorrow = new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString().split('T')[0];
    const dayAfter = new Date(Date.now() + 2 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];
    const weekLater = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];

    const { error: taskError } = await supabase.from("tasks").insert([
      {
        title: "Follow up with TechCorp Solutions",
        description: "Call Rajesh Kumar to discuss CRM requirements",
        status: "pending",
        due_date: today,
        priority: "high",
        created_at: "2024-12-10T09:00:00Z",
      },
      {
        title: "Prepare proposal for Global Industries",
        description: "Create detailed automation proposal",
        status: "in_progress",
        due_date: dayAfter,
        priority: "high",
        created_at: "2024-12-09T14:00:00Z",
      },
      {
        title: "Demo healthcare platform",
        description: "Schedule and conduct demo for Innovate Labs",
        status: "pending",
        due_date: tomorrow,
        priority: "medium",
        created_at: "2024-12-08T11:00:00Z",
      },
      {
        title: "Data analytics requirements gathering",
        description: "Meet with DataFlow Systems team",
        status: "completed",
        due_date: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString().split('T')[0],
        priority: "medium",
        created_at: "2024-12-05T10:00:00Z",
      },
      {
        title: "Solar monitoring system design",
        description: "Create technical design document",
        status: "pending",
        due_date: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
        priority: "low",
        created_at: "2024-12-07T16:00:00Z",
      },
      {
        title: "Client onboarding documentation",
        description: "Prepare onboarding materials for new clients",
        status: "pending",
        due_date: today,
        priority: "high",
        created_at: "2024-12-10T08:00:00Z",
      },
      {
        title: "Competitor analysis report",
        description: "Research and analyze competitor offerings",
        status: "in_progress",
        due_date: weekLater,
        priority: "medium",
        created_at: "2024-12-06T13:00:00Z",
      },
      {
        title: "Team meeting preparation",
        description: "Prepare agenda for weekly team meeting",
        status: "pending",
        due_date: today,
        priority: "medium",
        created_at: "2024-12-10T12:00:00Z",
      },
    ]);
    if (taskError) throw new Error(`Tasks error: ${taskError.message}`);

    // Insert attendance data
    console.log("Inserting attendance data...");
    const { data: employees } = await supabase.from("employees").select("id, employee_code");
    const employeeMap: { [key: string]: string } = {};
    employees?.forEach((emp) => {
      employeeMap[emp.employee_code] = emp.id;
    });

    const attendanceData = [];
    const days = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday'];

    for (let i = 0; i < 5; i++) {
      const date = new Date();
      date.setDate(date.getDate() - (date.getDay() - 1) + i); // Monday to Friday this week
      const dateStr = date.toISOString().split('T')[0];

      // EMP001 - all present except Thursday late
      attendanceData.push({
        employee_id: employeeMap['EMP001'],
        date: dateStr,
        status: i === 3 ? 'late' : 'present',
      });

      // EMP002 - Wednesday absent
      attendanceData.push({
        employee_id: employeeMap['EMP002'],
        date: dateStr,
        status: i === 2 ? 'absent' : 'present',
      });

      // EMP003 - all present
      attendanceData.push({
        employee_id: employeeMap['EMP003'],
        date: dateStr,
        status: 'present',
      });

      // EMP004 - Tuesday absent
      attendanceData.push({
        employee_id: employeeMap['EMP004'],
        date: dateStr,
        status: i === 1 ? 'absent' : 'present',
      });

      // EMP005 - all present
      attendanceData.push({
        employee_id: employeeMap['EMP005'],
        date: dateStr,
        status: 'present',
      });

      // EMP006 - Friday absent
      attendanceData.push({
        employee_id: employeeMap['EMP006'],
        date: dateStr,
        status: i === 4 ? 'absent' : 'present',
      });

      // EMP007 - Thursday late
      attendanceData.push({
        employee_id: employeeMap['EMP007'],
        date: dateStr,
        status: i === 3 ? 'late' : 'present',
      });

      // EMP008 - all present
      attendanceData.push({
        employee_id: employeeMap['EMP008'],
        date: dateStr,
        status: 'present',
      });
    }

    const { error: attendanceError } = await supabase.from("attendance").insert(attendanceData);
    if (attendanceError) throw new Error(`Attendance error: ${attendanceError.message}`);

    // Insert leave requests
    console.log("Inserting leave requests...");
    const { error: leaveError } = await supabase.from("leave_requests").insert([
      {
        employee_id: employeeMap['EMP001'],
        leave_type: 'annual',
        start_date: new Date(Date.now() + 10 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
        end_date: new Date(Date.now() + 15 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
        reason: 'Family vacation',
        status: 'pending',
      },
      {
        employee_id: employeeMap['EMP003'],
        leave_type: 'sick',
        start_date: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
        end_date: new Date(Date.now() + 6 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
        reason: 'Medical appointment',
        status: 'pending',
      },
      {
        employee_id: employeeMap['EMP004'],
        leave_type: 'personal',
        start_date: new Date(Date.now() + 20 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
        end_date: new Date(Date.now() + 22 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
        reason: 'Personal matters',
        status: 'approved',
      },
      {
        employee_id: employeeMap['EMP007'],
        leave_type: 'annual',
        start_date: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
        end_date: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
        reason: 'Previous vacation',
        status: 'approved',
      },
    ]);
    if (leaveError) throw new Error(`Leave requests error: ${leaveError.message}`);

    // Insert payroll data
    console.log("Inserting payroll data...");
    const currentMonth = new Date().getMonth() + 1;
    const currentYear = new Date().getFullYear();

    const { error: payrollError } = await supabase.from("payroll").insert([
      {
        employee_id: employeeMap['EMP001'],
        month: currentMonth,
        year: currentYear,
        basic_salary: 85000,
        deductions: 5000,
        bonus: 10000,
        net_salary: 90000,
        status: 'paid',
        paid_at: new Date().toISOString(),
      },
      {
        employee_id: employeeMap['EMP002'],
        month: currentMonth,
        year: currentYear,
        basic_salary: 75000,
        deductions: 4000,
        bonus: 8000,
        net_salary: 79000,
        status: 'paid',
      },
      {
        employee_id: employeeMap['EMP003'],
        month: currentMonth,
        year: currentYear,
        basic_salary: 70000,
        deductions: 3500,
        bonus: 7000,
        net_salary: 73500,
        status: 'pending',
      },
      {
        employee_id: employeeMap['EMP004'],
        month: currentMonth,
        year: currentYear,
        basic_salary: 55000,
        deductions: 2500,
        bonus: 5000,
        net_salary: 57500,
        status: 'pending',
      },
      {
        employee_id: employeeMap['EMP005'],
        month: currentMonth,
        year: currentYear,
        basic_salary: 65000,
        deductions: 3000,
        bonus: 6000,
        net_salary: 68000,
        status: 'paid',
      },
      {
        employee_id: employeeMap['EMP006'],
        month: currentMonth,
        year: currentYear,
        basic_salary: 60000,
        deductions: 2800,
        bonus: 5500,
        net_salary: 62700,
        status: 'pending',
      },
      {
        employee_id: employeeMap['EMP007'],
        month: currentMonth,
        year: currentYear,
        basic_salary: 50000,
        deductions: 2000,
        bonus: 4000,
        net_salary: 52000,
        status: 'paid',
      },
      {
        employee_id: employeeMap['EMP008'],
        month: currentMonth,
        year: currentYear,
        basic_salary: 80000,
        deductions: 4500,
        bonus: 9000,
        net_salary: 84500,
        status: 'pending',
      },
    ]);
    if (payrollError) throw new Error(`Payroll error: ${payrollError.message}`);

    console.log("Database seeding completed successfully!");
    return { success: true, message: "Database seeded successfully with dummy data!" };

  } catch (error) {
    console.error("Error seeding database:", error);
    return {
      success: false,
      message: error instanceof Error ? error.message : "Unknown error occurred during seeding"
    };
  }
}
