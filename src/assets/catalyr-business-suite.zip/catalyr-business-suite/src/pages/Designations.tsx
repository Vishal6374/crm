import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Plus, Search, MoreHorizontal, Edit, Trash2, Users, Eye } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";

type Designation = {
  id: string;
  name: string;
  description: string | null;
  created_at: string;
  updated_at: string;
};

function DesignationForm({
  initialData,
  onSubmit,
  onCancel
}: {
  initialData?: Designation;
  onSubmit: (formData: FormData) => void;
  onCancel?: () => void;
}) {
  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    onSubmit(formData);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="name">Designation Name *</Label>
        <Input
          id="name"
          name="name"
          required
          defaultValue={initialData?.name}
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="description">Description</Label>
        <Textarea
          id="description"
          name="description"
          defaultValue={initialData?.description || ""}
          rows={3}
        />
      </div>

      <div className="flex gap-2 pt-4">
        <Button type="submit" className="flex-1">
          {initialData ? "Update Designation" : "Create Designation"}
        </Button>
        {onCancel && (
          <Button type="button" variant="outline" onClick={onCancel}>
            Cancel
          </Button>
        )}
      </div>
    </form>
  );
}

export default function Designations() {
  const [designations, setDesignations] = useState<Designation[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [editingDesignation, setEditingDesignation] = useState<Designation | null>(null);
  const [viewingDesignation, setViewingDesignation] = useState<Designation | null>(null);
  const { toast } = useToast();

  useEffect(() => {
    fetchDesignations();
  }, []);

  const fetchDesignations = async () => {
    try {
      const { data, error } = await supabase
        .from('designations')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setDesignations(data || []);
    } catch (error) {
      console.error('Error fetching designations:', error);
      const errObj: any = error || {};
      const desc = errObj.message || errObj.details || 'Failed to fetch designations';
      toast({ title: 'Error', description: desc, variant: 'destructive' });
      setDesignations([]);
    } finally {
      setLoading(false);
    }
  };

  const filteredDesignations = designations.filter((designation) =>
    designation.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    designation.description?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleCreateDesignation = async (formData: FormData) => {
    try {
      const designationData = {
        name: formData.get('name') as string,
        description: formData.get('description') as string,
      };

      const { error } = await supabase
        .from('designations')
        .insert([designationData]);

      if (error) throw error;

      toast({
        title: "Success",
        description: "Designation created successfully",
      });

      setIsCreateDialogOpen(false);
      fetchDesignations();
    } catch (error) {
      console.error('Error creating designation:', error);
      toast({
        title: "Error",
        description: "Failed to create designation",
        variant: "destructive",
      });
    }
  };

  const handleUpdateDesignation = async (formData: FormData) => {
    if (!editingDesignation) return;

    try {
      const designationData = {
        name: formData.get('name') as string,
        description: formData.get('description') as string,
      };

      const { error } = await supabase
        .from('designations')
        .update(designationData)
        .eq('id', editingDesignation.id);

      if (error) throw error;

      toast({
        title: "Success",
        description: "Designation updated successfully",
      });

      setEditingDesignation(null);
      fetchDesignations();
    } catch (error) {
      console.error('Error updating designation:', error);
      toast({
        title: "Error",
        description: "Failed to update designation",
        variant: "destructive",
      });
    }
  };

  const handleDeleteDesignation = async (designationId: string) => {
    try {
      const { error } = await supabase
        .from('designations')
        .delete()
        .eq('id', designationId);

      if (error) throw error;

      toast({
        title: "Success",
        description: "Designation deleted successfully",
      });

      fetchDesignations();
    } catch (error) {
      console.error('Error deleting designation:', error);
      toast({
        title: "Error",
        description: "Failed to delete designation",
        variant: "destructive",
      });
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
          <p className="mt-2 text-muted-foreground">Loading designations...</p>
        </div>
      </div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-6"
    >
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Designations</h1>
          <p className="text-muted-foreground">
            Manage job titles and designations
          </p>
        </div>
        <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="h-4 w-4 mr-2" />
              Add Designation
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>Create New Designation</DialogTitle>
            </DialogHeader>
            <DesignationForm
              onSubmit={handleCreateDesignation}
            />
          </DialogContent>
        </Dialog>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Designations</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{designations.length}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Designations</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{designations.length}</div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="pt-6">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search designations..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
        </CardContent>
      </Card>

      {/* Designations Table */}
      <Card className="flex flex-col h-[calc(100vh-12rem)]">
        <CardHeader className="flex-shrink-0">
          <CardTitle>All Designations ({filteredDesignations.length})</CardTitle>
        </CardHeader>
        <CardContent className="flex-1 overflow-hidden p-0">
          <div className="h-full overflow-y-auto">
            <Table>
              <TableHeader className="sticky top-0 bg-background z-10">
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Description</TableHead>
                  <TableHead>Created</TableHead>
                  <TableHead className="w-12"></TableHead>
                </TableRow>
              </TableHeader>
            <TableBody>
              {filteredDesignations.map((designation) => (
                <TableRow key={designation.id}>
                  <TableCell className="font-medium">
                    {designation.name}
                  </TableCell>
                  <TableCell>
                    {designation.description || '-'}
                  </TableCell>
                  <TableCell>
                    {new Date(designation.created_at).toLocaleDateString()}
                  </TableCell>
                  <TableCell>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="sm">
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem onClick={() => setViewingDesignation(designation)}>
                          <Eye className="h-4 w-4 mr-2" />
                          View Details
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => setEditingDesignation(designation)}>
                          <Edit className="h-4 w-4 mr-2" />
                          Edit Designation
                        </DropdownMenuItem>
                        <DropdownMenuItem
                          onClick={() => handleDeleteDesignation(designation.id)}
                          className="text-destructive"
                        >
                          <Trash2 className="h-4 w-4 mr-2" />
                          Delete
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>

          {filteredDesignations.length === 0 && (
            <div className="text-center py-8">
              <p className="text-muted-foreground">No designations found</p>
            </div>
          )}
          </div>
        </CardContent>
      </Card>

      {/* Edit Dialog */}
      <Dialog open={!!editingDesignation} onOpenChange={() => setEditingDesignation(null)}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Edit Designation</DialogTitle>
          </DialogHeader>
          {editingDesignation && (
            <DesignationForm
              initialData={editingDesignation}
              onSubmit={handleUpdateDesignation}
              onCancel={() => setEditingDesignation(null)}
            />
          )}
        </DialogContent>
      </Dialog>

      {/* View Designation Sheet */}
      <Sheet open={!!viewingDesignation} onOpenChange={() => setViewingDesignation(null)}>
        <SheetContent className="w-full sm:max-w-2xl overflow-y-auto">
          <SheetHeader>
            <SheetTitle className="flex items-center gap-2">
              <Users className="h-5 w-5" />
              Designation Details
            </SheetTitle>
          </SheetHeader>
          {viewingDesignation && (
            <div className="space-y-6 mt-6">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-sm font-medium text-muted-foreground">Name</Label>
                  <p className="text-sm font-medium">{viewingDesignation.name}</p>
                </div>
                <div>
                  <Label className="text-sm font-medium text-muted-foreground">Created</Label>
                  <p className="text-sm font-medium">{new Date(viewingDesignation.created_at).toLocaleString()}</p>
                </div>
              </div>
              {viewingDesignation.description && (
                <div>
                  <Label className="text-sm font-medium text-muted-foreground">Description</Label>
                  <p className="text-sm mt-1">{viewingDesignation.description}</p>
                </div>
              )}
            </div>
          )}
        </SheetContent>
      </Sheet>
    </motion.div>
  );
}
