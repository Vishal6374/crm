import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { seedDatabase } from "@/utils/seedDatabase";
import { Loader2 } from "lucide-react";

export default function SeedDatabase() {
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<{ success: boolean; message: string } | null>(null);

  const handleSeed = async () => {
    setLoading(true);
    setResult(null);

    try {
      const seedResult = await seedDatabase();
      setResult(seedResult);
    } catch (error) {
      setResult({ success: false, message: `Unexpected error: ${error}` });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container mx-auto py-8">
      <Card className="max-w-2xl mx-auto">
        <CardHeader>
          <CardTitle>Database Seeding Tool</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-muted-foreground">
            This tool will populate your database with dummy data for testing the dashboard features.
            It will create sample departments, employees, companies, contacts, leads, deals, tasks,
            attendance records, leave requests, and payroll data.
          </p>

          <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
            <h4 className="font-medium text-yellow-800 mb-2">Warning</h4>
            <p className="text-sm text-yellow-700">
              This will add dummy data to your database. Make sure you're running this in a development
              environment and not on production data.
            </p>
          </div>

          <Button
            onClick={handleSeed}
            disabled={loading}
            className="w-full"
            size="lg"
          >
            {loading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Seeding Database...
              </>
            ) : (
              "Seed Database with Dummy Data"
            )}
          </Button>

          {result && (
            <div className={`p-4 rounded-lg border ${
              result.success
                ? "bg-green-50 border-green-200 text-green-800"
                : "bg-red-50 border-red-200 text-red-800"
            }`}>
              <h4 className={`font-medium mb-2 ${result.success ? "text-green-800" : "text-red-800"}`}>
                {result.success ? "Success!" : "Error"}
              </h4>
              <p className="text-sm">{result.message}</p>
            </div>
          )}

          <div className="text-sm text-muted-foreground">
            <p className="font-medium mb-2">What will be created:</p>
            <ul className="list-disc list-inside space-y-1">
              <li>5 departments (Engineering, Sales, Marketing, HR, Finance)</li>
              <li>8 employees with various roles and salaries</li>
              <li>5 companies across different industries</li>
              <li>6 contacts associated with companies</li>
              <li>25+ leads with different statuses and creation dates</li>
              <li>16 deals in various pipeline stages</li>
              <li>8 tasks with different priorities and due dates</li>
              <li>Weekly attendance records for all employees</li>
              <li>4 leave requests (some pending, some approved)</li>
              <li>Payroll records for the current month</li>
            </ul>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
