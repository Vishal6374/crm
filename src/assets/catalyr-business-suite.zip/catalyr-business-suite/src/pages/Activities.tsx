import React, { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { useToast } from "@/hooks/use-toast";
import { activitiesService } from "@/services/activities";
import {
  Phone,
  Mail,
  FileText,
  UserPlus,
  CheckCircle,
  Briefcase,
  CalendarDays,
  Clock,
} from "lucide-react";

/* ------------------------------
   Activity Type Mapping
--------------------------------*/
const activityIcons: Record<string, JSX.Element> = {
  create: <UserPlus size={16} />,
  update: <CheckCircle size={16} />,
  delete: <FileText size={16} />,
  assign: <UserPlus size={16} />,
  approve: <CheckCircle size={16} />,
  reject: <FileText size={16} />,
  login: <UserPlus size={16} />,
  logout: <UserPlus size={16} />,
  export: <FileText size={16} />,
  import: <FileText size={16} />,
  bulk_update: <CheckCircle size={16} />,
  status_update: <CheckCircle size={16} />,
  call: <Phone size={16} />,
  email: <Mail size={16} />,
  note: <FileText size={16} />,
  lead: <UserPlus size={16} />,
  deal: <Briefcase size={16} />,
  task: <CheckCircle size={16} />,
  leave: <CalendarDays size={16} />,
  clock_in: <Clock size={16} />,
  clock_out: <Clock size={16} />,
};

const activityLabels: Record<string, string> = {
  create: "Created",
  update: "Updated",
  delete: "Deleted",
  assign: "Assigned",
  approve: "Approved",
  reject: "Rejected",
  login: "Logged In",
  logout: "Logged Out",
  export: "Exported",
  import: "Imported",
  bulk_update: "Bulk Updated",
  status_update: "Status Changed",
  call: "Call Logged",
  email: "Email Sent",
  note: "Note Added",
  lead: "Lead Created",
  deal: "Deal Updated",
  task: "Task Action",
  leave: "Leave Request",
  clock_in: "Clocked In",
  clock_out: "Clocked Out",
};

const entityLabels: Record<string, string> = {
  companies: "CRM · Companies",
  contacts: "CRM · Contacts",
  leads: "CRM · Leads",
  deals: "CRM · Deals",
  employees: "HRM · Employees",
  departments: "HRM · Departments",
  designations: "HRM · Designations",
  attendance: "HRM · Attendance",
  leave_requests: "HRM · Leave Requests",
  payroll: "HRM · Payroll",
  documents: "HRM · Documents",
  tasks: "Management · Tasks",
  calendar_events: "Management · Calendar",
  automations: "Management · Automations",
  integrations: "Management · Integrations",
  user_roles: "Security · User Roles",
  permissions: "Security · Permissions",
  reports: "Reports",
  settings: "Settings",
};

type ActivityItem = {
  id: string;
  action: string;
  entity_type?: string;
  entity_id?: string;
  details?: any;
  created_at: string;
  user?: { id?: string; full_name?: string } | null;
};

const formatTimeAgo = (dateString: string) => {
  const now = new Date();
  const date = new Date(dateString);
  const diffInMinutes = Math.floor((now.getTime() - date.getTime()) / (1000 * 60));

  if (diffInMinutes < 1) return "Just now";
  if (diffInMinutes < 60) return `${diffInMinutes} min ago`;
  if (diffInMinutes < 1440) return `${Math.floor(diffInMinutes / 60)} hrs ago`;
  return `${Math.floor(diffInMinutes / 1440)} days ago`;
};

const Activities: React.FC = () => {
  const [activities, setActivities] = useState<ActivityItem[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [entityFilter, setEntityFilter] = useState<string>("all");
  const [actionFilter, setActionFilter] = useState<string>("all");
  const { toast } = useToast();

  const fetchActivities = async () => {
    setLoading(true);
    try {
      const filters: any = {};
      if (entityFilter && entityFilter !== "all") filters.entity_type = entityFilter;
      if (actionFilter && actionFilter !== "all") filters.action = actionFilter;

      const data = await activitiesService.getActivities(filters);
      setActivities(data || []);
    } catch (err) {
      console.error("Error fetching activities:", err);
      toast({ title: "Error", description: "Failed to load activities", variant: "destructive" });
      setActivities([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchActivities();
    const interval = setInterval(fetchActivities, 60_000);
    return () => clearInterval(interval);
  }, [entityFilter, actionFilter]);

  const formatActivityDescription = (activity: ActivityItem) => {
    const actionLabel = activityLabels[activity.action] || activity.action;
    const entityLabel = entityLabels[activity.entity_type || ""] || activity.entity_type || "";

    let description = `${actionLabel} ${entityLabel || activity.entity_type || "item"}`;
    if (activity.details) {
      const details = typeof activity.details === "string" ? JSON.parse(activity.details) : activity.details;
      if (details.title) description += `: ${details.title}`;
      if (details.name) description += `: ${details.name}`;
    }
    return description;
  };

  return (
    <div className="px-8 py-6 max-w-6xl">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-black">Activities</h1>
        <p className="text-gray-500 mt-1">Track all actions across CRM and HRM modules</p>
      </div>

      <div className="flex flex-wrap gap-3 mb-6">
        <select value={entityFilter} onChange={(e) => setEntityFilter(e.target.value)} className="px-4 py-2 border rounded-xl text-sm">
          <option value="all">All Modules</option>
          <option value="companies">Companies</option>
          <option value="contacts">Contacts</option>
          <option value="leads">Leads</option>
          <option value="deals">Deals</option>
          <option value="employees">Employees</option>
        </select>
        <select value={actionFilter} onChange={(e) => setActionFilter(e.target.value)} className="px-4 py-2 border rounded-xl text-sm">
          <option value="all">All Types</option>
          <option value="call">Call</option>
          <option value="email">Email</option>
          <option value="task">Task</option>
          <option value="deal">Deal</option>
        </select>
      </div>

      <div className="space-y-4">
        {loading ? (
          <div className="space-y-4">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="flex items-start gap-4 p-4 border rounded-lg">
                <div className="w-10 h-10 bg-muted rounded-full animate-pulse" />
                <div className="flex-1">
                  <div className="h-4 bg-muted rounded w-3/4 animate-pulse mb-2" />
                  <div className="h-3 bg-muted rounded w-1/4 animate-pulse" />
                </div>
              </div>
            ))}
          </div>
        ) : activities.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            <CalendarDays className="h-8 w-8 mx-auto mb-2 opacity-50" />
            <p>No recent activities</p>
          </div>
        ) : (
          activities.map((act) => (
            <div key={act.id} className="flex items-start gap-4 p-4 border rounded-lg">
              <div className="w-10 h-10 flex items-center justify-center bg-muted rounded-full">
                {activityIcons[act.details?.type || act.entity_type || "note"]}
              </div>
              <div className="flex-1">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-medium">{act.action}</h3>
                    <p className="text-sm text-muted-foreground">{formatActivityDescription(act)}</p>
                  </div>
                  <div className="text-xs text-muted-foreground">{formatTimeAgo(act.created_at)}</div>
                </div>
                <div className="mt-2 text-sm text-muted-foreground">{act.user?.full_name || "Unknown User"}</div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default Activities;
