import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Plus, Search, Filter, MoreHorizontal, Edit, Trash2, Building2, User, Phone, Mail, Calendar, FileText, Briefcase, CheckSquare, Paperclip, Eye, StickyNote, Download, Users, ArrowRight, Kanban } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { Checkbox } from "@/components/ui/checkbox";

type Contact = {
  id: string;
  first_name: string;
  last_name: string | null;
  email: string | null;
  phone: string | null;
  position: string | null;
  company_id: string | null;
  notes: string | null;
  created_at: string;
  updated_at: string;
  created_by: string | null;
  companies?: {
    name: string;
  } | null;
};
type Company = {
  id: string;
  name: string;
  email: string | null;
  phone: string | null;
  address: string | null;
  city: string | null;
  country: string | null;
  industry: string | null;
  website: string | null;
  notes: string | null;
  created_at: string;
  updated_at: string;
  created_by: string | null;
};

function ContactForm({
  initialData,
  companies,
  onSubmit,
  onCancel
}: {
  initialData?: Contact;
  companies: Company[];
  onSubmit: (formData: FormData) => void;
  onCancel?: () => void;
}) {
  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    onSubmit(formData);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="first_name">First Name *</Label>
          <Input
            id="first_name"
            name="first_name"
            required
            defaultValue={initialData?.first_name}
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="last_name">Last Name *</Label>
          <Input
            id="last_name"
            name="last_name"
            required
            defaultValue={initialData?.last_name}
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="email">Email</Label>
          <Input
            id="email"
            name="email"
            type="email"
            defaultValue={initialData?.email || ""}
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="phone">Phone</Label>
          <Input
            id="phone"
            name="phone"
            defaultValue={initialData?.phone || ""}
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="position">Position</Label>
          <Input
            id="position"
            name="position"
            defaultValue={initialData?.position || ""}
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="company_id">Company</Label>
          <Select name="company_id" defaultValue={initialData?.company_id || ""}>
            <SelectTrigger>
              <SelectValue placeholder="Select a company" />
            </SelectTrigger>
            <SelectContent>
              {companies.map((company) => (
                <SelectItem key={company.id} value={company.id}>
                  {company.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="notes">Notes</Label>
        <Textarea
          id="notes"
          name="notes"
          defaultValue={initialData?.notes || ""}
          rows={3}
        />
      </div>

      <div className="flex gap-2 pt-4">
        <Button type="submit" className="flex-1">
          {initialData ? "Update Contact" : "Create Contact"}
        </Button>
        {onCancel && (
          <Button type="button" variant="outline" onClick={onCancel}>
            Cancel
          </Button>
        )}
      </div>
    </form>
  );
}

type ActivityLog = {
  id: string;
  action: string;
  details: any | null;
  entity_id: string | null;
  entity_type: string;
  created_at: string;
  user_id: string | null;
};

export default function Contacts() {
  const [contacts, setContacts] = useState<Contact[]>([]);
  const [companies, setCompanies] = useState<Company[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [companyFilter, setCompanyFilter] = useState<string>("all");
  const [dateFilter, setDateFilter] = useState<string>("all");
  const [ownerFilter, setOwnerFilter] = useState<string>("all");
  const [viewMode, setViewMode] = useState<"table" | "kanban">("table");
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [editingContact, setEditingContact] = useState<Contact | null>(null);
  const [selectedContact, setSelectedContact] = useState<Contact | null>(null);
  const [isDetailSheetOpen, setIsDetailSheetOpen] = useState(false);
  const [selectedContacts, setSelectedContacts] = useState<Set<string>>(new Set());
  const [isBulkActionDialogOpen, setIsBulkActionDialogOpen] = useState(false);
  const [bulkActionType, setBulkActionType] = useState<string>("");
  const [bulkAssignee, setBulkAssignee] = useState<string>("");
  const [bulkStatus, setBulkStatus] = useState<string>("");
  const [activityLogs, setActivityLogs] = useState<ActivityLog[]>([]);
  const [users, setUsers] = useState<Array<{id: string, full_name: string}>>([]);
  const [usersMap, setUsersMap] = useState<Record<string, string>>({});
  const [hasMore, setHasMore] = useState(true);
  const [page, setPage] = useState(0);
  const { toast } = useToast();

  useEffect(() => {
    fetchContacts();
    fetchCompanies();
  }, []);

  const fetchContacts = async () => {
    try {
      const { data, error } = await supabase
        .from('contacts')
        .select(`
          *,
          companies (
            name
          )
        `)
        .order('first_name');

      if (error) throw error;
      setContacts(data || []);
    } catch (error) {
      console.error('Error fetching contacts:', error);
      toast({
        title: "Error",
        description: "Failed to fetch contacts",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const fetchCompanies = async () => {
    try {
      const { data, error } = await supabase
        .from('companies')
        .select('*')
        .order('name');

      if (error) throw error;
      setCompanies(data || []);
    } catch (error) {
      console.error('Error fetching companies:', error);
    }
  };



  const filteredContacts = contacts.filter((contact) => {
    const fullName = `${contact.first_name} ${contact.last_name}`;
    const matchesSearch =
      fullName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      contact.email?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      contact.phone?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      contact.position?.toLowerCase().includes(searchTerm.toLowerCase());

    return matchesSearch;
  });

  const handleCreateContact = async (formData: FormData) => {
    try {
      const contactData = {
        first_name: formData.get('first_name') as string,
        last_name: formData.get('last_name') as string,
        email: formData.get('email') as string,
        phone: formData.get('phone') as string,
        position: formData.get('position') as string,
        company_id: formData.get('company_id') as string,
        notes: formData.get('notes') as string,
      };

      const { error } = await supabase
        .from('contacts')
        .insert([contactData]);

      if (error) throw error;

      toast({
        title: "Success",
        description: "Contact created successfully",
      });

      setIsCreateDialogOpen(false);
      fetchContacts();
    } catch (error) {
      console.error('Error creating contact:', error);
      toast({
        title: "Error",
        description: "Failed to create contact",
        variant: "destructive",
      });
    }
  };

  const handleUpdateContact = async (formData: FormData) => {
    if (!editingContact) return;

    try {
      const contactData = {
        first_name: formData.get('first_name') as string,
        last_name: formData.get('last_name') as string,
        email: formData.get('email') as string,
        phone: formData.get('phone') as string,
        position: formData.get('position') as string,
        company_id: formData.get('company_id') as string,
        notes: formData.get('notes') as string,
      };

      const { error } = await supabase
        .from('contacts')
        .update(contactData)
        .eq('id', editingContact.id);

      if (error) throw error;

      toast({
        title: "Success",
        description: "Contact updated successfully",
      });

      setEditingContact(null);
      fetchContacts();
    } catch (error) {
      console.error('Error updating contact:', error);
      toast({
        title: "Error",
        description: "Failed to update contact",
        variant: "destructive",
      });
    }
  };

  const handleDeleteContact = async (contactId: string) => {
    try {
      const { error } = await supabase
        .from('contacts')
        .delete()
        .eq('id', contactId);

      if (error) throw error;

      toast({
        title: "Success",
        description: "Contact deleted successfully",
      });

      fetchContacts();
    } catch (error) {
      console.error('Error deleting contact:', error);
      toast({
        title: "Error",
        description: "Failed to delete contact",
        variant: "destructive",
      });
    }
  };

  const handleLogCall = (contact: Contact) => {
    // TODO: Implement log call functionality
    toast({
      title: "Feature Coming Soon",
      description: "Log call functionality will be implemented soon",
    });
  };

  const handleLogEmail = (contact: Contact) => {
    // TODO: Implement log email functionality
    toast({
      title: "Feature Coming Soon",
      description: "Log email functionality will be implemented soon",
    });
  };

  const handleAddNotes = (contact: Contact) => {
    // TODO: Implement add notes functionality
    toast({
      title: "Feature Coming Soon",
      description: "Add notes functionality will be implemented soon",
    });
  };

  const handleCreateDeal = (contact: Contact) => {
    // TODO: Implement create deal functionality
    toast({
      title: "Feature Coming Soon",
      description: "Create deal functionality will be implemented soon",
    });
  };

  const handleCreateTask = (contact: Contact) => {
    // TODO: Implement create task functionality
    toast({
      title: "Feature Coming Soon",
      description: "Create task functionality will be implemented soon",
    });
  };

  const handleExport = () => {
    try {
      // Create CSV content
      const headers = ["First Name", "Last Name", "Email", "Phone", "Position", "Company", "Created Date", "Notes"];
      const csvContent = [
        headers.join(","),
        ...filteredContacts.map(contact => [
          `"${contact.first_name}"`,
          `"${contact.last_name || ""}"`,
          `"${contact.email || ""}"`,
          `"${contact.phone || ""}"`,
          `"${contact.position || ""}"`,
          `"${contact.companies?.name || ""}"`,
          `"${new Date(contact.created_at).toLocaleDateString()}"`,
          `"${contact.notes || ""}"`
        ].join(","))
      ].join("\n");

      // Create and download the file
      const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
      const link = document.createElement("a");
      const url = URL.createObjectURL(blob);
      link.setAttribute("href", url);
      link.setAttribute("download", `contacts_export_${new Date().toISOString().split('T')[0]}.csv`);
      link.style.visibility = "hidden";
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);

      toast({
        title: "Success",
        description: "Contacts exported successfully",
      });
    } catch (error) {
      console.error('Error exporting contacts:', error);
      toast({
        title: "Error",
        description: "Failed to export contacts",
        variant: "destructive",
      });
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
          <p className="mt-2 text-muted-foreground">Loading contacts...</p>
        </div>
      </div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-6"
    >
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Contacts</h1>
          <p className="text-muted-foreground">
            Manage your business contacts and relationships
          </p>
        </div>
        <div className="flex gap-2">
          {selectedContacts.size > 0 && (
            <div className="flex items-center gap-2">
              <span className="text-sm text-muted-foreground">
                {selectedContacts.size} selected
              </span>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setSelectedContacts(new Set())}
              >
                Clear
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  setBulkActionType("delete");
                  setIsBulkActionDialogOpen(true);
                }}
              >
                <Trash2 className="h-4 w-4 mr-2" />
                Delete
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  setBulkActionType("assign");
                  setIsBulkActionDialogOpen(true);
                }}
              >
                <User className="h-4 w-4 mr-2" />
                Assign
              </Button>
            </div>
          )}
          <Button variant="outline" size="sm">
            <Download className="h-4 w-4 mr-2" />
            Export
          </Button>
          <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="h-4 w-4 mr-2" />
                Add Contact
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-md">
              <DialogHeader>
                <DialogTitle>Create New Contact</DialogTitle>
              </DialogHeader>
              <ContactForm
                companies={companies}
                onSubmit={handleCreateContact}
              />
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Search and Filters */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search contacts..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={companyFilter} onValueChange={setCompanyFilter}>
              <SelectTrigger className="w-full sm:w-48">
                <SelectValue placeholder="Filter by company" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Companies</SelectItem>
                {companies.map((company) => (
                  <SelectItem key={company.id} value={company.id}>
                    {company.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={ownerFilter} onValueChange={setOwnerFilter}>
              <SelectTrigger className="w-full sm:w-48">
                <SelectValue placeholder="Filter by owner" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Owners</SelectItem>
                {users.map((user) => (
                  <SelectItem key={user.id} value={user.id}>
                    {user.full_name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={dateFilter} onValueChange={setDateFilter}>
              <SelectTrigger className="w-full sm:w-48">
                <SelectValue placeholder="Filter by date" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Time</SelectItem>
                <SelectItem value="today">Today</SelectItem>
                <SelectItem value="week">This Week</SelectItem>
                <SelectItem value="month">This Month</SelectItem>
                <SelectItem value="quarter">This Quarter</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Contacts Table */}
      <Card className="flex flex-col h-[calc(100vh-12rem)]">
        <CardHeader className="flex-shrink-0">
          <CardTitle>All Contacts ({filteredContacts.length})</CardTitle>
        </CardHeader>
        <CardContent className="flex-1 overflow-hidden p-0">
          <div className="h-full overflow-y-auto">
            <Table>
              <TableHeader className="sticky top-0 bg-background z-10">
                <TableRow>
                  <TableHead className="w-12">
                    <Checkbox
                      checked={selectedContacts.size === filteredContacts.length && filteredContacts.length > 0}
                      onCheckedChange={(checked) => {
                        if (checked) {
                          setSelectedContacts(new Set(filteredContacts.map(contact => contact.id)));
                        } else {
                          setSelectedContacts(new Set());
                        }
                      }}
                    />
                  </TableHead>
                  <TableHead>Name</TableHead>
                  <TableHead>Email</TableHead>
                  <TableHead>Phone</TableHead>
                  <TableHead>Role</TableHead>
                  <TableHead>Company</TableHead>
                  <TableHead>Last Contacted</TableHead>
                  <TableHead>Owner</TableHead>
                  <TableHead className="w-12">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredContacts.map((contact) => (
                  <TableRow key={contact.id}>
                    <TableCell>
                      <Checkbox
                        checked={selectedContacts.has(contact.id)}
                        onCheckedChange={(checked) => {
                          const newSelected = new Set(selectedContacts);
                          if (checked) {
                            newSelected.add(contact.id);
                          } else {
                            newSelected.delete(contact.id);
                          }
                          setSelectedContacts(newSelected);
                        }}
                      />
                    </TableCell>
                    <TableCell className="font-medium">
                      {contact.first_name} {contact.last_name}
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <Mail className="h-4 w-4 text-muted-foreground" />
                        {contact.email}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <Phone className="h-4 w-4 text-muted-foreground" />
                        {contact.phone}
                      </div>
                    </TableCell>
                    <TableCell>{contact.position}</TableCell>
                    <TableCell>
                      {contact.companies?.name && (
                        <div className="flex items-center gap-2">
                          <Building2 className="h-4 w-4 text-muted-foreground" />
                          {contact.companies.name}
                        </div>
                      )}
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <Calendar className="h-4 w-4 text-muted-foreground" />
                        {contact.updated_at ? new Date(contact.updated_at).toLocaleDateString() : 'Never'}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <User className="h-4 w-4 text-muted-foreground" />
                        Unassigned
                      </div>
                    </TableCell>
                    <TableCell>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="sm">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => {
                            setSelectedContact(contact);
                            setIsDetailSheetOpen(true);
                          }}>
                            <Eye className="h-4 w-4 mr-2" />
                            View Contact
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => setEditingContact(contact)}>
                            <Edit className="h-4 w-4 mr-2" />
                            Edit Contact
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => handleLogCall(contact)}>
                            <Phone className="h-4 w-4 mr-2" />
                            Log Call
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => handleLogEmail(contact)}>
                            <Mail className="h-4 w-4 mr-2" />
                            Log Email
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => handleAddNotes(contact)}>
                            <StickyNote className="h-4 w-4 mr-2" />
                            Add Notes
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => handleCreateDeal(contact)}>
                            <Briefcase className="h-4 w-4 mr-2" />
                            Create Deal
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => handleCreateTask(contact)}>
                            <CheckSquare className="h-4 w-4 mr-2" />
                            Create Task
                          </DropdownMenuItem>
                          <DropdownMenuItem
                            onClick={() => handleDeleteContact(contact.id)}
                            className="text-destructive"
                          >
                            <Trash2 className="h-4 w-4 mr-2" />
                            Delete
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>

            {filteredContacts.length === 0 && (
              <div className="text-center py-8">
                <p className="text-muted-foreground">No contacts found</p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Edit Dialog */}
      <Dialog open={!!editingContact} onOpenChange={() => setEditingContact(null)}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Edit Contact</DialogTitle>
          </DialogHeader>
          {editingContact && (
            <ContactForm
              initialData={editingContact}
              companies={companies}
              onSubmit={handleUpdateContact}
              onCancel={() => setEditingContact(null)}
            />
          )}
        </DialogContent>
      </Dialog>

      {/* Bulk Action Dialog */}
      <Dialog open={isBulkActionDialogOpen} onOpenChange={setIsBulkActionDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>
              {bulkActionType === "delete" ? "Delete Contacts" : "Assign Contacts"}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            {bulkActionType === "delete" ? (
              <div>
                <p className="text-sm text-muted-foreground">
                  Are you sure you want to delete {selectedContacts.size} contact{selectedContacts.size > 1 ? 's' : ''}?
                  This action cannot be undone.
                </p>
                <div className="flex gap-2 pt-4">
                  <Button
                    variant="destructive"
                    onClick={async () => {
                      try {
                        const { error } = await supabase
                          .from('contacts')
                          .delete()
                          .in('id', Array.from(selectedContacts));

                        if (error) throw error;

                        toast({
                          title: "Success",
                          description: `${selectedContacts.size} contact${selectedContacts.size > 1 ? 's' : ''} deleted successfully`,
                        });

                        setSelectedContacts(new Set());
                        setIsBulkActionDialogOpen(false);
                        fetchContacts();
                      } catch (error) {
                        console.error('Error deleting contacts:', error);
                        toast({
                          title: "Error",
                          description: "Failed to delete contacts",
                          variant: "destructive",
                        });
                      }
                    }}
                    className="flex-1"
                  >
                    Delete
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => setIsBulkActionDialogOpen(false)}
                  >
                    Cancel
                  </Button>
                </div>
              </div>
            ) : (
              <div>
                <div className="space-y-2">
                  <Label htmlFor="bulk_assignee">Assign to</Label>
                  <Select value={bulkAssignee} onValueChange={setBulkAssignee}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select a user" />
                    </SelectTrigger>
                    <SelectContent>
                      {users.map((user) => (
                        <SelectItem key={user.id} value={user.id}>
                          {user.full_name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="flex gap-2 pt-4">
                  <Button
                    onClick={async () => {
                      if (!bulkAssignee) {
                        toast({
                          title: "Error",
                          description: "Please select a user to assign",
                          variant: "destructive",
                        });
                        return;
                      }

                      try {
                        const { error } = await supabase
                          .from('contacts')
                          .update({ created_by: bulkAssignee })
                          .in('id', Array.from(selectedContacts));

                        if (error) throw error;

                        toast({
                          title: "Success",
                          description: `${selectedContacts.size} contact${selectedContacts.size > 1 ? 's' : ''} assigned successfully`,
                        });

                        setSelectedContacts(new Set());
                        setIsBulkActionDialogOpen(false);
                        setBulkAssignee("");
                        fetchContacts();
                      } catch (error) {
                        console.error('Error assigning contacts:', error);
                        toast({
                          title: "Error",
                          description: "Failed to assign contacts",
                          variant: "destructive",
                        });
                      }
                    }}
                    className="flex-1"
                  >
                    Assign
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => setIsBulkActionDialogOpen(false)}
                  >
                    Cancel
                  </Button>
                </div>
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>

      {/* Contact Detail Sheet */}
      <Sheet open={isDetailSheetOpen} onOpenChange={setIsDetailSheetOpen}>
        <SheetContent className="w-full sm:max-w-2xl overflow-y-auto">
          <SheetHeader>
            <SheetTitle>Contact Details</SheetTitle>
          </SheetHeader>
          {selectedContact && (
            <div className="space-y-6 mt-6">
              {/* Contact Info */}
              <Card>
                <CardHeader>
                  <CardTitle>Contact Information</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label className="text-sm font-medium">Name</Label>
                      <p className="text-sm text-muted-foreground">
                        {selectedContact.first_name} {selectedContact.last_name}
                      </p>
                    </div>
                    <div>
                      <Label className="text-sm font-medium">Company</Label>
                      <p className="text-sm text-muted-foreground">
                        {selectedContact.companies?.name || 'N/A'}
                      </p>
                    </div>
                    <div>
                      <Label className="text-sm font-medium">Email</Label>
                      <p className="text-sm text-muted-foreground">
                        {selectedContact.email || 'N/A'}
                      </p>
                    </div>
                    <div>
                      <Label className="text-sm font-medium">Phone</Label>
                      <p className="text-sm text-muted-foreground">
                        {selectedContact.phone || 'N/A'}
                      </p>
                    </div>
                    <div>
                      <Label className="text-sm font-medium">Role</Label>
                      <p className="text-sm text-muted-foreground">
                        {selectedContact.position || 'N/A'}
                      </p>
                    </div>
                    <div>
                      <Label className="text-sm font-medium">Last Contacted</Label>
                      <p className="text-sm text-muted-foreground">
                        {selectedContact.updated_at ? new Date(selectedContact.updated_at).toLocaleDateString() : 'Never'}
                      </p>
                    </div>
                  </div>
                  {selectedContact.notes && (
                    <div>
                      <Label className="text-sm font-medium">Notes</Label>
                      <p className="text-sm text-muted-foreground mt-1">
                        {selectedContact.notes}
                      </p>
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Timeline */}
              <Card>
                <CardHeader>
                  <CardTitle>Timeline</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-start gap-3">
                      <div className="w-2 h-2 bg-blue-500 rounded-full mt-2"></div>
                      <div className="flex-1">
                        <p className="text-sm font-medium">Contact Created</p>
                        <p className="text-xs text-muted-foreground">
                          {new Date(selectedContact.created_at).toLocaleString()}
                        </p>
                      </div>
                    </div>
                    <div className="text-center py-4 text-muted-foreground text-sm">
                      No additional activities yet
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Linked Deals */}
              <Card>
                <CardHeader>
                  <CardTitle>Linked Deals</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-center py-4 text-muted-foreground text-sm">
                    No deals linked to this contact
                  </div>
                </CardContent>
              </Card>

              {/* Linked Tasks */}
              <Card>
                <CardHeader>
                  <CardTitle>Linked Tasks</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-center py-4 text-muted-foreground text-sm">
                    No tasks linked to this contact
                  </div>
                </CardContent>
              </Card>

              {/* Files/Documents */}
              <Card>
                <CardHeader>
                  <CardTitle>Files & Documents</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-center py-4 text-muted-foreground text-sm">
                    No files attached to this contact
                  </div>
                </CardContent>
              </Card>
            </div>
          )}
        </SheetContent>
      </Sheet>
    </motion.div>
  );
}
