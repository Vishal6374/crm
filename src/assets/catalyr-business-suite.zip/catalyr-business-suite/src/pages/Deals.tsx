import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Plus, Search, MoreHorizontal, Edit, Trash2, Building2, DollarSign, TrendingUp, Calendar, Filter, Eye, StickyNote, Download, Users, Kanban, User, Phone, Mail, CheckSquare, Square } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import type { Database } from "@/integrations/supabase/types";
import { Checkbox } from "@/components/ui/checkbox";

type Deal = Database['public']['Tables']['deals']['Row'] & {
  companies?: { name: string };
};
type Company = Database['public']['Tables']['companies']['Row'];

const stageColors = {
  lead: "bg-gray-100 text-gray-800",
  qualified: "bg-purple-100 text-purple-800",
  proposal: "bg-blue-100 text-blue-800",
  negotiation: "bg-yellow-100 text-yellow-800",
  won: "bg-green-100 text-green-800",
  lost: "bg-red-100 text-red-800",
};

const stageLabels = {
  lead: "Lead",
  qualified: "Qualified",
  proposal: "Proposal",
  negotiation: "Negotiation",
  won: "Won",
  lost: "Lost",
};

function DealForm({
  initialData,
  companies,
  onSubmit,
  onCancel
}: {
  initialData?: Deal;
  companies: Company[];
  onSubmit: (formData: FormData) => void;
  onCancel?: () => void;
}) {
  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    onSubmit(formData);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="title">Deal Title *</Label>
        <Input
          id="title"
          name="title"
          required
          defaultValue={initialData?.title}
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="company_id">Company *</Label>
        <Select name="company_id" defaultValue={initialData?.company_id || ""} required>
          <SelectTrigger>
            <SelectValue placeholder="Select a company" />
          </SelectTrigger>
          <SelectContent>
            {companies.map((company) => (
              <SelectItem key={company.id} value={company.id}>
                {company.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-2">
        <Label htmlFor="value">Value ($)</Label>
        <Input
          id="value"
          name="value"
          type="number"
          step="0.01"
          min="0"
          defaultValue={initialData?.value || ""}
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="stage">Stage</Label>
        <Select name="stage" defaultValue={initialData?.stage || "lead"}>
          <SelectTrigger>
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="lead">Lead</SelectItem>
            <SelectItem value="qualified">Qualified</SelectItem>
            <SelectItem value="proposal">Proposal</SelectItem>
            <SelectItem value="negotiation">Negotiation</SelectItem>
            <SelectItem value="won">Won</SelectItem>
            <SelectItem value="lost">Lost</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-2">
        <Label htmlFor="expected_close_date">Expected Close Date</Label>
        <Input
          id="expected_close_date"
          name="expected_close_date"
          type="date"
          defaultValue={initialData?.expected_close_date || ""}
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="notes">Notes</Label>
        <Textarea
          id="notes"
          name="notes"
          defaultValue={initialData?.notes || ""}
          rows={3}
        />
      </div>

      <div className="flex gap-2 pt-4">
        <Button type="submit" className="flex-1">
          {initialData ? "Update Deal" : "Create Deal"}
        </Button>
        {onCancel && (
          <Button type="button" variant="outline" onClick={onCancel}>
            Cancel
          </Button>
        )}
      </div>
    </form>
  );
}

type ActivityLog = Database['public']['Tables']['activity_logs']['Row'];

export default function Deals() {
  const [deals, setDeals] = useState<Deal[]>([]);
  const [companies, setCompanies] = useState<Company[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [stageFilter, setStageFilter] = useState<string>("all");
  const [ownerFilter, setOwnerFilter] = useState<string>("all");
  const [dateFilter, setDateFilter] = useState<string>("all");
  const [viewMode, setViewMode] = useState<"table" | "kanban">("table");
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [editingDeal, setEditingDeal] = useState<Deal | null>(null);
  const [selectedDeal, setSelectedDeal] = useState<Deal | null>(null);
  const [isDetailSheetOpen, setIsDetailSheetOpen] = useState(false);
  const [selectedDeals, setSelectedDeals] = useState<Set<string>>(new Set());
  const [isBulkActionDialogOpen, setIsBulkActionDialogOpen] = useState(false);
  const [bulkActionType, setBulkActionType] = useState<string>("");
  const [bulkAssignee, setBulkAssignee] = useState<string>("");
  const [bulkStatus, setBulkStatus] = useState<string>("");
  const [activityLogs, setActivityLogs] = useState<ActivityLog[]>([]);
  const [users, setUsers] = useState<Array<{id: string, full_name: string}>>([]);
  const [usersMap, setUsersMap] = useState<Record<string, string>>({});
  const [hasMore, setHasMore] = useState(true);
  const [page, setPage] = useState(0);
  const [sourceFilter, setSourceFilter] = useState<string>("all");
  const { toast } = useToast();

  useEffect(() => {
    fetchDeals();
    fetchCompanies();
    fetchUsers();
  }, []);

  const fetchDeals = async () => {
    try {
      const { data, error } = await supabase
        .from('deals')
        .select(`
          *,
          companies (
            name
          )
        `)
        .order('created_at', { ascending: false })
        .range(page * 50, (page + 1) * 50 - 1);

      if (error) throw error;

      if (page === 0) {
        setDeals(data || []);
      } else {
        setDeals(prev => [...prev, ...(data || [])]);
      }

      setHasMore((data || []).length === 50);
    } catch (error) {
      console.error('Error fetching deals:', error);
      toast({
        title: "Error",
        description: "Failed to fetch deals",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const fetchCompanies = async () => {
    try {
      const { data, error } = await supabase
        .from('companies')
        .select('*')
        .order('name');

      if (error) throw error;
      setCompanies(data || []);
    } catch (error) {
      console.error('Error fetching companies:', error);
    }
  };

  const fetchActivityLogs = async (dealId: string) => {
    try {
      const { data, error } = await supabase
        .from('activity_logs')
        .select('*')
        .eq('entity_type', 'deal')
        .eq('entity_id', dealId)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setActivityLogs(data || []);
    } catch (error) {
      console.error('Error fetching activity logs:', error);
    }
  };

  const fetchUsers = async () => {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('id, full_name')
        .order('full_name');

      if (error) throw error;
      setUsers(data || []);
      const userMap: Record<string, string> = {};
      (data || []).forEach(user => {
        userMap[user.id] = user.full_name;
      });
      setUsersMap(userMap);
    } catch (error) {
      console.error('Error fetching users:', error);
    }
  };

  const filteredDeals = deals.filter((deal) => {
    const matchesSearch =
      deal.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      deal.companies?.name?.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesStage = stageFilter === "all" || deal.stage === stageFilter;
    const matchesOwner = ownerFilter === "all" || deal.assigned_to === ownerFilter;

    // Date filtering logic
    let matchesDate = true;
    if (dateFilter !== "all") {
      const dealDate = new Date(deal.created_at);
      const now = new Date();
      const daysDiff = Math.floor((now.getTime() - dealDate.getTime()) / (1000 * 3600 * 24));

      switch (dateFilter) {
        case "today":
          matchesDate = daysDiff === 0;
          break;
        case "week":
          matchesDate = daysDiff <= 7;
          break;
        case "month":
          matchesDate = daysDiff <= 30;
          break;
        default:
          matchesDate = true;
      }
    }

    return matchesSearch && matchesStage && matchesOwner && matchesDate;
  });

  const totalValue = deals.reduce((sum, deal) => sum + (deal.value || 0), 0);
  const wonValue = deals
    .filter((deal) => deal.stage === "won")
    .reduce((sum, deal) => sum + (deal.value || 0), 0);

  const handleCreateDeal = async (formData: FormData) => {
    try {
      const dealData = {
        title: formData.get('title') as string,
        company_id: formData.get('company_id') as string,
        value: parseFloat(formData.get('value') as string) || null,
        stage: formData.get('stage') as string as Deal['stage'],
        expected_close_date: formData.get('expected_close_date') as string || null,
        notes: formData.get('notes') as string,
      };

      const { error } = await supabase
        .from('deals')
        .insert([dealData]);

      if (error) throw error;

      toast({
        title: "Success",
        description: "Deal created successfully",
      });

      setIsCreateDialogOpen(false);
      fetchDeals();
    } catch (error) {
      console.error('Error creating deal:', error);
      toast({
        title: "Error",
        description: "Failed to create deal",
        variant: "destructive",
      });
    }
  };

  const handleUpdateDeal = async (formData: FormData) => {
    if (!editingDeal) return;

    try {
      const dealData = {
        title: formData.get('title') as string,
        company_id: formData.get('company_id') as string,
        value: parseFloat(formData.get('value') as string) || null,
        stage: formData.get('stage') as string as Deal['stage'],
        expected_close_date: formData.get('expected_close_date') as string || null,
        notes: formData.get('notes') as string,
      };

      const { error } = await supabase
        .from('deals')
        .update(dealData)
        .eq('id', editingDeal.id);

      if (error) throw error;

      toast({
        title: "Success",
        description: "Deal updated successfully",
      });

      setEditingDeal(null);
      fetchDeals();
    } catch (error) {
      console.error('Error updating deal:', error);
      toast({
        title: "Error",
        description: "Failed to update deal",
        variant: "destructive",
      });
    }
  };

  const handleDeleteDeal = async (dealId: string) => {
    try {
      const { error } = await supabase
        .from('deals')
        .delete()
        .eq('id', dealId);

      if (error) throw error;

      toast({
        title: "Success",
        description: "Deal deleted successfully",
      });

      fetchDeals();
    } catch (error) {
      console.error('Error deleting deal:', error);
      toast({
        title: "Error",
        description: "Failed to delete deal",
        variant: "destructive",
      });
    }
  };

  const handleExport = () => {
    try {
      // Create CSV content
      const headers = ["Deal Title", "Company", "Value", "Stage", "Assigned To", "Expected Close Date", "Created Date", "Notes"];
      const csvContent = [
        headers.join(","),
        ...filteredDeals.map(deal => [
          `"${deal.title}"`,
          `"${deal.companies?.name || ""}"`,
          `"${deal.value || ""}"`,
          `"${stageLabels[deal.stage]}"`,
          `"${deal.assigned_to ? usersMap[deal.assigned_to] || deal.assigned_to : "Unassigned"}"`,
          `"${deal.expected_close_date || ""}"`,
          `"${new Date(deal.created_at).toLocaleDateString()}"`,
          `"${deal.notes || ""}"`
        ].join(","))
      ].join("\n");

      // Create and download the file
      const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
      const link = document.createElement("a");
      const url = URL.createObjectURL(blob);
      link.setAttribute("href", url);
      link.setAttribute("download", `deals_export_${new Date().toISOString().split('T')[0]}.csv`);
      link.style.visibility = "hidden";
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);

      toast({
        title: "Success",
        description: "Deals exported successfully",
      });
    } catch (error) {
      console.error('Error exporting deals:', error);
      toast({
        title: "Error",
        description: "Failed to export deals",
        variant: "destructive",
      });
    }
  };

  const handleBulkAction = async () => {
    if (selectedDeals.size === 0) return;

    try {
      const dealIds = Array.from(selectedDeals);

      if (bulkActionType === "delete") {
        const { error } = await supabase
          .from('deals')
          .delete()
          .in('id', dealIds);

        if (error) throw error;

        toast({
          title: "Success",
          description: `${dealIds.length} deal(s) deleted successfully`,
        });
      } else if (bulkActionType === "stage") {
        const { error } = await supabase
          .from('deals')
          .update({ stage: bulkStatus as Deal['stage'] })
          .in('id', dealIds);

        if (error) throw error;

        toast({
          title: "Success",
          description: `${dealIds.length} deal(s) updated to ${stageLabels[bulkStatus as keyof typeof stageLabels]} stage`,
        });
      } else if (bulkActionType === "assign") {
        const { error } = await supabase
          .from('deals')
          .update({ assigned_to: bulkAssignee === "unassigned" ? null : bulkAssignee })
          .in('id', dealIds);

        if (error) throw error;

        toast({
          title: "Success",
          description: `${dealIds.length} deal(s) assigned successfully`,
        });
      }

      setSelectedDeals(new Set());
      setIsBulkActionDialogOpen(false);
      setBulkActionType("");
      setBulkAssignee("");
      setBulkStatus("");
      fetchDeals();
    } catch (error) {
      console.error('Error performing bulk action:', error);
      toast({
        title: "Error",
        description: "Failed to perform bulk action",
        variant: "destructive",
      });
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
          <p className="mt-2 text-muted-foreground">Loading deals...</p>
        </div>
      </div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-6"
    >
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Deals</h1>
          <p className="text-muted-foreground">
            Track and manage your sales pipeline
          </p>
        </div>
        <div className="flex gap-2">
          {selectedDeals.size > 0 && (
            <div className="flex items-center gap-2">
              <span className="text-sm text-muted-foreground">
                {selectedDeals.size} selected
              </span>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setSelectedDeals(new Set())}
              >
                Clear
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  setBulkActionType("delete");
                  setIsBulkActionDialogOpen(true);
                }}
              >
                <Trash2 className="h-4 w-4 mr-2" />
                Delete
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  setBulkActionType("stage");
                  setIsBulkActionDialogOpen(true);
                }}
              >
                <Edit className="h-4 w-4 mr-2" />
                Update Stage
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  setBulkActionType("assign");
                  setIsBulkActionDialogOpen(true);
                }}
              >
                <User className="h-4 w-4 mr-2" />
                Assign
              </Button>
            </div>
          )}
          <Button variant="outline" size="sm" onClick={handleExport}>
            <Download className="h-4 w-4 mr-2" />
            Export
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => setViewMode(viewMode === "table" ? "kanban" : "table")}
          >
            <Kanban className="h-4 w-4 mr-2" />
            {viewMode === "table" ? "Kanban" : "Table"}
          </Button>
          <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="h-4 w-4 mr-2" />
                Add Deal
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-md">
              <DialogHeader>
                <DialogTitle>Create New Deal</DialogTitle>
              </DialogHeader>
              <DealForm
                companies={companies}
                onSubmit={handleCreateDeal}
              />
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Pipeline</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">${totalValue.toLocaleString()}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Won Deals</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">${wonValue.toLocaleString()}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Deals</CardTitle>
            <Calendar className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{deals.length}</div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search deals..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={stageFilter} onValueChange={setStageFilter}>
              <SelectTrigger className="w-full sm:w-48">
                <SelectValue placeholder="Filter by stage" />
              </SelectTrigger>
            <SelectContent>
                <SelectItem value="all">All Stages</SelectItem>
                <SelectItem value="lead">Lead</SelectItem>
                <SelectItem value="qualified">Qualified</SelectItem>
                <SelectItem value="proposal">Proposal</SelectItem>
                <SelectItem value="negotiation">Negotiation</SelectItem>
                <SelectItem value="won">Won</SelectItem>
                <SelectItem value="lost">Lost</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>


      {/* Deals Content */}

      {viewMode === "table" ? (

        <Card className="flex flex-col h-[calc(100vh-12rem)]">

          <CardHeader className="flex-shrink-0">

            <CardTitle>All Deals ({filteredDeals.length})</CardTitle>

          </CardHeader>

          <CardContent className="flex-1 overflow-hidden p-0">

            <div className="h-full overflow-y-auto">

              <Table>

                <TableHeader className="sticky top-0 bg-background z-10">

                  <TableRow>

                    <TableHead className="w-12">

                      <Checkbox

                        checked={selectedDeals.size === filteredDeals.length && filteredDeals.length > 0}

                        onCheckedChange={(checked) => {

                          if (checked) {

                            setSelectedDeals(new Set(filteredDeals.map(deal => deal.id)));

                          } else {

                            setSelectedDeals(new Set());

                          }

                        }}

                      />

                    </TableHead>

                    <TableHead>Deal Title</TableHead>

                    <TableHead>Company</TableHead>

                    <TableHead>Value</TableHead>

                    <TableHead>Stage</TableHead>

                    <TableHead>Assigned To</TableHead>

                    <TableHead>Expected Close Date</TableHead>

                    <TableHead className="w-12">Actions</TableHead>

                  </TableRow>

                </TableHeader>

                <TableBody>

                  {filteredDeals.map((deal) => (

                    <TableRow key={deal.id}>

                      <TableCell>

                        <Checkbox

                          checked={selectedDeals.has(deal.id)}

                          onCheckedChange={(checked) => {

                            const newSelected = new Set(selectedDeals);

                            if (checked) {

                              newSelected.add(deal.id);

                            } else {

                              newSelected.delete(deal.id);

                            }

                            setSelectedDeals(newSelected);

                          }}

                        />

                      </TableCell>

                      <TableCell className="font-medium">

                        {deal.title}

                      </TableCell>

                      <TableCell>

                        {deal.companies?.name || '-'}

                      </TableCell>

                      <TableCell>

                        {deal.value ? `$${deal.value.toLocaleString()}` : '-'}

                      </TableCell>

                      <TableCell>

                        <Badge className={stageColors[deal.stage]}>

                          {stageLabels[deal.stage]}

                        </Badge>

                      </TableCell>

                      <TableCell>

                        {deal.assigned_to ? usersMap[deal.assigned_to] || deal.assigned_to : "Unassigned"}

                      </TableCell>

                      <TableCell>

                        {deal.expected_close_date ? new Date(deal.expected_close_date).toLocaleDateString() : '-'}

                      </TableCell>

                      <TableCell>

                        <DropdownMenu>

                          <DropdownMenuTrigger asChild>

                            <Button variant="ghost" size="sm">

                              <MoreHorizontal className="h-4 w-4" />

                            </Button>

                          </DropdownMenuTrigger>

                          <DropdownMenuContent align="end">

                            <DropdownMenuItem onClick={() => {

                              setSelectedDeal(deal);

                              fetchActivityLogs(deal.id);

                              setIsDetailSheetOpen(true);

                            }}>

                              <Eye className="h-4 w-4 mr-2" />

                              View Profile

                            </DropdownMenuItem>

                            <DropdownMenuItem onClick={() => setEditingDeal(deal)}>

                              <Edit className="h-4 w-4 mr-2" />

                              Edit Deal

                            </DropdownMenuItem>

                            <DropdownMenuItem

                              onClick={() => handleDeleteDeal(deal.id)}

                              className="text-destructive"

                            >

                              <Trash2 className="h-4 w-4 mr-2" />

                              Delete

                            </DropdownMenuItem>

                          </DropdownMenuContent>

                        </DropdownMenu>

                      </TableCell>

                    </TableRow>

                  ))}

                </TableBody>

              </Table>



              {filteredDeals.length === 0 && (

                <div className="text-center py-8">

                  <p className="text-muted-foreground">No deals found</p>

                </div>

              )}

            </div>

          </CardContent>

        </Card>

      ) : (

        /* Kanban Pipeline */

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">

          {Object.entries(stageLabels).map(([stageKey, stageLabel]) => {

            const stageDeals = filteredDeals.filter(deal => deal.stage === stageKey);

            const totalValue = stageDeals.reduce((sum, deal) => sum + (deal.value || 0), 0);



            return (

              <Card key={stageKey} className="min-h-96">

                <CardHeader className="pb-3">

                  <CardTitle className="text-sm font-medium flex items-center justify-between">

                    <span>{stageLabel}</span>

                    <Badge variant="secondary" className="text-xs">

                      {stageDeals.length}

                    </Badge>

                  </CardTitle>

                  <p className="text-xs text-muted-foreground">

                    ${totalValue.toLocaleString()}

                  </p>

                </CardHeader>

                <CardContent className="space-y-3">

                  {stageDeals.map((deal) => (

                    <Card

                      key={deal.id}

                      className="cursor-pointer hover:shadow-md transition-shadow"

                      onClick={() => setEditingDeal(deal)}

                    >

                      <CardContent className="p-3">

                        <div className="space-y-2">

                          <h4 className="font-medium text-sm line-clamp-2">{deal.title}</h4>

                          {deal.companies?.name && (

                            <div className="flex items-center gap-1 text-xs text-muted-foreground">

                              <Building2 className="h-3 w-3" />

                              <span className="truncate">{deal.companies.name}</span>

                            </div>

                          )}

                          <div className="flex items-center justify-between">

                            <span className="text-sm font-medium">

                              {deal.value ? `$${deal.value.toLocaleString()}` : '-'}

                            </span>

                            {deal.expected_close_date && (

                              <span className="text-xs text-muted-foreground">

                                {new Date(deal.expected_close_date).toLocaleDateString()}

                              </span>

                            )}

                          </div>

                        </div>

                      </CardContent>

                    </Card>

                  ))}

                  {stageDeals.length === 0 && (

                    <div className="text-center py-8 text-muted-foreground text-sm">

                      No deals in this stage

                    </div>

                  )}

                </CardContent>

              </Card>

            );

          })}

        </div>

      )}


      {/* Edit Dialog */}
      <Dialog open={!!editingDeal} onOpenChange={() => setEditingDeal(null)}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Edit Deal</DialogTitle>
          </DialogHeader>
          {editingDeal && (
            <DealForm
              initialData={editingDeal}
              companies={companies}
              onSubmit={handleUpdateDeal}
              onCancel={() => setEditingDeal(null)}
            />
          )}
        </DialogContent>
      </Dialog>

      {/* Bulk Action Dialog */}
      <Dialog open={isBulkActionDialogOpen} onOpenChange={setIsBulkActionDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>
              {bulkActionType === "delete" && "Delete Selected Deals"}
              {bulkActionType === "stage" && "Update Deal Stage"}
              {bulkActionType === "assign" && "Assign Deals"}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            {bulkActionType === "delete" && (
              <p>Are you sure you want to delete {selectedDeals.size} selected deal(s)? This action cannot be undone.</p>
            )}
            {bulkActionType === "stage" && (
              <div className="space-y-2">
                <Label htmlFor="bulk-stage">Select New Stage</Label>
                <Select value={bulkStatus} onValueChange={setBulkStatus}>
                  <SelectTrigger>
                    <SelectValue placeholder="Choose stage" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="lead">Lead</SelectItem>
                    <SelectItem value="qualified">Qualified</SelectItem>
                    <SelectItem value="proposal">Proposal</SelectItem>
                    <SelectItem value="negotiation">Negotiation</SelectItem>
                    <SelectItem value="won">Won</SelectItem>
                    <SelectItem value="lost">Lost</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            )}
            {bulkActionType === "assign" && (
              <div className="space-y-2">
                <Label htmlFor="bulk-assignee">Assign To</Label>
                <Select value={bulkAssignee} onValueChange={setBulkAssignee}>
                  <SelectTrigger>
                    <SelectValue placeholder="Choose assignee" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="unassigned">Unassigned</SelectItem>
                    {users.map((user) => (
                      <SelectItem key={user.id} value={user.id}>
                        {user.full_name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}
            <div className="flex gap-2 pt-4">
              <Button onClick={handleBulkAction} className="flex-1">
                {bulkActionType === "delete" && "Delete"}
                {bulkActionType === "stage" && "Update Stage"}
                {bulkActionType === "assign" && "Assign"}
              </Button>
              <Button
                type="button"
                variant="outline"
                onClick={() => setIsBulkActionDialogOpen(false)}
              >
                Cancel
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Deal Detail Sheet */}
      <Sheet open={isDetailSheetOpen} onOpenChange={setIsDetailSheetOpen}>
        <SheetContent className="w-full sm:max-w-2xl overflow-y-auto z-[100]">
          <SheetHeader>
            <SheetTitle className="flex items-center gap-2">
              <DollarSign className="h-5 w-5" />
              {selectedDeal?.title}
            </SheetTitle>
          </SheetHeader>
          {selectedDeal && (
            <div className="space-y-6 mt-6">
              {/* Deal Details */}
              <Card>
                <CardHeader>
                  <CardTitle>Deal Details</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 gap-4">
                    <div>
                      <Label className="text-sm font-medium">Company</Label>
                      <p className="text-sm text-muted-foreground">{selectedDeal.companies?.name || 'Not specified'}</p>
                    </div>
                    <div>
                      <Label className="text-sm font-medium">Value</Label>
                      <p className="text-sm text-muted-foreground">
                        {selectedDeal.value ? `$${selectedDeal.value.toLocaleString()}` : 'Not specified'}
                      </p>
                    </div>
                    <div>
                      <Label className="text-sm font-medium">Stage</Label>
                      <Badge className={stageColors[selectedDeal.stage]}>
                        {stageLabels[selectedDeal.stage]}
                      </Badge>
                    </div>
                    <div>
                      <Label className="text-sm font-medium">Assigned To</Label>
                      <p className="text-sm text-muted-foreground">
                        {selectedDeal.assigned_to ? usersMap[selectedDeal.assigned_to] || selectedDeal.assigned_to : 'Unassigned'}
                      </p>
                    </div>
                    <div>
                      <Label className="text-sm font-medium">Expected Close Date</Label>
                      <p className="text-sm text-muted-foreground">
                        {selectedDeal.expected_close_date ? new Date(selectedDeal.expected_close_date).toLocaleDateString() : 'Not specified'}
                      </p>
                    </div>
                    <div>
                      <Label className="text-sm font-medium">Created Date</Label>
                      <p className="text-sm text-muted-foreground">
                        {new Date(selectedDeal.created_at).toLocaleDateString()}
                      </p>
                    </div>
                  </div>
                  <div>
                    <Label className="text-sm font-medium">Notes</Label>
                    <p className="text-sm text-muted-foreground">{selectedDeal.notes || 'No notes available'}</p>
                  </div>
                </CardContent>
              </Card>

              {/* Activity Logs */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <StickyNote className="h-4 w-4" />
                    Activity Logs ({activityLogs.length})
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {activityLogs.length > 0 ? (
                    <div className="space-y-3">
                      {activityLogs.map((log) => (
                        <div key={log.id} className="flex items-start gap-3 p-3 border rounded-lg">
                          <div className="flex-1">
                            <p className="text-sm font-medium">{log.action}</p>
                            <p className="text-xs text-muted-foreground">
                              {new Date(log.created_at).toLocaleString()}
                            </p>
                            {log.details && (
                              <p className="text-xs text-muted-foreground mt-1">{log.details}</p>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-sm text-muted-foreground">No activity logs available.</p>
                  )}
                </CardContent>
              </Card>
            </div>
          )}
        </SheetContent>
      </Sheet>
    </motion.div>
  );
}
