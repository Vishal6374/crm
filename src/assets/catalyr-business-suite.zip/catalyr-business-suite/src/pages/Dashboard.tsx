import { motion } from "framer-motion";
import {
  Users,
  TrendingUp,
  UserCheck,
  Calendar,
  ArrowUpRight,
  ArrowDownRight,
  CheckSquare,
  Plus,
  Clock,
  DollarSign,
  Target,
  Activity,
  BarChart3,
  PieChart,
  TrendingDown,
  Shield,
  Crown,
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { useState, useEffect } from "react";
import { useAuth } from "@/contexts/AuthContext";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar,
  PieChart as RechartsPieChart,
  Pie,
  Cell,
  Area,
  AreaChart,
} from "recharts";

// Recent activities will be loaded from the database

// Sample data for charts
const leadsData = [
  { month: "Jan", leads: 45 },
  { month: "Feb", leads: 52 },
  { month: "Mar", leads: 48 },
  { month: "Apr", leads: 61 },
  { month: "May", leads: 55 },
  { month: "Jun", leads: 67 },
];

const dealPipelineData = [
  { stage: "Prospect", value: 250000, color: "#8884d8" },
  { stage: "Qualification", value: 180000, color: "#82ca9d" },
  { stage: "Proposal", value: 120000, color: "#ffc658" },
  { stage: "Negotiation", value: 80000, color: "#ff7300" },
  { stage: "Closed Won", value: 450000, color: "#00ff00" },
];

const attendanceData = [
  { day: "Mon", present: 28, absent: 4 },
  { day: "Tue", present: 30, absent: 2 },
  { day: "Wed", present: 27, absent: 5 },
  { day: "Thu", present: 29, absent: 3 },
  { day: "Fri", present: 31, absent: 1 },
];

const revenueData = [
  { month: "Jan", revenue: 125000 },
  { month: "Feb", revenue: 145000 },
  { month: "Mar", revenue: 138000 },
  { month: "Apr", revenue: 162000 },
  { month: "May", revenue: 158000 },
  { month: "Jun", revenue: 175000 },
];

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1,
    },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: {
    opacity: 1,
    y: 0,
    transition: {
      duration: 0.4,
    },
  },
};

export default function Dashboard() {
  const { user } = useAuth();
  const [userRole, setUserRole] = useState<string>('employee');
  const [dashboardData, setDashboardData] = useState({
    totalLeads: 0,
    openDealsValue: 0,
    totalEmployees: 0,
    pendingLeaveRequests: 0,
    tasksDueToday: 0,
    leadsData: [] as any[],
    dealPipelineData: [] as any[],
    attendanceData: [] as any[],
    revenueData: [] as any[],
  });
  const [loading, setLoading] = useState(true);
  const [recentActivities, setRecentActivities] = useState<any[]>([]);

  const formatTimeAgo = (dateString: string) => {
    const now = new Date();
    const date = new Date(dateString);
    const diffInMinutes = Math.floor((now.getTime() - date.getTime()) / (1000 * 60));

    if (diffInMinutes < 1) return "Just now";
    if (diffInMinutes < 60) return `${diffInMinutes} min ago`;
    if (diffInMinutes < 1440) return `${Math.floor(diffInMinutes / 60)} hrs ago`;
    return `${Math.floor(diffInMinutes / 1440)} days ago`;
  };

  useEffect(() => {
    // Mock role detection - in real app, this would come from user metadata or database
    // For now, we'll simulate different roles based on email or user ID
    if (user?.email?.includes('admin')) {
      setUserRole('super_admin');
    } else if (user?.email?.includes('hr')) {
      setUserRole('hr');
    } else if (user?.email?.includes('sales')) {
      setUserRole('sales');
    } else if (user?.email?.includes('manager')) {
      setUserRole('manager');
    } else {
      setUserRole('employee');
    }

    fetchDashboardData();
  }, [user]);

  const fetchDashboardData = async () => {
    try {
      setLoading(true);

      // Use sample data for now
      setDashboardData({
        totalLeads: 156,
        openDealsValue: 1250000,
        totalEmployees: 32,
        pendingLeaveRequests: 5,
        tasksDueToday: 8,
        leadsData: leadsData,
        dealPipelineData: dealPipelineData,
        attendanceData: attendanceData,
        revenueData: revenueData,
      });

      // Sample recent activities
      setRecentActivities([
        {
          id: 1,
          action: "Lead converted",
          subject: "John Doe",
          time: "30 min ago",
          type: "lead",
          user: "Jane Smith",
        },
        {
          id: 2,
          action: "Deal updated",
          subject: "ABC Corp Deal",
          time: "2 hours ago",
          type: "deal",
          user: "Bob Johnson",
        },
      ]);

      setLoading(false);
    } catch (error) {
      console.error('Error fetching dashboard data:', error);
      setLoading(false);
    }
  };

  const generateLeadsOverTime = async () => {
    // Return sample data
    return [
      { month: "Jan", leads: 45 },
      { month: "Feb", leads: 52 },
      { month: "Mar", leads: 48 },
      { month: "Apr", leads: 61 },
      { month: "May", leads: 55 },
      { month: "Jun", leads: 67 },
    ];
  };

  const generateDealPipelineData = async () => {
    // Return sample data
    return [
      { stage: "Lead", value: 250000, color: "#8884d8" },
      { stage: "Qualified", value: 180000, color: "#82ca9d" },
      { stage: "Proposal", value: 320000, color: "#ffc658" },
      { stage: "Negotiation", value: 150000, color: "#ff7300" },
      { stage: "Won", value: 450000, color: "#00ff00" },
    ];
  };

  const generateAttendanceData = async () => {
    // Return sample data
    return [
      { day: "Mon", present: 28, absent: 4 },
      { day: "Tue", present: 30, absent: 2 },
      { day: "Wed", present: 27, absent: 5 },
      { day: "Thu", present: 29, absent: 3 },
      { day: "Fri", present: 31, absent: 1 },
    ];
  };

  const generateRevenueData = async () => {
    // Return sample data
    return [
      { month: "Jan", revenue: 125000 },
      { month: "Feb", revenue: 145000 },
      { month: "Mar", revenue: 135000 },
      { month: "Apr", revenue: 165000 },
      { month: "May", revenue: 155000 },
      { month: "Jun", revenue: 175000 },
    ];
  };

  // Role-based stats filtering
  const getRoleBasedStats = () => {
    const allStats = [
      {
        title: "Total Leads",
        value: dashboardData.totalLeads.toString(),
        change: "+12%",
        changeType: "positive" as const,
        icon: Users,
        roles: ['sales', 'manager', 'hr', 'admin', 'super_admin'],
      },
      {
        title: "Open Deals (₹)",
        value: `₹${dashboardData.openDealsValue.toLocaleString()}`,
        change: "+8%",
        changeType: "positive" as const,
        icon: TrendingUp,
        roles: ['sales', 'manager', 'hr', 'admin', 'super_admin'],
      },
      {
        title: "Employees",
        value: dashboardData.totalEmployees.toString(),
        change: "+2",
        changeType: "positive" as const,
        icon: UserCheck,
        roles: ['hr', 'manager', 'admin', 'super_admin'],
      },
      {
        title: "Pending Leave Requests",
        value: dashboardData.pendingLeaveRequests.toString(),
        change: "-3",
        changeType: "negative" as const,
        icon: Calendar,
        roles: ['hr', 'manager', 'admin', 'super_admin'],
      },
      {
        title: "Tasks Due Today",
        value: dashboardData.tasksDueToday.toString(),
        change: "+2",
        changeType: "positive" as const,
        icon: CheckSquare,
        roles: ['employee', 'sales', 'manager', 'hr', 'admin', 'super_admin'],
      },
    ];

    return allStats.filter(stat => stat.roles.includes(userRole));
  };

  // Role-based quick actions
  const getRoleBasedActions = () => {
    const allActions = [
      { label: "Add Lead", href: "/leads", icon: Plus, color: "bg-blue-500", roles: ['sales', 'manager', 'admin', 'super_admin'] },
      { label: "Add Employee", href: "/employees", icon: UserCheck, color: "bg-green-500", roles: ['hr', 'admin', 'super_admin'] },
      { label: "Create Task", href: "/tasks", icon: CheckSquare, color: "bg-purple-500", roles: ['employee', 'sales', 'manager', 'hr', 'admin', 'super_admin'] },
      { label: "Request Leave", href: "/leave", icon: Calendar, color: "bg-orange-500", roles: ['employee', 'sales', 'manager', 'hr', 'admin', 'super_admin'] },
      { label: "View Reports", href: "/reports", icon: BarChart3, color: "bg-indigo-500", roles: ['manager', 'hr', 'admin', 'super_admin'] },
      { label: "Manage Payroll", href: "/payroll", icon: DollarSign, color: "bg-emerald-500", roles: ['hr', 'admin', 'super_admin'] },
    ];

    return allActions.filter(action => action.roles.includes(userRole));
  };

  // Role-based charts visibility
  const canViewCharts = ['manager', 'hr', 'admin', 'super_admin'].includes(userRole);

  const roleStats = getRoleBasedStats();
  const roleActions = getRoleBasedActions();

  return (
    <motion.div
      variants={containerVariants}
      initial="hidden"
      animate="visible"
      className="space-y-8"
    >
      {/* Page Header */}
      <motion.div variants={itemVariants}>
        <h1 className="text-3xl font-bold tracking-tight">Dashboard</h1>
        <p className="text-muted-foreground mt-1">
          Welcome back! Here's what's happening with your business.
        </p>
      </motion.div>

      {/* Stats Grid */}
      <motion.div
        variants={containerVariants}
        className="grid gap-4 md:grid-cols-2 lg:grid-cols-4"
      >
        {roleStats.map((stat, index) => (
          <motion.div key={stat.title} variants={itemVariants}>
            <Card className="stat-card">
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">
                  {stat.title}
                </CardTitle>
                <stat.icon className="h-5 w-5 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold">{stat.value}</div>
                <div className="flex items-center gap-1 mt-1">
                  {stat.changeType === "positive" ? (
                    <ArrowUpRight className="h-4 w-4 text-success" />
                  ) : (
                    <ArrowDownRight className="h-4 w-4 text-destructive" />
                  )}
                  <span
                    className={
                      stat.changeType === "positive"
                        ? "text-sm text-success"
                        : "text-sm text-destructive"
                    }
                  >
                    {stat.change}
                  </span>
                  <span className="text-sm text-muted-foreground">from last month</span>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </motion.div>

      {/* Main Content Grid */}
      <div className="grid gap-6 lg:grid-cols-2">
        {/* Recent Activity */}
        <motion.div variants={itemVariants}>
          <Card>
            <CardHeader>
              <CardTitle>Recent Activity</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recentActivities.map((activity) => (
                  <div
                    key={activity.id}
                    className="flex items-center justify-between py-2 border-b border-border last:border-0"
                  >
                    <div>
                      <p className="text-sm">
                        <span className="text-muted-foreground">{activity.action}</span>{" "}
                        <span className="font-medium">{activity.subject}</span>
                      </p>
                    </div>
                    <span className="text-xs text-muted-foreground">{activity.time}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Quick Actions */}
        <motion.div variants={itemVariants}>
          <Card>
            <CardHeader>
              <CardTitle>Quick Actions</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-3">
                {roleActions.map((action, index) => (
                  <QuickActionButton
                    key={index}
                    label={action.label}
                    href={action.href}
                    icon={action.icon}
                    color={action.color}
                  />
                ))}
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>

      {/* Charts Section */}
      {canViewCharts && (
        <motion.div variants={containerVariants} className="grid gap-6 lg:grid-cols-2">
        {/* Leads Over Time */}
        <motion.div variants={itemVariants}>
          <Card>
            <CardHeader>
              <CardTitle>Leads Over Time</CardTitle>
            </CardHeader>
            <CardContent>
              {loading ? (
                <div className="flex items-center justify-center h-[300px]">
                  <div className="text-muted-foreground">Loading...</div>
                </div>
              ) : (
                <ResponsiveContainer width="100%" height={300}>
                  <AreaChart data={dashboardData.leadsData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="month" />
                    <YAxis />
                    <Tooltip />
                    <Area
                      type="monotone"
                      dataKey="leads"
                      stroke="#8884d8"
                      fill="#8884d8"
                      fillOpacity={0.6}
                    />
                  </AreaChart>
                </ResponsiveContainer>
              )}
            </CardContent>
          </Card>
        </motion.div>

        {/* Deal Pipeline Value */}
        <motion.div variants={itemVariants}>
          <Card>
            <CardHeader>
              <CardTitle>Deal Pipeline Value</CardTitle>
            </CardHeader>
            <CardContent>
              {loading ? (
                <div className="flex items-center justify-center h-[300px]">
                  <div className="text-muted-foreground">Loading...</div>
                </div>
              ) : (
                <ResponsiveContainer width="100%" height={300}>
                  <RechartsPieChart>
                    <Pie
                      data={dashboardData.dealPipelineData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ stage, percent }) => `${stage} ${(percent * 100).toFixed(0)}%`}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                    >
                      {dashboardData.dealPipelineData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip formatter={(value) => [`₹${value.toLocaleString()}`, 'Value']} />
                  </RechartsPieChart>
                </ResponsiveContainer>
              )}
            </CardContent>
          </Card>
        </motion.div>

        {/* Attendance Summary */}
        <motion.div variants={itemVariants}>
          <Card>
            <CardHeader>
              <CardTitle>Attendance Summary (This Week)</CardTitle>
            </CardHeader>
            <CardContent>
              {loading ? (
                <div className="flex items-center justify-center h-[300px]">
                  <div className="text-muted-foreground">Loading...</div>
                </div>
              ) : (
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={dashboardData.attendanceData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="day" />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="present" stackId="a" fill="#82ca9d" />
                    <Bar dataKey="absent" stackId="a" fill="#ff7300" />
                  </BarChart>
                </ResponsiveContainer>
              )}
            </CardContent>
          </Card>
        </motion.div>

        {/* Revenue Trend */}
        <motion.div variants={itemVariants}>
          <Card>
            <CardHeader>
              <CardTitle>Revenue Trend</CardTitle>
            </CardHeader>
            <CardContent>
              {loading ? (
                <div className="flex items-center justify-center h-[300px]">
                  <div className="text-muted-foreground">Loading...</div>
                </div>
              ) : (
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={dashboardData.revenueData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="month" />
                    <YAxis />
                    <Tooltip formatter={(value) => [`₹${value.toLocaleString()}`, 'Revenue']} />
                    <Line
                      type="monotone"
                      dataKey="revenue"
                      stroke="#8884d8"
                      strokeWidth={2}
                    />
                  </LineChart>
                </ResponsiveContainer>
              )}
            </CardContent>
          </Card>
        </motion.div>
      </motion.div>
      )}

      {/* Footer */}
      <motion.footer
        variants={itemVariants}
        className="pt-8 pb-4 border-t border-border text-center text-sm text-muted-foreground"
      >
        <p>© 2025 Catalyr. All rights reserved.</p>
        <div className="flex justify-center gap-4 mt-2">
          <a href="#" className="hover:text-foreground transition-colors">
            Privacy Policy
          </a>
          <a href="#" className="hover:text-foreground transition-colors">
            Terms of Service
          </a>
        </div>
      </motion.footer>
    </motion.div>
  );
}

function QuickActionButton({ label, href, icon: Icon, color }: { label: string; href: string; icon: any; color: string }) {
  return (
    <a
      href={href}
      className={`flex items-center justify-center h-12 px-4 rounded-lg border border-border ${color} text-white text-sm font-medium hover:opacity-90 transition-colors`}
    >
      <Icon className="h-4 w-4 mr-2" />
      {label}
    </a>
  );
}
