import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Plus, Search, Filter, MoreHorizontal, Edit, Trash2, DollarSign, CreditCard, Eye } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import type { Database } from "@/integrations/supabase/types";

type Payroll = Database['public']['Tables']['payroll']['Row'] & {
  employees?: { full_name: string; employee_code: string };
};
type Employee = Database['public']['Tables']['employees']['Row'];

const statusColors = {
  pending: "bg-yellow-100 text-yellow-800",
  paid: "bg-green-100 text-green-800",
};

const statusLabels = {
  pending: "Pending",
  paid: "Paid",
};

function PayrollForm({
  initialData,
  employees,
  onSubmit,
  onCancel
}: {
  initialData?: Payroll;
  employees: Employee[];
  onSubmit: (formData: FormData) => void;
  onCancel?: () => void;
}) {
  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    onSubmit(formData);
  };

  const currentYear = new Date().getFullYear();
  const currentMonth = new Date().getMonth() + 1;

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="employee_id">Employee *</Label>
        <Select name="employee_id" defaultValue={initialData?.employee_id || ""} required>
          <SelectTrigger>
            <SelectValue placeholder="Select employee" />
          </SelectTrigger>
          <SelectContent>
            {employees.map((emp) => (
              <SelectItem key={emp.id} value={emp.id}>
                {emp.full_name} ({emp.employee_code})
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="month">Month *</Label>
          <Select name="month" defaultValue={initialData?.month?.toString() || currentMonth.toString()} required>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="1">January</SelectItem>
              <SelectItem value="2">February</SelectItem>
              <SelectItem value="3">March</SelectItem>
              <SelectItem value="4">April</SelectItem>
              <SelectItem value="5">May</SelectItem>
              <SelectItem value="6">June</SelectItem>
              <SelectItem value="7">July</SelectItem>
              <SelectItem value="8">August</SelectItem>
              <SelectItem value="9">September</SelectItem>
              <SelectItem value="10">October</SelectItem>
              <SelectItem value="11">November</SelectItem>
              <SelectItem value="12">December</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-2">
          <Label htmlFor="year">Year *</Label>
          <Select name="year" defaultValue={initialData?.year?.toString() || currentYear.toString()} required>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {Array.from({ length: 5 }, (_, i) => currentYear - 2 + i).map((year) => (
                <SelectItem key={year} value={year.toString()}>
                  {year}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="basic_salary">Basic Salary *</Label>
        <Input
          id="basic_salary"
          name="basic_salary"
          type="number"
          step="0.01"
          required
          defaultValue={initialData?.basic_salary || ""}
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="bonus">Bonus</Label>
        <Input
          id="bonus"
          name="bonus"
          type="number"
          step="0.01"
          defaultValue={initialData?.bonus || ""}
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="deductions">Deductions</Label>
        <Input
          id="deductions"
          name="deductions"
          type="number"
          step="0.01"
          defaultValue={initialData?.deductions || ""}
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="status">Status *</Label>
        <Select name="status" defaultValue={initialData?.status || "pending"} required>
          <SelectTrigger>
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="pending">Pending</SelectItem>
            <SelectItem value="paid">Paid</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="flex gap-2 pt-4">
        <Button type="submit" className="flex-1">
          {initialData ? "Update Payroll" : "Create Payroll"}
        </Button>
        {onCancel && (
          <Button type="button" variant="outline" onClick={onCancel}>
            Cancel
          </Button>
        )}
      </div>
    </form>
  );
}

export default function Payroll() {
  const [payroll, setPayroll] = useState<Payroll[]>([]);
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [yearFilter, setYearFilter] = useState<string>("all");
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [editingPayroll, setEditingPayroll] = useState<Payroll | null>(null);
  const [viewingPayroll, setViewingPayroll] = useState<Payroll | null>(null);
  const { toast } = useToast();

  useEffect(() => {
    fetchPayroll();
    fetchEmployees();
  }, []);

  const fetchPayroll = async () => {
    try {
      const { data, error } = await supabase
        .from('payroll')
        .select(`
          *,
          employees (
            full_name,
            employee_code
          )
        `)
        .order('year', { ascending: false })
        .order('month', { ascending: false });

      if (error) throw error;
      setPayroll(data || []);
    } catch (error) {
      console.error('Error fetching payroll:', error);
      toast({
        title: "Error",
        description: "Failed to fetch payroll records",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const fetchEmployees = async () => {
    try {
      const { data, error } = await supabase
        .from('employees')
        .select('*')
        .eq('status', 'active')
        .order('full_name');

      if (error) throw error;
      setEmployees(data || []);
    } catch (error) {
      console.error('Error fetching employees:', error);
    }
  };

  const filteredPayroll = payroll.filter((record) => {
    const matchesSearch =
      record.employees?.full_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      record.employees?.employee_code.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesStatus = statusFilter === "all" || record.status === statusFilter;
    const matchesYear = yearFilter === "all" || record.year.toString() === yearFilter;

    return matchesSearch && matchesStatus && matchesYear;
  });

  const handleCreatePayroll = async (formData: FormData) => {
    try {
      const payrollData = {
        employee_id: formData.get('employee_id') as string,
        month: parseInt(formData.get('month') as string),
        year: parseInt(formData.get('year') as string),
        basic_salary: parseFloat(formData.get('basic_salary') as string),
        bonus: formData.get('bonus') ? parseFloat(formData.get('bonus') as string) : null,
        deductions: formData.get('deductions') ? parseFloat(formData.get('deductions') as string) : null,
        status: formData.get('status') as Database['public']['Enums']['payroll_status'],
      };

      // Calculate net salary
      const netSalary = payrollData.basic_salary + (payrollData.bonus || 0) - (payrollData.deductions || 0);

      const { error } = await supabase
        .from('payroll')
        .insert([{ ...payrollData, net_salary: netSalary }]);

      if (error) throw error;

      toast({
        title: "Success",
        description: "Payroll record created successfully",
      });

      setIsCreateDialogOpen(false);
      fetchPayroll();
    } catch (error) {
      console.error('Error creating payroll:', error);
      toast({
        title: "Error",
        description: "Failed to create payroll record",
        variant: "destructive",
      });
    }
  };

  const handleUpdatePayroll = async (formData: FormData) => {
    if (!editingPayroll) return;

    try {
      const payrollData = {
        employee_id: formData.get('employee_id') as string,
        month: parseInt(formData.get('month') as string),
        year: parseInt(formData.get('year') as string),
        basic_salary: parseFloat(formData.get('basic_salary') as string),
        bonus: formData.get('bonus') ? parseFloat(formData.get('bonus') as string) : null,
        deductions: formData.get('deductions') ? parseFloat(formData.get('deductions') as string) : null,
        status: formData.get('status') as Database['public']['Enums']['payroll_status'],
      };

      // Calculate net salary
      const netSalary = payrollData.basic_salary + (payrollData.bonus || 0) - (payrollData.deductions || 0);

      const { error } = await supabase
        .from('payroll')
        .update({ ...payrollData, net_salary: netSalary })
        .eq('id', editingPayroll.id);

      if (error) throw error;

      toast({
        title: "Success",
        description: "Payroll record updated successfully",
      });

      setEditingPayroll(null);
      fetchPayroll();
    } catch (error) {
      console.error('Error updating payroll:', error);
      toast({
        title: "Error",
        description: "Failed to update payroll record",
        variant: "destructive",
      });
    }
  };

  const handleDeletePayroll = async (payrollId: string) => {
    try {
      const { error } = await supabase
        .from('payroll')
        .delete()
        .eq('id', payrollId);

      if (error) throw error;

      toast({
        title: "Success",
        description: "Payroll record deleted successfully",
      });

      fetchPayroll();
    } catch (error) {
      console.error('Error deleting payroll:', error);
      toast({
        title: "Error",
        description: "Failed to delete payroll record",
        variant: "destructive",
      });
    }
  };

  const handleMarkAsPaid = async (payrollId: string) => {
    try {
      const { error } = await supabase
        .from('payroll')
        .update({
          status: 'paid',
          paid_at: new Date().toISOString(),
        })
        .eq('id', payrollId);

      if (error) throw error;

      toast({
        title: "Success",
        description: "Payroll marked as paid",
      });

      fetchPayroll();
    } catch (error) {
      console.error('Error marking payroll as paid:', error);
      toast({
        title: "Error",
        description: "Failed to mark payroll as paid",
        variant: "destructive",
      });
    }
  };

  const getMonthName = (month: number) => {
    const months = [
      'January', 'February', 'March', 'April', 'May', 'June',
      'July', 'August', 'September', 'October', 'November', 'December'
    ];
    return months[month - 1];
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
          <p className="mt-2 text-muted-foreground">Loading payroll records...</p>
        </div>
      </div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-6"
    >
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Payroll</h1>
          <p className="text-muted-foreground">
            Manage employee salaries and payment records
          </p>
        </div>
        <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="h-4 w-4 mr-2" />
              Add Payroll
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>Create Payroll Record</DialogTitle>
            </DialogHeader>
            <PayrollForm
              employees={employees}
              onSubmit={handleCreatePayroll}
            />
          </DialogContent>
        </Dialog>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search by employee name or code..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-full sm:w-48">
                <Filter className="h-4 w-4 mr-2" />
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="pending">Pending</SelectItem>
                <SelectItem value="paid">Paid</SelectItem>
              </SelectContent>
            </Select>
            <Select value={yearFilter} onValueChange={setYearFilter}>
              <SelectTrigger className="w-full sm:w-48">
                <Filter className="h-4 w-4 mr-2" />
                <SelectValue placeholder="Filter by year" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Years</SelectItem>
                {Array.from({ length: 5 }, (_, i) => new Date().getFullYear() - 2 + i).map((year) => (
                  <SelectItem key={year} value={year.toString()}>
                    {year}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Payroll Table */}
      <Card className="flex flex-col h-[calc(100vh-12rem)]">
        <CardHeader className="flex-shrink-0">
          <CardTitle>All Payroll Records ({filteredPayroll.length})</CardTitle>
        </CardHeader>
        <CardContent className="flex-1 overflow-hidden p-0">
          <div className="h-full overflow-y-auto">
            <Table>
              <TableHeader className="sticky top-0 bg-background z-10">
                <TableRow>
                  <TableHead>Employee</TableHead>
                  <TableHead>Month/Year</TableHead>
                  <TableHead>Basic Salary</TableHead>
                  <TableHead>Allowances</TableHead>
                  <TableHead>Deductions</TableHead>
                  <TableHead>Net Salary</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="w-12"></TableHead>
                </TableRow>
              </TableHeader>
            <TableBody>
              {filteredPayroll.map((record) => (
                <TableRow key={record.id}>
                  <TableCell className="font-medium">
                    <div className="flex items-center gap-2">
                      <DollarSign className="h-4 w-4 text-muted-foreground" />
                      {record.employees?.full_name} ({record.employees?.employee_code})
                    </div>
                  </TableCell>
                  <TableCell>
                    {getMonthName(record.month)} {record.year}
                  </TableCell>
                  <TableCell>${record.basic_salary.toFixed(2)}</TableCell>
                  <TableCell>
                    {record.bonus ? `$${record.bonus.toFixed(2)}` : '-'}
                  </TableCell>
                  <TableCell>
                    {record.deductions ? `$${record.deductions.toFixed(2)}` : '-'}
                  </TableCell>
                  <TableCell className="font-semibold">
                    ${record.net_salary.toFixed(2)}
                  </TableCell>
                  <TableCell>
                    <Badge className={statusColors[record.status]}>
                      {statusLabels[record.status]}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="sm">
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        {record.status === 'pending' && (
                          <DropdownMenuItem onClick={() => handleMarkAsPaid(record.id)}>
                            <CreditCard className="h-4 w-4 mr-2" />
                            Mark as Paid
                          </DropdownMenuItem>
                        )}
                        <DropdownMenuItem onClick={() => setViewingPayroll(record)}>
                          <Eye className="h-4 w-4 mr-2" />
                          View Details
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => setEditingPayroll(record)}>
                          <Edit className="h-4 w-4 mr-2" />
                          Edit
                        </DropdownMenuItem>
                        <DropdownMenuItem
                          onClick={() => handleDeletePayroll(record.id)}
                          className="text-destructive"
                        >
                          <Trash2 className="h-4 w-4 mr-2" />
                          Delete
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>

          {filteredPayroll.length === 0 && (
            <div className="text-center py-8">
              <p className="text-muted-foreground">No payroll records found</p>
            </div>
          )}
          </div>
        </CardContent>
      </Card>

      {/* Edit Dialog */}
      <Dialog open={!!editingPayroll} onOpenChange={() => setEditingPayroll(null)}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Edit Payroll Record</DialogTitle>
          </DialogHeader>
          {editingPayroll && (
            <PayrollForm
              initialData={editingPayroll}
              employees={employees}
              onSubmit={handleUpdatePayroll}
              onCancel={() => setEditingPayroll(null)}
            />
          )}
        </DialogContent>
      </Dialog>

      {/* View Payroll Sheet */}
      <Sheet open={!!viewingPayroll} onOpenChange={() => setViewingPayroll(null)}>
        <SheetContent className="w-full sm:max-w-2xl overflow-y-auto">
          <SheetHeader>
            <SheetTitle className="flex items-center gap-2">
              <DollarSign className="h-5 w-5" />
              Payroll Details
            </SheetTitle>
          </SheetHeader>
          {viewingPayroll && (
            <div className="space-y-6 mt-6">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-sm font-medium text-muted-foreground">Employee</Label>
                  <p className="text-sm font-medium">{viewingPayroll.employees?.full_name} ({viewingPayroll.employees?.employee_code})</p>
                </div>
                <div>
                  <Label className="text-sm font-medium text-muted-foreground">Period</Label>
                  <p className="text-sm font-medium">{viewingPayroll.month}/{viewingPayroll.year}</p>
                </div>
                <div>
                  <Label className="text-sm font-medium text-muted-foreground">Basic Salary</Label>
                  <p className="text-sm font-medium">₹{viewingPayroll.basic_salary?.toLocaleString()}</p>
                </div>
                <div>
                  <Label className="text-sm font-medium text-muted-foreground">Allowances</Label>
                  <p className="text-sm font-medium">₹{viewingPayroll.allowances?.toLocaleString()}</p>
                </div>
                <div>
                  <Label className="text-sm font-medium text-muted-foreground">Deductions</Label>
                  <p className="text-sm font-medium">₹{viewingPayroll.deductions?.toLocaleString()}</p>
                </div>
                <div>
                  <Label className="text-sm font-medium text-muted-foreground">Net Salary</Label>
                  <p className="text-sm font-medium">₹{viewingPayroll.net_salary?.toLocaleString()}</p>
                </div>
                <div>
                  <Label className="text-sm font-medium text-muted-foreground">Status</Label>
                  <Badge className={statusColors[viewingPayroll.status as keyof typeof statusColors]}>
                    {statusLabels[viewingPayroll.status as keyof typeof statusLabels]}
                  </Badge>
                </div>
                <div>
                  <Label className="text-sm font-medium text-muted-foreground">Created</Label>
                  <p className="text-sm font-medium">{new Date(viewingPayroll.created_at).toLocaleString()}</p>
                </div>
              </div>
            </div>
          )}
        </SheetContent>
      </Sheet>
    </motion.div>
  );
}
