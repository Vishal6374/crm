import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Plus, Search, Filter, MoreHorizontal, Edit, Trash2, User, Phone, Mail, StickyNote, Calendar, Kanban, Eye, CheckSquare, Square, Download, Users, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import type { Database } from "@/integrations/supabase/types";
import { Checkbox } from "@/components/ui/checkbox";

type Lead = Database['public']['Tables']['leads']['Row'];
type LeadStatus = Database['public']['Tables']['leads']['Row']['status'];

const statusColors = {
  new: "bg-blue-100 text-blue-800",
  contacted: "bg-yellow-100 text-yellow-800",
  qualified: "bg-green-100 text-green-800",
  proposal: "bg-purple-100 text-purple-800",
  won: "bg-emerald-100 text-emerald-800",
  lost: "bg-red-100 text-red-800",
};

const statusLabels = {
  new: "New",
  contacted: "Contacted",
  qualified: "Qualified",
  proposal: "Proposal",
  won: "Won",
  lost: "Lost",
};

function LeadForm({
  initialData,
  onSubmit,
  onCancel
}: {
  initialData?: Lead;
  onSubmit: (formData: FormData) => void;
  onCancel?: () => void;
}) {
  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    onSubmit(formData);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="company_name">Company Name *</Label>
          <Input
            id="company_name"
            name="company_name"
            required
            defaultValue={initialData?.company_name}
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="contact_name">Contact Name *</Label>
          <Input
            id="contact_name"
            name="contact_name"
            required
            defaultValue={initialData?.contact_name}
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="email">Email</Label>
          <Input
            id="email"
            name="email"
            type="email"
            defaultValue={initialData?.email || ""}
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="phone">Phone</Label>
          <Input
            id="phone"
            name="phone"
            defaultValue={initialData?.phone || ""}
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="source">Source</Label>
          <Input
            id="source"
            name="source"
            defaultValue={initialData?.source || ""}
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="status">Status *</Label>
          <Select name="status" defaultValue={initialData?.status || "new"}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="new">New</SelectItem>
              <SelectItem value="contacted">Contacted</SelectItem>
              <SelectItem value="qualified">Qualified</SelectItem>
              <SelectItem value="proposal">Proposal</SelectItem>
              <SelectItem value="won">Won</SelectItem>
              <SelectItem value="lost">Lost</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="notes">Notes</Label>
        <Textarea
          id="notes"
          name="notes"
          defaultValue={initialData?.notes || ""}
          rows={3}
        />
      </div>

      <div className="flex gap-2 pt-4">
        <Button type="submit" className="flex-1">
          {initialData ? "Update Lead" : "Create Lead"}
        </Button>
        {onCancel && (
          <Button type="button" variant="outline" onClick={onCancel}>
            Cancel
          </Button>
        )}
      </div>
    </form>
  );
}

type ActivityLog = Database['public']['Tables']['activity_logs']['Row'];

export default function Leads() {
  const { user } = useAuth();
  const [leads, setLeads] = useState<Lead[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [sourceFilter, setSourceFilter] = useState<string>("all");
  const [ownerFilter, setOwnerFilter] = useState<string>("all");
  const [dateFilter, setDateFilter] = useState<string>("all");
  const [viewMode, setViewMode] = useState<"table" | "kanban">("table");
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [editingLead, setEditingLead] = useState<Lead | null>(null);
  const [selectedLead, setSelectedLead] = useState<Lead | null>(null);
  const [isDetailSheetOpen, setIsDetailSheetOpen] = useState(false);
  const [selectedLeads, setSelectedLeads] = useState<Set<string>>(new Set());
  const [activityLogs, setActivityLogs] = useState<ActivityLog[]>([]);
  const [isBulkActionDialogOpen, setIsBulkActionDialogOpen] = useState(false);
  const [bulkActionType, setBulkActionType] = useState<string>("");
  const [bulkStatus, setBulkStatus] = useState<string>("");
  const [bulkAssignee, setBulkAssignee] = useState<string>("");
  const [users, setUsers] = useState<Array<{id: string, full_name: string}>>([]);
  const [usersMap, setUsersMap] = useState<Record<string, string>>({});
  const [hasMore, setHasMore] = useState(true);
  const [page, setPage] = useState(0);
  const { toast } = useToast();

  useEffect(() => {
    fetchLeads();
    fetchUsers();
  }, []);

  const fetchLeads = async () => {
    try {
      const { data, error } = await supabase
        .from('leads')
        .select('*')
        .order('created_at', { ascending: false })
        .range(page * 50, (page + 1) * 50 - 1);

      if (error) throw error;

      if (page === 0) {
        setLeads(data || []);
      } else {
        setLeads(prev => [...prev, ...(data || [])]);
      }

      setHasMore((data || []).length === 50);
    } catch (error) {
      console.error('Error fetching leads:', error);
      const errObj: any = error || {};
      const desc = errObj.message || errObj.details || 'Failed to fetch leads';
      toast({ title: 'Error', description: desc, variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  };

  const fetchActivityLogs = async (leadId: string) => {
    try {
      const { data, error } = await supabase
        .from('activity_logs')
        .select('*')
        .eq('entity_type', 'lead')
        .eq('entity_id', leadId)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setActivityLogs(data || []);
    } catch (error) {
      console.error('Error fetching activity logs:', error);
    }
  };

  const fetchUsers = async () => {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('id, full_name')
        .order('full_name');

      if (error) throw error;
      setUsers(data || []);
      const userMap: Record<string, string> = {};
      (data || []).forEach(user => {
        userMap[user.id] = user.full_name;
      });
      setUsersMap(userMap);
    } catch (error) {
      console.error('Error fetching users:', error);
    }
  };

  const filteredLeads = leads.filter((lead) => {
    const matchesSearch =
      lead.company_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      lead.contact_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      lead.email?.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesStatus = statusFilter === "all" || lead.status === statusFilter;
    const matchesSource = sourceFilter === "all" || lead.source === sourceFilter;
    const matchesOwner = ownerFilter === "all" || lead.assigned_to === ownerFilter;

    // Date filtering logic
    let matchesDate = true;
    if (dateFilter !== "all") {
      const leadDate = new Date(lead.created_at);
      const now = new Date();
      const daysDiff = Math.floor((now.getTime() - leadDate.getTime()) / (1000 * 3600 * 24));

      switch (dateFilter) {
        case "today":
          matchesDate = daysDiff === 0;
          break;
        case "week":
          matchesDate = daysDiff <= 7;
          break;
        case "month":
          matchesDate = daysDiff <= 30;
          break;
        default:
          matchesDate = true;
      }
    }

    return matchesSearch && matchesStatus && matchesSource && matchesOwner && matchesDate;
  });

  const handleCreateLead = async (formData: FormData) => {
    if (!user?.id) {
      toast({ title: 'Authentication required', description: 'Please sign in to create leads', variant: 'destructive' });
      return;
    }

    try {
      const leadData = {
        company_name: formData.get('company_name') as string,
        contact_name: formData.get('contact_name') as string,
        email: formData.get('email') as string,
        phone: formData.get('phone') as string,
        source: formData.get('source') as string,
        status: formData.get('status') as LeadStatus,
        notes: formData.get('notes') as string,
        created_by: user?.id || null,
      };

      const { error } = await supabase.from('leads').insert([leadData]);
      if (error) {
        const errObj: any = error;
        console.error('Create lead error:', errObj);
        const msg = errObj.message || errObj.details || 'Failed to create lead';
        if (msg.toLowerCase().includes('foreign key') || msg.toLowerCase().includes('violat')) {
          toast({ title: 'Foreign key error', description: 'One of the referenced records does not exist. Check related records.', variant: 'destructive' });
        } else {
          toast({ title: 'Error', description: msg, variant: 'destructive' });
        }
        return;
      }

      toast({
        title: "Success",
        description: "Lead created successfully",
      });

      setIsCreateDialogOpen(false);
      fetchLeads();
    } catch (error) {
      console.error('Error creating lead:', error);
      const errObj: any = error || {};
      const desc = errObj.message || errObj.details || 'Failed to create lead';
      toast({ title: 'Error', description: desc, variant: 'destructive' });
    }
  };

  const handleUpdateLead = async (formData: FormData) => {
    if (!editingLead) return;

    try {
      const leadData = {
        company_name: formData.get('company_name') as string,
        contact_name: formData.get('contact_name') as string,
        email: formData.get('email') as string,
        phone: formData.get('phone') as string,
        source: formData.get('source') as string,
        status: formData.get('status') as LeadStatus,
        notes: formData.get('notes') as string,
      };

      const { error } = await supabase
        .from('leads')
        .update(leadData)
        .eq('id', editingLead.id);

      if (error) throw error;

      toast({
        title: "Success",
        description: "Lead updated successfully",
      });

      setEditingLead(null);
      fetchLeads();
    } catch (error) {
      console.error('Error updating lead:', error);
      toast({
        title: "Error",
        description: "Failed to update lead",
        variant: "destructive",
      });
    }
  };

  const handleDeleteLead = async (leadId: string) => {
    try {
      const { error } = await supabase
        .from('leads')
        .delete()
        .eq('id', leadId);

      if (error) throw error;

      toast({
        title: "Success",
        description: "Lead deleted successfully",
      });

      fetchLeads();
    } catch (error) {
      console.error('Error deleting lead:', error);
      toast({
        title: "Error",
        description: "Failed to delete lead",
        variant: "destructive",
      });
    }
  };

  const handleConvertToContact = async (lead: Lead) => {
    if (!user?.id) {
      toast({ title: 'Authentication required', description: 'Please sign in to convert leads', variant: 'destructive' });
      return;
    }

    try {
      // Create contact from lead data
      const { data: contactData, error: contactError } = await supabase
        .from('contacts')
        .insert({
          first_name: lead.contact_name.split(' ')[0],
          last_name: lead.contact_name.split(' ').slice(1).join(' ') || null,
          email: lead.email,
          phone: lead.phone,
          notes: lead.notes,
          created_by: user?.id || null,
        })
        .select()
        .single();

      if (contactError) {
        console.error('Contact create error:', contactError);
        const msg = contactError.message || contactError.details || 'Failed to create contact';
        if (msg.toLowerCase().includes('foreign key') || msg.toLowerCase().includes('violat')) {
          toast({ title: 'Foreign key error', description: 'Contact creation failed due to missing referenced records.', variant: 'destructive' });
        } else {
          toast({ title: 'Error', description: msg, variant: 'destructive' });
        }
        return;
      }

      // Update lead as converted
      const { error: leadError } = await supabase
        .from('leads')
        .update({
          converted_at: new Date().toISOString(),
          status: 'qualified',
        })
        .eq('id', lead.id);

      if (leadError) throw leadError;

      // Log activity
      await supabase
        .from('activity_logs')
        .insert({
          entity_type: 'lead',
          entity_id: lead.id,
          action: 'converted_to_contact',
          details: { contact_id: contactData.id }
        });

      toast({
        title: "Success",
        description: "Lead converted to contact successfully",
      });

      fetchLeads();
    } catch (error) {
      console.error('Error converting lead to contact:', error);
      toast({
        title: "Error",
        description: "Failed to convert lead to contact",
        variant: "destructive",
      });
    }
  };

  const handleLogCall = async (lead: Lead) => {
    try {
      await supabase
        .from('activity_logs')
        .insert({
          entity_type: 'lead',
          entity_id: lead.id,
          action: 'call_logged',
          details: {
            type: 'call',
            timestamp: new Date().toISOString()
          }
        });

      toast({
        title: "Success",
        description: "Call logged successfully",
      });
    } catch (error) {
      console.error('Error logging call:', error);
      toast({
        title: "Error",
        description: "Failed to log call",
        variant: "destructive",
      });
    }
  };

  const handleLogEmail = async (lead: Lead) => {
    try {
      await supabase
        .from('activity_logs')
        .insert({
          entity_type: 'lead',
          entity_id: lead.id,
          action: 'email_logged',
          details: {
            type: 'email',
            timestamp: new Date().toISOString()
          }
        });

      toast({
        title: "Success",
        description: "Email logged successfully",
      });
    } catch (error) {
      console.error('Error logging email:', error);
      toast({
        title: "Error",
        description: "Failed to log email",
        variant: "destructive",
      });
    }
  };

  const handleAddNotes = async (lead: Lead) => {
    const newNote = prompt('Enter note:');
    if (!newNote) return;

    try {
      const existingNotes = lead.notes || '';
      const updatedNotes = existingNotes ? `${existingNotes}\n\n${new Date().toLocaleString()}: ${newNote}` : `${new Date().toLocaleString()}: ${newNote}`;

      const { error } = await supabase
        .from('leads')
        .update({ notes: updatedNotes })
        .eq('id', lead.id);

      if (error) throw error;

      // Log activity
      await supabase
        .from('activity_logs')
        .insert({
          entity_type: 'lead',
          entity_id: lead.id,
          action: 'note_added',
          details: { note: newNote }
        });

      toast({
        title: "Success",
        description: "Note added successfully",
      });

      fetchLeads();
    } catch (error) {
      console.error('Error adding note:', error);
      toast({
        title: "Error",
        description: "Failed to add note",
        variant: "destructive",
      });
    }
  };

  const handleBulkAction = async () => {
    if (selectedLeads.size === 0) return;

    try {
      const leadIds = Array.from(selectedLeads);

      if (bulkActionType === "delete") {
        const { error } = await supabase
          .from('leads')
          .delete()
          .in('id', leadIds);

        if (error) throw error;

        toast({
          title: "Success",
          description: `Deleted ${leadIds.length} lead(s) successfully`,
        });
      } else if (bulkActionType === "status" && bulkStatus) {
        const { error } = await supabase
          .from('leads')
          .update({ status: bulkStatus as LeadStatus })
          .in('id', leadIds);

        if (error) throw error;

        toast({
          title: "Success",
          description: `Updated status for ${leadIds.length} lead(s) successfully`,
        });
      } else if (bulkActionType === "assign") {
        const assignee = bulkAssignee === "Unassigned" ? null : bulkAssignee;
        const { error } = await supabase
          .from('leads')
          .update({ assigned_to: assignee })
          .in('id', leadIds);

        if (error) throw error;

        toast({
          title: "Success",
          description: `Assigned ${leadIds.length} lead(s) successfully`,
        });
      }

      setIsBulkActionDialogOpen(false);
      setSelectedLeads(new Set());
      setBulkStatus("");
      setBulkAssignee("");
      fetchLeads();
    } catch (error) {
      console.error('Error performing bulk action:', error);
      toast({
        title: "Error",
        description: "Failed to perform bulk action",
        variant: "destructive",
      });
    }
  };

  const handleExport = () => {
    try {
      // Create CSV content
      const headers = ["Company Name", "Contact Name", "Email", "Phone", "Source", "Status", "Assigned To", "Created Date", "Notes"];
      const csvContent = [
        headers.join(","),
        ...filteredLeads.map(lead => [
          `"${lead.company_name}"`,
          `"${lead.contact_name}"`,
          `"${lead.email || ""}"`,
          `"${lead.phone || ""}"`,
          `"${lead.source || ""}"`,
          `"${statusLabels[lead.status]}"`,
          `"${lead.assigned_to ? usersMap[lead.assigned_to] || lead.assigned_to : "Unassigned"}"`,
          `"${new Date(lead.created_at).toLocaleDateString()}"`,
          `"${lead.notes || ""}"`
        ].join(","))
      ].join("\n");

      // Create and download the file
      const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
      const link = document.createElement("a");
      const url = URL.createObjectURL(blob);
      link.setAttribute("href", url);
      link.setAttribute("download", `leads_export_${new Date().toISOString().split('T')[0]}.csv`);
      link.style.visibility = "hidden";
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);

      toast({
        title: "Success",
        description: "Leads exported successfully",
      });
    } catch (error) {
      console.error('Error exporting leads:', error);
      toast({
        title: "Error",
        description: "Failed to export leads",
        variant: "destructive",
      });
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
          <p className="mt-2 text-muted-foreground">Loading leads...</p>
        </div>
      </div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-6"
    >
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Leads</h1>
          <p className="text-muted-foreground">
            Manage your sales leads and track their progress
          </p>
        </div>
        <div className="flex gap-2">
          {selectedLeads.size > 0 && (
            <div className="flex items-center gap-2">
              <span className="text-sm text-muted-foreground">
                {selectedLeads.size} selected
              </span>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setSelectedLeads(new Set())}
              >
                Clear
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  setBulkActionType("delete");
                  setIsBulkActionDialogOpen(true);
                }}
              >
                <Trash2 className="h-4 w-4 mr-2" />
                Delete
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  setBulkActionType("status");
                  setIsBulkActionDialogOpen(true);
                }}
              >
                <Edit className="h-4 w-4 mr-2" />
                Update Status
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  setBulkActionType("assign");
                  setIsBulkActionDialogOpen(true);
                }}
              >
                <User className="h-4 w-4 mr-2" />
                Assign
              </Button>
            </div>
          )}
          <Button variant="outline" size="sm" onClick={handleExport}>
            <Download className="h-4 w-4 mr-2" />
            Export
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => setViewMode(viewMode === "table" ? "kanban" : "table")}
          >
            <Kanban className="h-4 w-4 mr-2" />
            {viewMode === "table" ? "Kanban" : "Table"}
          </Button>
          <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="h-4 w-4 mr-2" />
                Add Lead
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-md">
              <DialogHeader>
                <DialogTitle>Create New Lead</DialogTitle>
              </DialogHeader>
              <LeadForm onSubmit={handleCreateLead} />
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="pt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search leads..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger>
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="new">New</SelectItem>
                <SelectItem value="contacted">Contacted</SelectItem>
                <SelectItem value="qualified">Qualified</SelectItem>
                <SelectItem value="proposal">Proposal</SelectItem>
                <SelectItem value="won">Won</SelectItem>
                <SelectItem value="lost">Lost</SelectItem>
              </SelectContent>
            </Select>
            <Select value={sourceFilter} onValueChange={setSourceFilter}>
              <SelectTrigger>
                <SelectValue placeholder="Filter by source" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Sources</SelectItem>
                <SelectItem value="Website">Website</SelectItem>
                <SelectItem value="Referral">Referral</SelectItem>
                <SelectItem value="LinkedIn">LinkedIn</SelectItem>
                <SelectItem value="Other">Other</SelectItem>
              </SelectContent>
            </Select>
            <Select value={ownerFilter} onValueChange={setOwnerFilter}>
              <SelectTrigger>
                <SelectValue placeholder="Filter by owner" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Owners</SelectItem>
                <SelectItem value="Unassigned">Unassigned</SelectItem>
                {users.map((user) => (
                  <SelectItem key={user.id} value={user.id}>
                    {user.full_name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={dateFilter} onValueChange={setDateFilter}>
              <SelectTrigger>
                <SelectValue placeholder="Filter by date" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Dates</SelectItem>
                <SelectItem value="today">Today</SelectItem>
                <SelectItem value="week">This Week</SelectItem>
                <SelectItem value="month">This Month</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Leads Content */}
      {viewMode === "table" ? (
        <Card className="flex flex-col h-[calc(100vh-12rem)]">
          <CardHeader className="flex-shrink-0">
            <CardTitle>All Leads ({filteredLeads.length})</CardTitle>
          </CardHeader>
          <CardContent className="flex-1 overflow-hidden p-0">
            <div className="h-full overflow-y-auto">
              <Table>
                <TableHeader className="sticky top-0 bg-background z-10">
                  <TableRow>
                    <TableHead className="w-12">
                      <Checkbox
                        checked={selectedLeads.size === filteredLeads.length && filteredLeads.length > 0}
                        onCheckedChange={(checked) => {
                          if (checked) {
                            setSelectedLeads(new Set(filteredLeads.map(lead => lead.id)));
                          } else {
                            setSelectedLeads(new Set());
                          }
                        }}
                      />
                    </TableHead>
                    <TableHead>Lead Name</TableHead>
                    <TableHead>Email</TableHead>
                    <TableHead>Phone</TableHead>
                    <TableHead>Source</TableHead>
                    <TableHead>Assigned To</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Created Date</TableHead>
                    <TableHead className="w-12">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredLeads.map((lead) => (
                    <TableRow key={lead.id}>
                      <TableCell>
                        <Checkbox
                          checked={selectedLeads.has(lead.id)}
                          onCheckedChange={(checked) => {
                            const newSelected = new Set(selectedLeads);
                            if (checked) {
                              newSelected.add(lead.id);
                            } else {
                              newSelected.delete(lead.id);
                            }
                            setSelectedLeads(newSelected);
                          }}
                        />
                      </TableCell>
                      <TableCell className="font-medium">
                        <div>
                          <div className="font-medium">{lead.contact_name}</div>
                          <div className="text-sm text-muted-foreground">{lead.company_name}</div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Mail className="h-4 w-4 text-muted-foreground" />
                          {lead.email}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Phone className="h-4 w-4 text-muted-foreground" />
                          {lead.phone}
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline">{lead.source}</Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <User className="h-4 w-4 text-muted-foreground" />
                          {lead.assigned_to ? usersMap[lead.assigned_to] || lead.assigned_to : "Unassigned"}
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge className={statusColors[lead.status]}>
                          {statusLabels[lead.status]}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Calendar className="h-4 w-4 text-muted-foreground" />
                          {new Date(lead.created_at).toLocaleDateString()}
                        </div>
                      </TableCell>
                      <TableCell>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="sm">
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => {
                              setSelectedLead(lead);
                              fetchActivityLogs(lead.id);
                              setIsDetailSheetOpen(true);
                            }}>
                              <Eye className="h-4 w-4 mr-2" />
                              View Details
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => setEditingLead(lead)}>
                              <Edit className="h-4 w-4 mr-2" />
                              Edit Lead
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => handleConvertToContact(lead)}>
                              <User className="h-4 w-4 mr-2" />
                              Convert to Contact
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => handleLogCall(lead)}>
                              <Phone className="h-4 w-4 mr-2" />
                              Log Call
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => handleLogEmail(lead)}>
                              <Mail className="h-4 w-4 mr-2" />
                              Log Email
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => handleAddNotes(lead)}>
                              <StickyNote className="h-4 w-4 mr-2" />
                              Add Notes
                            </DropdownMenuItem>
                            <DropdownMenuItem
                              onClick={() => handleDeleteLead(lead.id)}
                              className="text-destructive"
                            >
                              <Trash2 className="h-4 w-4 mr-2" />
                              Delete
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>

              {filteredLeads.length === 0 && (
                <div className="text-center py-8">
                  <p className="text-muted-foreground">No leads found</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      ) : (
        /* Kanban View */
        <div className="h-[calc(100vh-12rem)] overflow-y-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {Object.entries(statusLabels).map(([statusKey, statusLabel]) => {
              const statusLeads = filteredLeads.filter(lead => lead.status === statusKey);
              return (
                <Card key={statusKey}>
                  <CardHeader>
                    <CardTitle className="flex items-center justify-between">
                      <span>{statusLabel}</span>
                      <Badge variant="secondary">{statusLeads.length}</Badge>
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    {statusLeads.map((lead) => (
                      <div
                        key={lead.id}
                        className="p-3 border rounded-lg bg-card hover:shadow-md transition-shadow cursor-pointer"
                        onClick={() => setEditingLead(lead)}
                      >
                        <div className="font-medium text-sm">{lead.contact_name}</div>
                        <div className="text-xs text-muted-foreground">{lead.company_name}</div>
                        <div className="text-xs text-muted-foreground mt-1">{lead.email}</div>
                        <div className="text-xs text-muted-foreground">{lead.source}</div>
                      </div>
                    ))}
                    {statusLeads.length === 0 && (
                      <div className="text-center py-4 text-muted-foreground text-sm">
                        No leads in {statusLabel.toLowerCase()}
                      </div>
                    )}
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      )}

      {/* Edit Dialog */}
      <Dialog open={!!editingLead} onOpenChange={() => setEditingLead(null)}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Edit Lead</DialogTitle>
          </DialogHeader>
          {editingLead && (
            <LeadForm
              initialData={editingLead}
              onSubmit={handleUpdateLead}
              onCancel={() => setEditingLead(null)}
            />
          )}
        </DialogContent>
      </Dialog>

      {/* Lead Details Sheet */}
      <Sheet open={isDetailSheetOpen} onOpenChange={setIsDetailSheetOpen}>
        <SheetContent className="w-[400px] sm:w-[540px] h-screen overflow-y-auto">
          <SheetHeader>
            <SheetTitle>Lead Details</SheetTitle>
          </SheetHeader>
          {selectedLead && (
            <div className="space-y-6 mt-6">
              <div className="space-y-4">
                <div>
                  <h3 className="text-lg font-semibold">{selectedLead.contact_name}</h3>
                  <p className="text-muted-foreground">{selectedLead.company_name}</p>
                </div>

                <div className="grid grid-cols-1 gap-4">
                  <div className="space-y-2">
                    <Label className="text-sm font-medium">Email</Label>
                    <div className="flex items-center gap-2">
                      <Mail className="h-4 w-4 text-muted-foreground" />
                      <span>{selectedLead.email || "Not provided"}</span>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label className="text-sm font-medium">Phone</Label>
                    <div className="flex items-center gap-2">
                      <Phone className="h-4 w-4 text-muted-foreground" />
                      <span>{selectedLead.phone || "Not provided"}</span>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label className="text-sm font-medium">Source</Label>
                    <Badge variant="outline">{selectedLead.source}</Badge>
                  </div>

                  <div className="space-y-2">
                    <Label className="text-sm font-medium">Assigned To</Label>
                    <div className="flex items-center gap-2">
                      <User className="h-4 w-4 text-muted-foreground" />
                      <span>{selectedLead.assigned_to || "Unassigned"}</span>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label className="text-sm font-medium">Status</Label>
                    <Badge className={statusColors[selectedLead.status]}>
                      {statusLabels[selectedLead.status]}
                    </Badge>
                  </div>

                  <div className="space-y-2">
                    <Label className="text-sm font-medium">Created Date</Label>
                    <div className="flex items-center gap-2">
                      <Calendar className="h-4 w-4 text-muted-foreground" />
                      <span>{new Date(selectedLead.created_at).toLocaleDateString()}</span>
                    </div>
                  </div>

                  {selectedLead.notes && (
                    <div className="space-y-2">
                      <Label className="text-sm font-medium">Notes</Label>
                      <div className="p-3 bg-muted rounded-md">
                        <p className="text-sm">{selectedLead.notes}</p>
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {/* Activity Logs */}
              <div className="space-y-4">
                <Label className="text-sm font-medium">Activity Logs</Label>
                <div className="space-y-2">
                  {activityLogs.length > 0 ? (
                    activityLogs.map((log) => (
                      <div key={log.id} className="p-3 border rounded-md bg-muted/50">
                        <div className="flex items-center justify-between">
                          <span className="text-sm font-medium capitalize">
                            {log.action.replace(/_/g, ' ')}
                          </span>
                          <span className="text-xs text-muted-foreground">
                            {new Date(log.created_at).toLocaleString()}
                          </span>
                        </div>
                        {log.details && (
                          <div className="text-xs text-muted-foreground mt-1">
                            {typeof log.details === 'object' ? JSON.stringify(log.details) : log.details}
                          </div>
                        )}
                      </div>
                    ))
                  ) : (
                    <p className="text-sm text-muted-foreground">No activity logs found</p>
                  )}
                </div>
              </div>

              <div className="flex gap-2 pt-4">
                <Button
                  onClick={() => {
                    setEditingLead(selectedLead);
                    setIsDetailSheetOpen(false);
                  }}
                  className="flex-1"
                >
                  <Edit className="h-4 w-4 mr-2" />
                  Edit Lead
                </Button>
                <Button
                  variant="outline"
                  onClick={() => setIsDetailSheetOpen(false)}
                >
                  Close
                </Button>
              </div>
            </div>
          )}
        </SheetContent>
      </Sheet>

      {/* Bulk Action Dialog */}
      <Dialog open={isBulkActionDialogOpen} onOpenChange={setIsBulkActionDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>
              {bulkActionType === "delete" && "Delete Selected Leads"}
              {bulkActionType === "status" && "Update Status"}
              {bulkActionType === "assign" && "Assign Leads"}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <p className="text-sm text-muted-foreground">
              {bulkActionType === "delete" && `Are you sure you want to delete ${selectedLeads.size} selected lead(s)? This action cannot be undone.`}
              {bulkActionType === "status" && "Select the new status for the selected leads:"}
              {bulkActionType === "assign" && "Select the assignee for the selected leads:"}
            </p>

            {bulkActionType === "status" && (
              <Select value={bulkStatus} onValueChange={setBulkStatus}>
                <SelectTrigger>
                  <SelectValue placeholder="Select status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="new">New</SelectItem>
                  <SelectItem value="contacted">Contacted</SelectItem>
                  <SelectItem value="qualified">Qualified</SelectItem>
                  <SelectItem value="proposal">Proposal</SelectItem>
                  <SelectItem value="won">Won</SelectItem>
                  <SelectItem value="lost">Lost</SelectItem>
                </SelectContent>
              </Select>
            )}

            {bulkActionType === "assign" && (
              <Select value={bulkAssignee} onValueChange={setBulkAssignee}>
                <SelectTrigger>
                  <SelectValue placeholder="Select assignee" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Unassigned">Unassigned</SelectItem>
                  {users.map((user) => (
                    <SelectItem key={user.id} value={user.id}>
                      {user.full_name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            )}

            <div className="flex gap-2 pt-4">
              <Button
                variant="outline"
                onClick={() => setIsBulkActionDialogOpen(false)}
                className="flex-1"
              >
                Cancel
              </Button>
              <Button
                variant={bulkActionType === "delete" ? "destructive" : "default"}
                onClick={handleBulkAction}
                className="flex-1"
              >
                {bulkActionType === "delete" && "Delete"}
                {bulkActionType === "status" && "Update Status"}
                {bulkActionType === "assign" && "Assign"}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </motion.div>
  );
}
