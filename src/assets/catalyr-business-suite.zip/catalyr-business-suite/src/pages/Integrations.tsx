import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import {
  Zap,
  Webhook,
  Mail,
  MessageSquare,
  Calendar,
  Cloud,
  Settings,
  Plus,
  Trash2,
  Edit,
  CheckCircle,
  XCircle,
  ExternalLink,
  RefreshCw
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/contexts/AuthContext";
import { integrationsService } from "@/services";

type Integration = {
  id: string;
  name: string;
  type: 'email' | 'calendar' | 'communication' | 'storage' | 'automation' | 'webhook';
  provider: string;
  status: 'active' | 'inactive' | 'error';
  config: Record<string, any>;
  last_sync?: string;
  created_at: string;
  updated_at: string;
};

const integrationTypes = {
  email: { icon: Mail, label: 'Email', color: 'bg-blue-100 text-blue-800' },
  calendar: { icon: Calendar, label: 'Calendar', color: 'bg-green-100 text-green-800' },
  communication: { icon: MessageSquare, label: 'Communication', color: 'bg-purple-100 text-purple-800' },
  storage: { icon: Cloud, label: 'Storage', color: 'bg-orange-100 text-orange-800' },
  automation: { icon: Zap, label: 'Automation', color: 'bg-yellow-100 text-yellow-800' },
  webhook: { icon: Webhook, label: 'Webhook', color: 'bg-red-100 text-red-800' },
};

const statusConfig = {
  active: { icon: CheckCircle, color: 'text-green-600', label: 'Active' },
  inactive: { icon: XCircle, color: 'text-gray-600', label: 'Inactive' },
  error: { icon: XCircle, color: 'text-red-600', label: 'Error' },
};

function IntegrationForm({
  integration,
  onSubmit,
  onCancel
}: {
  integration?: Integration;
  onSubmit: (formData: FormData) => void;
  onCancel?: () => void;
}) {
  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    onSubmit(formData);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="name">Integration Name *</Label>
          <Input
            id="name"
            name="name"
            required
            defaultValue={integration?.name || ""}
            placeholder="e.g., Gmail Integration"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="type">Type *</Label>
          <Select name="type" defaultValue={integration?.type || "email"} required>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="email">Email</SelectItem>
              <SelectItem value="calendar">Calendar</SelectItem>
              <SelectItem value="communication">Communication</SelectItem>
              <SelectItem value="storage">Storage</SelectItem>
              <SelectItem value="automation">Automation</SelectItem>
              <SelectItem value="webhook">Webhook</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="provider">Provider *</Label>
        <Input
          id="provider"
          name="provider"
          required
          defaultValue={integration?.provider || ""}
          placeholder="e.g., Gmail, Outlook, Slack"
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="api_key">API Key</Label>
        <Input
          id="api_key"
          name="api_key"
          type="password"
          defaultValue={integration?.config?.api_key || ""}
          placeholder="Enter API key"
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="webhook_url">Webhook URL</Label>
        <Input
          id="webhook_url"
          name="webhook_url"
          defaultValue={integration?.config?.webhook_url || ""}
          placeholder="https://your-app.com/webhook"
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="description">Description</Label>
        <Textarea
          id="description"
          name="description"
          defaultValue={integration?.config?.description || ""}
          rows={3}
          placeholder="Describe this integration"
        />
      </div>

      <div className="flex items-center space-x-2">
        <Switch
          id="active"
          name="active"
          defaultChecked={integration?.status === 'active'}
        />
        <Label htmlFor="active">Active</Label>
      </div>

      <div className="flex gap-2 pt-4">
        <Button type="submit" className="flex-1">
          {integration ? "Update Integration" : "Create Integration"}
        </Button>
        {onCancel && (
          <Button type="button" variant="outline" onClick={onCancel}>
            Cancel
          </Button>
        )}
      </div>
    </form>
  );
}

export default function Integrations() {
  const [integrations, setIntegrations] = useState<Integration[]>([]);
  const [loading, setLoading] = useState(true);
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [editingIntegration, setEditingIntegration] = useState<Integration | null>(null);
  const { toast } = useToast();

  useEffect(() => {
    fetchIntegrations();
  }, []);

  const fetchIntegrations = async () => {
    try {
      setLoading(true);
      const rows = await integrationsService.list();
      setIntegrations(rows as Integration[]);
    } catch (error) {
      console.error('Error fetching integrations:', error);
      toast({
        title: "Error",
        description: "Failed to fetch integrations",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleCreateIntegration = async (formData: FormData) => {
    try {
      const { user } = useAuth();
      const payload = {
        name: formData.get('name') as string,
        type: formData.get('type') as Integration['type'],
        provider: formData.get('provider') as string,
        status: formData.get('active') === 'on' ? 'active' : 'inactive',
        config: {
          api_key: formData.get('api_key') as string,
          webhook_url: formData.get('webhook_url') as string,
          description: formData.get('description') as string,
        },
      };

      const created = await integrationsService.create(payload, user?.id);
      setIntegrations(prev => [created as Integration, ...prev]);

      toast({ title: "Success", description: "Integration created successfully" });
      setIsCreateDialogOpen(false);
    } catch (error) {
      console.error('Error creating integration:', error);
      toast({
        title: "Error",
        description: "Failed to create integration",
        variant: "destructive",
      });
    }
  };

  const handleUpdateIntegration = async (formData: FormData) => {
    if (!editingIntegration) return;

    try {
      const payload = {
        name: formData.get('name') as string,
        type: formData.get('type') as Integration['type'],
        provider: formData.get('provider') as string,
        status: formData.get('active') === 'on' ? 'active' : 'inactive',
        config: {
          api_key: formData.get('api_key') as string,
          webhook_url: formData.get('webhook_url') as string,
          description: formData.get('description') as string,
        },
      };

      const updated = await integrationsService.update(editingIntegration.id, payload);
      setIntegrations(prev => prev.map(i => (i.id === editingIntegration.id ? (updated as Integration) : i)));
      toast({ title: "Success", description: "Integration updated successfully" });
      setEditingIntegration(null);
    } catch (error) {
      console.error('Error updating integration:', error);
      toast({
        title: "Error",
        description: "Failed to update integration",
        variant: "destructive",
      });
    }
  };

  const handleDeleteIntegration = async (integrationId: string) => {
    try {
      await integrationsService.remove(integrationId);
      setIntegrations(prev => prev.filter(integration => integration.id !== integrationId));
      toast({ title: "Success", description: "Integration deleted successfully" });
    } catch (error) {
      console.error('Error deleting integration:', error);
      toast({
        title: "Error",
        description: "Failed to delete integration",
        variant: "destructive",
      });
    }
  };

  const handleTestIntegration = async (integration: Integration) => {
    try {
      // Mock test functionality
      toast({
        title: "Testing Integration",
        description: `Testing connection to ${integration.provider}...`,
      });

      // Simulate API call
      setTimeout(() => {
        toast({
          title: "Test Successful",
          description: `${integration.name} is working correctly`,
        });
      }, 2000);
    } catch (error) {
      toast({
        title: "Test Failed",
        description: `Failed to test ${integration.name}`,
        variant: "destructive",
      });
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
          <p className="mt-2 text-muted-foreground">Loading integrations...</p>
        </div>
      </div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-6"
    >
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Integrations</h1>
          <p className="text-muted-foreground">
            Connect and manage third-party services
          </p>
        </div>
        <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="h-4 w-4 mr-2" />
              Add Integration
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>Create Integration</DialogTitle>
            </DialogHeader>
            <IntegrationForm
              onSubmit={handleCreateIntegration}
            />
          </DialogContent>
        </Dialog>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Integrations</CardTitle>
            <Webhook className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{integrations.length}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active</CardTitle>
            <CheckCircle className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {integrations.filter(i => i.status === 'active').length}
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">With Errors</CardTitle>
            <XCircle className="h-4 w-4 text-red-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {integrations.filter(i => i.status === 'error').length}
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Types</CardTitle>
            <Settings className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {new Set(integrations.map(i => i.type)).size}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Integrations Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {integrations.map((integration) => {
          const typeConfig = integrationTypes[integration.type];
          const statusConfigItem = statusConfig[integration.status];
          const StatusIcon = statusConfigItem.icon;
          const TypeIcon = typeConfig.icon;

          return (
            <Card key={integration.id} className="relative">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <TypeIcon className="h-5 w-5" />
                    <CardTitle className="text-lg">{integration.name}</CardTitle>
                  </div>
                  <StatusIcon className={`h-5 w-5 ${statusConfigItem.color}`} />
                </div>
                <div className="flex items-center gap-2">
                  <Badge className={typeConfig.color}>
                    {typeConfig.label}
                  </Badge>
                  <Badge variant="outline">
                    {integration.provider}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="text-sm text-muted-foreground">
                  {integration.config.description || 'No description provided'}
                </div>

                {integration.last_sync && (
                  <div className="text-xs text-muted-foreground">
                    Last sync: {new Date(integration.last_sync).toLocaleString()}
                  </div>
                )}

                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleTestIntegration(integration)}
                    className="flex-1"
                  >
                    <RefreshCw className="h-3 w-3 mr-1" />
                    Test
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setEditingIntegration(integration)}
                  >
                    <Edit className="h-3 w-3" />
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleDeleteIntegration(integration.id)}
                  >
                    <Trash2 className="h-3 w-3" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {integrations.length === 0 && (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12">
            <Webhook className="h-12 w-12 text-muted-foreground mb-4" />
            <h3 className="text-lg font-medium mb-2">No integrations yet</h3>
            <p className="text-muted-foreground text-center mb-4">
              Connect third-party services to extend your CRM capabilities
            </p>
            <Button onClick={() => setIsCreateDialogOpen(true)}>
              <Plus className="h-4 w-4 mr-2" />
              Add Your First Integration
            </Button>
          </CardContent>
        </Card>
      )}

      {/* Edit Dialog */}
      <Dialog open={!!editingIntegration} onOpenChange={() => setEditingIntegration(null)}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Edit Integration</DialogTitle>
          </DialogHeader>
          {editingIntegration && (
            <IntegrationForm
              integration={editingIntegration}
              onSubmit={handleUpdateIntegration}
              onCancel={() => setEditingIntegration(null)}
            />
          )}
        </DialogContent>
      </Dialog>
    </motion.div>
  );
}
