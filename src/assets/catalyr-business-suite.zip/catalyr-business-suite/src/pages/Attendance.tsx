import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Plus, Search, Filter, MoreHorizontal, Edit, Trash2, Clock, Calendar, Eye } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import type { Database } from "@/integrations/supabase/types";

type Attendance = Database['public']['Tables']['attendance']['Row'] & {
  employees?: { full_name: string; employee_code: string };
};
type Employee = Database['public']['Tables']['employees']['Row'];

const statusColors = {
  present: "bg-green-100 text-green-800",
  absent: "bg-red-100 text-red-800",
  late: "bg-yellow-100 text-yellow-800",
  half_day: "bg-orange-100 text-orange-800",
};

const statusLabels = {
  present: "Present",
  absent: "Absent",
  late: "Late",
  half_day: "Half Day",
};

function AttendanceForm({
  initialData,
  employees,
  onSubmit,
  onCancel
}: {
  initialData?: Attendance;
  employees: Employee[];
  onSubmit: (formData: FormData) => void;
  onCancel?: () => void;
}) {
  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    onSubmit(formData);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="employee_id">Employee *</Label>
        <Select name="employee_id" defaultValue={initialData?.employee_id || ""} required>
          <SelectTrigger>
            <SelectValue placeholder="Select employee" />
          </SelectTrigger>
          <SelectContent>
            {employees.map((emp) => (
              <SelectItem key={emp.id} value={emp.id}>
                {emp.full_name} ({emp.employee_code})
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-2">
        <Label htmlFor="date">Date *</Label>
        <Input
          id="date"
          name="date"
          type="date"
          required
          defaultValue={initialData?.date ? new Date(initialData.date).toISOString().split('T')[0] : new Date().toISOString().split('T')[0]}
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="check_in">Check In Time</Label>
        <Input
          id="check_in"
          name="check_in"
          type="datetime-local"
          defaultValue={initialData?.check_in ? new Date(initialData.check_in).toISOString().slice(0, 16) : ""}
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="check_out">Check Out Time</Label>
        <Input
          id="check_out"
          name="check_out"
          type="datetime-local"
          defaultValue={initialData?.check_out ? new Date(initialData.check_out).toISOString().slice(0, 16) : ""}
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="status">Status</Label>
        <Select name="status" defaultValue={initialData?.status || ""}>
          <SelectTrigger>
            <SelectValue placeholder="Select status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="present">Present</SelectItem>
            <SelectItem value="absent">Absent</SelectItem>
            <SelectItem value="late">Late</SelectItem>
            <SelectItem value="half_day">Half Day</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-2">
        <Label htmlFor="notes">Notes</Label>
        <Textarea
          id="notes"
          name="notes"
          defaultValue={initialData?.notes || ""}
          rows={3}
        />
      </div>

      <div className="flex gap-2 pt-4">
        <Button type="submit" className="flex-1">
          {initialData ? "Update Attendance" : "Create Attendance"}
        </Button>
        {onCancel && (
          <Button type="button" variant="outline" onClick={onCancel}>
            Cancel
          </Button>
        )}
      </div>
    </form>
  );
}

export default function Attendance() {
  const [attendance, setAttendance] = useState<Attendance[]>([]);
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [dateFilter, setDateFilter] = useState<string>("");
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [editingAttendance, setEditingAttendance] = useState<Attendance | null>(null);
  const [viewingAttendance, setViewingAttendance] = useState<Attendance | null>(null);
  const { toast } = useToast();

  useEffect(() => {
    fetchAttendance();
    fetchEmployees();
  }, []);

  const fetchAttendance = async () => {
    try {
      const { data, error } = await supabase
        .from('attendance')
        .select(`
          *,
          employees (
            full_name,
            employee_code
          )
        `)
        .order('date', { ascending: false });

      if (error) throw error;
      setAttendance(data || []);
    } catch (error) {
      console.error('Error fetching attendance:', error);
      toast({
        title: "Error",
        description: "Failed to fetch attendance records",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const fetchEmployees = async () => {
    try {
      const { data, error } = await supabase
        .from('employees')
        .select('*')
        .eq('status', 'active')
        .order('full_name');

      if (error) throw error;
      setEmployees(data || []);
    } catch (error) {
      console.error('Error fetching employees:', error);
    }
  };

  const filteredAttendance = attendance.filter((record) => {
    const matchesSearch =
      record.employees?.full_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      record.employees?.employee_code.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesStatus = statusFilter === "all" || record.status === statusFilter;
    const matchesDate = !dateFilter || record.date === dateFilter;

    return matchesSearch && matchesStatus && matchesDate;
  });

  const handleCreateAttendance = async (formData: FormData) => {
    try {
      const attendanceData = {
        employee_id: formData.get('employee_id') as string,
        date: formData.get('date') as string,
        check_in: formData.get('check_in') as string || null,
        check_out: formData.get('check_out') as string || null,
        status: formData.get('status') as string || null,
        notes: formData.get('notes') as string,
      };

      const { error } = await supabase
        .from('attendance')
        .insert([attendanceData]);

      if (error) throw error;

      toast({
        title: "Success",
        description: "Attendance record created successfully",
      });

      setIsCreateDialogOpen(false);
      fetchAttendance();
    } catch (error) {
      console.error('Error creating attendance:', error);
      toast({
        title: "Error",
        description: "Failed to create attendance record",
        variant: "destructive",
      });
    }
  };

  const handleUpdateAttendance = async (formData: FormData) => {
    if (!editingAttendance) return;

    try {
      const attendanceData = {
        employee_id: formData.get('employee_id') as string,
        date: formData.get('date') as string,
        check_in: formData.get('check_in') as string || null,
        check_out: formData.get('check_out') as string || null,
        status: formData.get('status') as string || null,
        notes: formData.get('notes') as string,
      };

      const { error } = await supabase
        .from('attendance')
        .update(attendanceData)
        .eq('id', editingAttendance.id);

      if (error) throw error;

      toast({
        title: "Success",
        description: "Attendance record updated successfully",
      });

      setEditingAttendance(null);
      fetchAttendance();
    } catch (error) {
      console.error('Error updating attendance:', error);
      toast({
        title: "Error",
        description: "Failed to update attendance record",
        variant: "destructive",
      });
    }
  };

  const handleDeleteAttendance = async (attendanceId: string) => {
    try {
      const { error } = await supabase
        .from('attendance')
        .delete()
        .eq('id', attendanceId);

      if (error) throw error;

      toast({
        title: "Success",
        description: "Attendance record deleted successfully",
      });

      fetchAttendance();
    } catch (error) {
      console.error('Error deleting attendance:', error);
      toast({
        title: "Error",
        description: "Failed to delete attendance record",
        variant: "destructive",
      });
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
          <p className="mt-2 text-muted-foreground">Loading attendance records...</p>
        </div>
      </div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-6"
    >
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Attendance</h1>
          <p className="text-muted-foreground">
            Track employee attendance and working hours
          </p>
        </div>
        <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="h-4 w-4 mr-2" />
              Add Attendance
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>Create Attendance Record</DialogTitle>
            </DialogHeader>
            <AttendanceForm
              employees={employees}
              onSubmit={handleCreateAttendance}
            />
          </DialogContent>
        </Dialog>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search by employee name or code..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-full sm:w-48">
                <Filter className="h-4 w-4 mr-2" />
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="present">Present</SelectItem>
                <SelectItem value="absent">Absent</SelectItem>
                <SelectItem value="late">Late</SelectItem>
                <SelectItem value="half_day">Half Day</SelectItem>
              </SelectContent>
            </Select>
            <div className="w-full sm:w-48">
              <Input
                type="date"
                placeholder="Filter by date"
                value={dateFilter}
                onChange={(e) => setDateFilter(e.target.value)}
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Attendance Table */}
      <Card className="flex flex-col h-[calc(100vh-12rem)]">
        <CardHeader className="flex-shrink-0">
          <CardTitle>All Attendance Records ({filteredAttendance.length})</CardTitle>
        </CardHeader>
        <CardContent className="flex-1 overflow-hidden p-0">
          <div className="h-full overflow-y-auto">
            <Table>
              <TableHeader className="sticky top-0 bg-background z-10">
                <TableRow>
                  <TableHead>Employee</TableHead>
                  <TableHead>Date</TableHead>
                  <TableHead>Check In</TableHead>
                  <TableHead>Check Out</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Notes</TableHead>
                  <TableHead className="w-12"></TableHead>
                </TableRow>
              </TableHeader>
            <TableBody>
              {filteredAttendance.map((record) => (
                <TableRow key={record.id}>
                  <TableCell className="font-medium">
                    <div className="flex items-center gap-2">
                      <Clock className="h-4 w-4 text-muted-foreground" />
                      {record.employees?.full_name} ({record.employees?.employee_code})
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-1">
                      <Calendar className="h-3 w-3 text-muted-foreground" />
                      {new Date(record.date).toLocaleDateString()}
                    </div>
                  </TableCell>
                  <TableCell>
                    {record.check_in ? new Date(record.check_in).toLocaleTimeString() : "-"}
                  </TableCell>
                  <TableCell>
                    {record.check_out ? new Date(record.check_out).toLocaleTimeString() : "-"}
                  </TableCell>
                  <TableCell>
                    {record.status && (
                      <Badge className={statusColors[record.status]}>
                        {statusLabels[record.status]}
                      </Badge>
                    )}
                  </TableCell>
                  <TableCell>
                    <span className="truncate max-w-32" title={record.notes || ""}>
                      {record.notes || "No notes"}
                    </span>
                  </TableCell>
                  <TableCell>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="sm">
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem onClick={() => setViewingAttendance(record)}>
                          <Eye className="h-4 w-4 mr-2" />
                          View Details
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => setEditingAttendance(record)}>
                          <Edit className="h-4 w-4 mr-2" />
                          Edit
                        </DropdownMenuItem>
                        <DropdownMenuItem
                          onClick={() => handleDeleteAttendance(record.id)}
                          className="text-destructive"
                        >
                          <Trash2 className="h-4 w-4 mr-2" />
                          Delete
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>

          {filteredAttendance.length === 0 && (
            <div className="text-center py-8">
              <p className="text-muted-foreground">No attendance records found</p>
            </div>
          )}
          </div>
        </CardContent>
      </Card>

      {/* Edit Dialog */}
      <Dialog open={!!editingAttendance} onOpenChange={() => setEditingAttendance(null)}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Edit Attendance Record</DialogTitle>
          </DialogHeader>
          {editingAttendance && (
            <AttendanceForm
              initialData={editingAttendance}
              employees={employees}
              onSubmit={handleUpdateAttendance}
              onCancel={() => setEditingAttendance(null)}
            />
          )}
        </DialogContent>
      </Dialog>

      {/* View Attendance Sheet */}
      <Sheet open={!!viewingAttendance} onOpenChange={() => setViewingAttendance(null)}>
        <SheetContent className="w-full sm:max-w-2xl overflow-y-auto">
          <SheetHeader>
            <SheetTitle className="flex items-center gap-2">
              <Clock className="h-5 w-5" />
              Attendance Details
            </SheetTitle>
          </SheetHeader>
          {viewingAttendance && (
            <div className="space-y-6 mt-6">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-sm font-medium text-muted-foreground">Employee</Label>
                  <p className="text-sm font-medium">{viewingAttendance.employees?.full_name} ({viewingAttendance.employees?.employee_code})</p>
                </div>
                <div>
                  <Label className="text-sm font-medium text-muted-foreground">Date</Label>
                  <p className="text-sm font-medium">{new Date(viewingAttendance.date).toLocaleDateString()}</p>
                </div>
                <div>
                  <Label className="text-sm font-medium text-muted-foreground">Check In</Label>
                  <p className="text-sm font-medium">{viewingAttendance.check_in ? new Date(viewingAttendance.check_in).toLocaleTimeString() : 'Not recorded'}</p>
                </div>
                <div>
                  <Label className="text-sm font-medium text-muted-foreground">Check Out</Label>
                  <p className="text-sm font-medium">{viewingAttendance.check_out ? new Date(viewingAttendance.check_out).toLocaleTimeString() : 'Not recorded'}</p>
                </div>
                <div>
                  <Label className="text-sm font-medium text-muted-foreground">Status</Label>
                  <Badge className={statusColors[viewingAttendance.status as keyof typeof statusColors]}>
                    {statusLabels[viewingAttendance.status as keyof typeof statusLabels]}
                  </Badge>
                </div>
                <div>
                  <Label className="text-sm font-medium text-muted-foreground">Created</Label>
                  <p className="text-sm font-medium">{new Date(viewingAttendance.created_at).toLocaleString()}</p>
                </div>
              </div>
              {viewingAttendance.notes && (
                <div>
                  <Label className="text-sm font-medium text-muted-foreground">Notes</Label>
                  <p className="text-sm mt-1">{viewingAttendance.notes}</p>
                </div>
              )}
            </div>
          )}
        </SheetContent>
      </Sheet>
    </motion.div>
  );
}
