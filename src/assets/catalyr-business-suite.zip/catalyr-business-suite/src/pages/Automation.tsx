import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Plus, Search, Play, Pause, Settings, Zap, Clock, CheckCircle, XCircle, Eye } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";

type Automation = {
  id: string;
  name: string;
  description: string | null;
  trigger_type: 'schedule' | 'event' | 'condition';
  trigger_config: any;
  actions: any[];
  is_active: boolean;
  last_run: string | null;
  next_run: string | null;
  created_by: string;
  created_at: string;
  updated_at: string;
};

function AutomationForm({
  initialData,
  onSubmit,
  onCancel
}: {
  initialData?: Automation;
  onSubmit: (formData: FormData) => void;
  onCancel?: () => void;
}) {
  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    onSubmit(formData);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="name">Automation Name *</Label>
        <Input
          id="name"
          name="name"
          required
          defaultValue={initialData?.name}
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="trigger_type">Trigger Type *</Label>
        <Select name="trigger_type" defaultValue={initialData?.trigger_type || "schedule"} required>
          <SelectTrigger>
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="schedule">Schedule</SelectItem>
            <SelectItem value="event">Event</SelectItem>
            <SelectItem value="condition">Condition</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-2">
        <Label htmlFor="description">Description</Label>
        <Textarea
          id="description"
          name="description"
          defaultValue={initialData?.description || ""}
          rows={3}
          placeholder="Describe what this automation does..."
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="schedule">Schedule (for scheduled triggers)</Label>
        <Input
          id="schedule"
          name="schedule"
          defaultValue={initialData?.trigger_config?.schedule || ""}
          placeholder="e.g., daily at 9:00 AM, every Monday"
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="actions">Actions (comma-separated)</Label>
        <Input
          id="actions"
          name="actions"
          defaultValue={initialData?.actions?.join(', ') || ""}
          placeholder="e.g., send email, create task, update record"
        />
      </div>

      <div className="flex items-center space-x-2">
        <Switch
          id="is_active"
          name="is_active"
          defaultChecked={initialData?.is_active ?? true}
        />
        <Label htmlFor="is_active">Active</Label>
      </div>

      <div className="flex gap-2 pt-4">
        <Button type="submit" className="flex-1">
          {initialData ? "Update Automation" : "Create Automation"}
        </Button>
        {onCancel && (
          <Button type="button" variant="outline" onClick={onCancel}>
            Cancel
          </Button>
        )}
      </div>
    </form>
  );
}

export default function Automation() {
  const [automations, setAutomations] = useState<Automation[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [editingAutomation, setEditingAutomation] = useState<Automation | null>(null);
  const [viewingAutomation, setViewingAutomation] = useState<Automation | null>(null);
  const { toast } = useToast();

  useEffect(() => {
    fetchAutomations();
  }, []);

  const fetchAutomations = async () => {
    try {
      // For now, we'll use mock data since automations table might not exist
      // In a real implementation, this would fetch from an automations table
      const mockAutomations: Automation[] = [
        {
          id: '1',
          name: 'Daily Report Generation',
          description: 'Automatically generate and send daily sales reports',
          trigger_type: 'schedule',
          trigger_config: { schedule: 'daily at 8:00 AM' },
          actions: ['generate report', 'send email'],
          is_active: true,
          last_run: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(),
          next_run: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(),
          created_by: 'user1',
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        },
        {
          id: '2',
          name: 'Lead Follow-up Reminder',
          description: 'Send reminder emails for leads that haven\'t been contacted in 7 days',
          trigger_type: 'schedule',
          trigger_config: { schedule: 'weekly on Monday' },
          actions: ['check leads', 'send reminder'],
          is_active: true,
          last_run: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString(),
          next_run: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(),
          created_by: 'user2',
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        },
        {
          id: '3',
          name: 'Deal Stage Update',
          description: 'Automatically update deal stages based on activity',
          trigger_type: 'condition',
          trigger_config: { condition: 'no activity for 30 days' },
          actions: ['update stage', 'notify manager'],
          is_active: false,
          last_run: null,
          next_run: null,
          created_by: 'user1',
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        },
      ];

      setAutomations(mockAutomations);
    } catch (error) {
      console.error('Error fetching automations:', error);
      toast({
        title: "Error",
        description: "Failed to fetch automations",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const filteredAutomations = automations.filter((automation) => {
    const matchesSearch =
      automation.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      automation.description?.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesStatus = statusFilter === "all" ||
      (statusFilter === "active" && automation.is_active) ||
      (statusFilter === "inactive" && !automation.is_active);

    return matchesSearch && matchesStatus;
  });

  const handleCreateAutomation = async (formData: FormData) => {
    try {
      const actions = (formData.get('actions') as string)?.split(',').map(action => action.trim()).filter(Boolean) || [];

      const automationData: Automation = {
        id: Date.now().toString(),
        name: formData.get('name') as string,
        description: formData.get('description') as string,
        trigger_type: formData.get('trigger_type') as string as Automation['trigger_type'],
        trigger_config: {
          schedule: formData.get('schedule') as string,
        },
        actions,
        is_active: formData.get('is_active') === 'on',
        last_run: null,
        next_run: null,
        created_by: 'current-user', // In real implementation, get from auth
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      };

      // In a real implementation, this would save to database
      setAutomations(prev => [automationData, ...prev]);

      toast({
        title: "Success",
        description: "Automation created successfully",
      });

      setIsCreateDialogOpen(false);
    } catch (error) {
      console.error('Error creating automation:', error);
      toast({
        title: "Error",
        description: "Failed to create automation",
        variant: "destructive",
      });
    }
  };

  const handleUpdateAutomation = async (formData: FormData) => {
    if (!editingAutomation) return;

    try {
      const actions = (formData.get('actions') as string)?.split(',').map(action => action.trim()).filter(Boolean) || [];

      const updatedAutomation: Automation = {
        ...editingAutomation,
        name: formData.get('name') as string,
        description: formData.get('description') as string,
        trigger_type: formData.get('trigger_type') as string as Automation['trigger_type'],
        trigger_config: {
          schedule: formData.get('schedule') as string,
        },
        actions,
        is_active: formData.get('is_active') === 'on',
        updated_at: new Date().toISOString(),
      };

      // In a real implementation, this would update the database
      setAutomations(prev =>
        prev.map(a => a.id === editingAutomation.id ? updatedAutomation : a)
      );

      toast({
        title: "Success",
        description: "Automation updated successfully",
      });

      setEditingAutomation(null);
    } catch (error) {
      console.error('Error updating automation:', error);
      toast({
        title: "Error",
        description: "Failed to update automation",
        variant: "destructive",
      });
    }
  };

  const handleDeleteAutomation = async (automationId: string) => {
    try {
      // In a real implementation, this would delete from database
      setAutomations(prev => prev.filter(a => a.id !== automationId));

      toast({
        title: "Success",
        description: "Automation deleted successfully",
      });
    } catch (error) {
      console.error('Error deleting automation:', error);
      toast({
        title: "Error",
        description: "Failed to delete automation",
        variant: "destructive",
      });
    }
  };

  const handleToggleAutomation = async (automationId: string, isActive: boolean) => {
    try {
      // In a real implementation, this would update the database
      setAutomations(prev =>
        prev.map(a =>
          a.id === automationId
            ? { ...a, is_active: isActive, updated_at: new Date().toISOString() }
            : a
        )
      );

      toast({
        title: "Success",
        description: `Automation ${isActive ? 'activated' : 'deactivated'} successfully`,
      });
    } catch (error) {
      console.error('Error toggling automation:', error);
      toast({
        title: "Error",
        description: "Failed to update automation status",
        variant: "destructive",
      });
    }
  };

  const handleRunAutomation = async (automationId: string) => {
    try {
      // In a real implementation, this would trigger the automation
      setAutomations(prev =>
        prev.map(a =>
          a.id === automationId
            ? { ...a, last_run: new Date().toISOString() }
            : a
        )
      );

      toast({
        title: "Success",
        description: "Automation executed successfully",
      });
    } catch (error) {
      console.error('Error running automation:', error);
      toast({
        title: "Error",
        description: "Failed to execute automation",
        variant: "destructive",
      });
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
          <p className="mt-2 text-muted-foreground">Loading automations...</p>
        </div>
      </div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-6"
    >
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Automation</h1>
          <p className="text-muted-foreground">
            Create and manage automated workflows
          </p>
        </div>
        <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="h-4 w-4 mr-2" />
              New Automation
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Create New Automation</DialogTitle>
            </DialogHeader>
            <AutomationForm
              onSubmit={handleCreateAutomation}
            />
          </DialogContent>
        </Dialog>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Automations</CardTitle>
            <Zap className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{automations.length}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active</CardTitle>
            <CheckCircle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {automations.filter(a => a.is_active).length}
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Scheduled</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {automations.filter(a => a.trigger_type === 'schedule').length}
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Last 24h Runs</CardTitle>
            <Play className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {automations.filter(a => {
                if (!a.last_run) return false;
                const lastRun = new Date(a.last_run);
                const oneDayAgo = new Date(Date.now() - 24 * 60 * 60 * 1000);
                return lastRun >= oneDayAgo;
              }).length}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search automations..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-full sm:w-48">
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="active">Active</SelectItem>
                <SelectItem value="inactive">Inactive</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Automations Table */}
      <Card className="h-[calc(100vh-12rem)]">
        <CardHeader>
          <CardTitle>All Automations ({filteredAutomations.length})</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-y-auto h-full">
          <Table>
            <TableHeader className="sticky top-0 bg-background z-10">
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead>Trigger</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Last Run</TableHead>
                <TableHead>Next Run</TableHead>
                <TableHead className="w-12">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredAutomations.map((automation) => (
                <TableRow key={automation.id}>
                  <TableCell className="font-medium">
                    <div>
                      <div className="font-medium">{automation.name}</div>
                      <div className="text-sm text-muted-foreground">
                        {automation.description}
                      </div>
                    </div>
                  </TableCell>
                  <TableCell>
                    <Badge variant="outline">
                      {automation.trigger_type}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <Switch
                        checked={automation.is_active}
                        onCheckedChange={(checked) => handleToggleAutomation(automation.id, checked)}
                      />
                      <span className={`text-sm ${automation.is_active ? 'text-green-600' : 'text-red-600'}`}>
                        {automation.is_active ? 'Active' : 'Inactive'}
                      </span>
                    </div>
                  </TableCell>
                  <TableCell>
                    {automation.last_run
                      ? new Date(automation.last_run).toLocaleString()
                      : 'Never'
                    }
                  </TableCell>
                  <TableCell>
                    {automation.next_run
                      ? new Date(automation.next_run).toLocaleString()
                      : 'Not scheduled'
                    }
                  </TableCell>
                  <TableCell>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="sm">
                          <Settings className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem onClick={() => setViewingAutomation(automation)}>
                          <Eye className="h-4 w-4 mr-2" />
                          View Details
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => handleRunAutomation(automation.id)}>
                          <Play className="h-4 w-4 mr-2" />
                          Run Now
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => setEditingAutomation(automation)}>
                          <Settings className="h-4 w-4 mr-2" />
                          Edit Automation
                        </DropdownMenuItem>
                        <DropdownMenuItem
                          onClick={() => handleDeleteAutomation(automation.id)}
                          className="text-destructive"
                        >
                          <XCircle className="h-4 w-4 mr-2" />
                          Delete
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
          </div>

          {filteredAutomations.length === 0 && (
            <div className="text-center py-8">
              <Zap className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <p className="text-muted-foreground">No automations found</p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Edit Dialog */}
      <Dialog open={!!editingAutomation} onOpenChange={() => setEditingAutomation(null)}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Edit Automation</DialogTitle>
          </DialogHeader>
          {editingAutomation && (
            <AutomationForm
              initialData={editingAutomation}
              onSubmit={handleUpdateAutomation}
              onCancel={() => setEditingAutomation(null)}
            />
          )}
        </DialogContent>
      </Dialog>

      {/* View Details Sheet */}
      <Sheet open={!!viewingAutomation} onOpenChange={() => setViewingAutomation(null)}>
        <SheetContent>
          <SheetHeader>
            <SheetTitle>Automation Details</SheetTitle>
            <SheetDescription>
              View detailed information about this automation.
            </SheetDescription>
          </SheetHeader>
          {viewingAutomation && (
            <div className="space-y-6 mt-6">
              <div>
                <Label className="text-sm font-medium">Name</Label>
                <p className="text-sm text-muted-foreground mt-1">
                  {viewingAutomation.name}
                </p>
              </div>
              <div>
                <Label className="text-sm font-medium">Description</Label>
                <p className="text-sm text-muted-foreground mt-1">
                  {viewingAutomation.description || 'No description provided'}
                </p>
              </div>
              <div>
                <Label className="text-sm font-medium">Trigger Type</Label>
                <p className="text-sm text-muted-foreground mt-1">
                  {viewingAutomation.trigger_type}
                </p>
              </div>
              <div>
                <Label className="text-sm font-medium">Status</Label>
                <p className="text-sm text-muted-foreground mt-1">
                  {viewingAutomation.is_active ? 'Active' : 'Inactive'}
                </p>
              </div>
              <div>
                <Label className="text-sm font-medium">Last Run</Label>
                <p className="text-sm text-muted-foreground mt-1">
                  {viewingAutomation.last_run
                    ? new Date(viewingAutomation.last_run).toLocaleString()
                    : 'Never'
                  }
                </p>
              </div>
              <div>
                <Label className="text-sm font-medium">Next Run</Label>
                <p className="text-sm text-muted-foreground mt-1">
                  {viewingAutomation.next_run
                    ? new Date(viewingAutomation.next_run).toLocaleString()
                    : 'Not scheduled'
                  }
                </p>
              </div>
              <div>
                <Label className="text-sm font-medium">Actions</Label>
                <div className="text-sm text-muted-foreground mt-1">
                  {viewingAutomation.actions && viewingAutomation.actions.length > 0
                    ? viewingAutomation.actions.join(', ')
                    : 'No actions defined'
                  }
                </div>
              </div>
            </div>
          )}
        </SheetContent>
      </Sheet>
    </motion.div>
  );
}
