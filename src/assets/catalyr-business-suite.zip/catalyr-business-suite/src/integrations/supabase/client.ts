// Supabase client removed - migrated to custom API
// This file is kept for type definitions only
export const supabase = null;
