import { Bell, Search, HelpCircle, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useAuth } from "@/contexts/AuthContext";
import { useLocation, Link } from "react-router-dom";

const breadcrumbMap: Record<string, { label: string; parent?: string }> = {
  "/dashboard": { label: "Dashboard" },
  "/leads": { label: "Leads", parent: "CRM" },
  "/contacts": { label: "Contacts", parent: "CRM" },
  "/companies": { label: "Companies", parent: "CRM" },
  "/deals": { label: "Deals", parent: "CRM" },
  "/activities": { label: "Activities", parent: "CRM" },
  "/employees": { label: "Employees", parent: "HRM" },
  "/attendance": { label: "Attendance", parent: "HRM" },
  "/leave": { label: "Leave Management", parent: "HRM" },
  "/payroll": { label: "Payroll", parent: "HRM" },
  "/documents": { label: "Documents", parent: "HRM" },
  "/tasks": { label: "Tasks / Todo", parent: "Productivity" },
  "/calendar": { label: "Calendar", parent: "Productivity" },
  "/reports": { label: "Reports", parent: "Management" },
  "/automation": { label: "Automation", parent: "Management" },
  "/integrations": { label: "Integrations", parent: "Management" },
  "/audit": { label: "Audit Logs", parent: "Management" },
  "/settings": { label: "Organization Settings", parent: "Settings" },
  "/user-roles": { label: "User & Roles", parent: "Settings" },
  "/permissions": { label: "Permissions", parent: "Settings" },
  "/departments": { label: "Departments", parent: "Settings" },
  "/designations": { label: "Designations", parent: "Settings" },
};

export function AppHeader() {
  const { user, signOut } = useAuth();
  const location = useLocation();

  const getBreadcrumbs = () => {
    const currentPath = location.pathname;
    const breadcrumb = breadcrumbMap[currentPath];

    if (!breadcrumb) return [];

    const breadcrumbs = [{ label: "Dashboard", href: "/dashboard" }];

    if (breadcrumb.parent) {
      breadcrumbs.push({ label: breadcrumb.parent, href: "#" });
    }

    breadcrumbs.push({ label: breadcrumb.label, href: currentPath });

    return breadcrumbs;
  };

  const breadcrumbs = getBreadcrumbs();

  return (
    <header className="flex h-16 items-center justify-between border-b border-border bg-background px-6">
      {/* Breadcrumb and Title */}
      <div className="flex items-center gap-4">
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          {breadcrumbs.map((crumb, index) => (
            <div key={index} className="flex items-center gap-2">
              {index > 0 && <ChevronRight className="h-4 w-4" />}
              {crumb.href !== "#" ? (
                <Link
                  to={crumb.href}
                  className="hover:text-foreground transition-colors"
                >
                  {crumb.label}
                </Link>
              ) : (
                <span>{crumb.label}</span>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Search */}
      <div className="relative w-full max-w-md">
        <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
        <Input
          type="search"
          placeholder="Search leads, contacts, employees..."
          className="pl-10 bg-secondary border-0 focus-visible:ring-1"
        />
      </div>

      {/* Actions */}
      <div className="flex items-center gap-2">
        <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-foreground">
          <HelpCircle className="h-5 w-5" />
        </Button>

        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="icon" className="relative text-muted-foreground hover:text-foreground">
              <Bell className="h-5 w-5" />
              <span className="absolute right-1.5 top-1.5 h-2 w-2 rounded-full bg-destructive" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-80">
            <DropdownMenuLabel>Notifications</DropdownMenuLabel>
            <DropdownMenuSeparator />
            <div className="space-y-2">
              <NotificationItem
                title="New lead created"
                description="Acme Corp added by John Smith"
                time="2 min ago"
                unread
              />
              <NotificationItem
                title="Deal moved to Negotiation"
                description="TechCorp deal updated"
                time="15 min ago"
                unread
              />
              <NotificationItem
                title="Leave request approved"
                description="Sarah Wilson's leave approved"
                time="1 hr ago"
              />
              <NotificationItem
                title="Task completed"
                description="Monthly report submitted"
                time="2 hrs ago"
              />
            </div>
            <DropdownMenuSeparator />
            <DropdownMenuItem className="w-full text-center">
              View all notifications
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>

        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="sm" className="ml-2 gap-2">
              <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary text-primary-foreground text-sm font-medium">
                {user?.email?.charAt(0).toUpperCase() || "U"}
              </div>
              <span className="hidden md:inline-block text-sm font-medium">
                {user?.user_metadata?.full_name || user?.email?.split("@")[0] || "User"}
              </span>
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-56">
            <DropdownMenuLabel>My Account</DropdownMenuLabel>
            <DropdownMenuSeparator />
            <DropdownMenuItem>Profile</DropdownMenuItem>
            <DropdownMenuItem>Settings</DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={signOut} className="text-destructive">
              Sign Out
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </header>
  );
}

function NotificationItem({
  title,
  description,
  time,
  unread = false
}: {
  title: string;
  description: string;
  time: string;
  unread?: boolean;
}) {
  return (
    <div className={`p-3 rounded-lg ${unread ? 'bg-accent' : ''}`}>
      <div className="flex items-start gap-3">
        <div className="flex-1">
          <p className="text-sm font-medium">{title}</p>
          <p className="text-xs text-muted-foreground">{description}</p>
          <p className="text-xs text-muted-foreground mt-1">{time}</p>
        </div>
        {unread && <div className="h-2 w-2 rounded-full bg-primary flex-shrink-0 mt-2" />}
      </div>
    </div>
  );
}
