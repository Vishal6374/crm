import { useState } from "react";
import { useLocation, Link } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import {
  LayoutDashboard,
  Users,
  UserCircle,
  Building2,
  TrendingUp,
  UserCheck,
  Calendar,
  Clock,
  DollarSign,
  CheckSquare,
  BarChart3,
  Settings,
  ChevronLeft,
  ChevronRight,
  ChevronDown,
  LogOut,
  Phone,
  FileText,
  StickyNote,
  FileCheck,
  Receipt,
  FolderOpen,
  Target,
  Users2,
  CalendarDays,
  AlertTriangle,
  CalendarClock,
  Zap,
  Webhook,
  Shield,
  Building,
  UserCog,
  Lock,
  Briefcase,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";

interface NavItem {
  title: string;
  href: string;
  icon: React.ElementType;
}

interface NavGroup {
  title: string;
  items: NavItem[];
}

const navigation: NavGroup[] = [
  {
    title: "🏠 Overview",
    items: [
      { title: "Dashboard", href: "/dashboard", icon: LayoutDashboard },
    ],
  },
  {
    title: "🤝 CRM",
    items: [
      { title: "Leads", href: "/leads", icon: Users },
      { title: "Contacts", href: "/contacts", icon: UserCircle },
      { title: "Companies", href: "/companies", icon: Building2 },
      { title: "Deals", href: "/deals", icon: TrendingUp },
      { title: "Activities", href: "/activities", icon: Target },
    ],
  },
  {
    title: "👥 HRM",
    items: [
      { title: "Employees", href: "/employees", icon: UserCheck },
      { title: "Attendance", href: "/attendance", icon: Clock },
      { title: "Leave Management", href: "/leave", icon: Calendar },
      { title: "Payroll", href: "/payroll", icon: DollarSign },
      { title: "Documents", href: "/documents", icon: FolderOpen },
    ],
  },
  {
    title: "🧠 Productivity",
    items: [
      { title: "Tasks / Todo", href: "/tasks", icon: CheckSquare },
      { title: "Calendar", href: "/calendar", icon: CalendarDays },
    ],
  },
  {
    title: "🛠 Management",
    items: [
      { title: "Reports", href: "/reports", icon: BarChart3 },
      { title: "Automation", href: "/automation", icon: Zap },
      { title: "Integrations", href: "/integrations", icon: Webhook },
      { title: "Audit Logs", href: "/audit", icon: Shield },
    ],
  },
  {
    title: "⚙ Settings",
    items: [
      { title: "Organization Settings", href: "/settings", icon: Building },
      { title: "User & Roles", href: "/user-roles", icon: UserCog },
      { title: "Permissions", href: "/permissions", icon: Lock },
      { title: "Departments", href: "/departments", icon: Briefcase },
      { title: "Designations", href: "/designations", icon: Users2 },
    ],
  },
];

export function AppSidebar() {
  const [collapsed, setCollapsed] = useState(false);
  const [openGroups, setOpenGroups] = useState<string[]>(["🏠 Overview", "🤝 CRM", "👥 HRM", "🧠 Productivity", "🛠 Management", "⚙ Settings"]);
  const location = useLocation();
  const { signOut, user } = useAuth();

  const toggleGroup = (title: string) => {
    setOpenGroups((prev) =>
      prev.includes(title) ? prev.filter((g) => g !== title) : [...prev, title]
    );
  };

  const isActive = (href: string) => location.pathname === href;

  return (
    <motion.aside
      initial={false}
      animate={{ width: collapsed ? 72 : 256 }}
      transition={{ duration: 0.2, ease: "easeInOut" }}
      className="flex h-screen flex-col bg-sidebar border-r border-sidebar-border"
    >
      {/* Logo */}
      <div className="flex h-16 items-center justify-between px-4 border-b border-sidebar-border">
        <AnimatePresence mode="wait">
          {!collapsed && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="flex items-center gap-2"
            >
              <span className="text-xl font-bold text-sidebar-foreground">Catalyr</span>
            </motion.div>
          )}
        </AnimatePresence>
        <Button
          variant="ghost"
          size="icon"
          onClick={() => setCollapsed(!collapsed)}
          className="text-sidebar-foreground hover:bg-sidebar-accent h-8 w-8"
        >
          {collapsed ? <ChevronRight className="h-4 w-4" /> : <ChevronLeft className="h-4 w-4" />}
        </Button>
      </div>

      {/* Navigation */}
      <nav className="flex-1 overflow-y-auto scrollbar-hide py-4 px-3">
        {navigation.map((group) => (
          <Collapsible
            key={group.title}
            open={openGroups.includes(group.title)}
            onOpenChange={() => toggleGroup(group.title)}
            className="mb-2"
          >
            {!collapsed && (
              <CollapsibleTrigger className="flex w-full items-center justify-between px-2 py-1.5 text-xs font-medium uppercase tracking-wider text-sidebar-foreground/60 hover:text-sidebar-foreground transition-colors">
                {group.title}
                <ChevronDown
                  className={cn(
                    "h-3 w-3 transition-transform",
                    openGroups.includes(group.title) && "rotate-180"
                  )}
                />
              </CollapsibleTrigger>
            )}
            <CollapsibleContent className="mt-1 space-y-1">
              {group.items.map((item) => (
                <Link
                  key={item.href}
                  to={item.href}
                  className={cn(
                    "flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-all",
                    isActive(item.href)
                      ? "bg-sidebar-accent text-sidebar-accent-foreground"
                      : "text-sidebar-foreground/70 hover:bg-sidebar-accent/50 hover:text-sidebar-foreground"
                  )}
                >
                  <item.icon className="h-5 w-5 shrink-0" />
                  <AnimatePresence mode="wait">
                    {!collapsed && (
                      <motion.span
                        initial={{ opacity: 0, width: 0 }}
                        animate={{ opacity: 1, width: "auto" }}
                        exit={{ opacity: 0, width: 0 }}
                        className="truncate"
                      >
                        {item.title}
                      </motion.span>
                    )}
                  </AnimatePresence>
                </Link>
              ))}
            </CollapsibleContent>
          </Collapsible>
        ))}
      </nav>

      {/* User & Logout */}
      <div className="border-t border-sidebar-border p-3">
        <div className={cn("flex items-center gap-3", collapsed && "justify-center")}>
          <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-sidebar-accent text-sidebar-accent-foreground text-sm font-medium">
            {user?.email?.charAt(0).toUpperCase() || "U"}
          </div>
          <AnimatePresence mode="wait">
            {!collapsed && (
              <motion.div
                initial={{ opacity: 0, width: 0 }}
                animate={{ opacity: 1, width: "auto" }}
                exit={{ opacity: 0, width: 0 }}
                className="flex-1 overflow-hidden"
              >
                <p className="truncate text-sm font-medium text-sidebar-foreground">
                  {user?.user_metadata?.full_name || user?.email?.split("@")[0] || "User"}
                </p>
                <p className="truncate text-xs text-sidebar-foreground/60">
                  {user?.email}
                </p>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
        <Button
          variant="ghost"
          onClick={signOut}
          className={cn(
            "mt-3 w-full justify-start gap-3 text-sidebar-foreground/70 hover:bg-sidebar-accent hover:text-sidebar-foreground",
            collapsed && "justify-center px-0"
          )}
        >
          <LogOut className="h-5 w-5 shrink-0" />
          {!collapsed && <span>Sign Out</span>}
        </Button>
      </div>
    </motion.aside>
  );
}
