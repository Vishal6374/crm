type Company = {
  id: string;
  name: string;
  industry?: string;
  website?: string;
  phone?: string;
  email?: string;
  city?: string;
  country?: string;
  address?: string;
  notes?: string;
  createdBy: string;
  createdAt: string;
  updatedAt: string;
};

type CompanyInsert = Omit<Company, 'id' | 'createdAt' | 'updatedAt'>;
type CompanyUpdate = Partial<CompanyInsert>;

const API_BASE = 'http://localhost:3001/api';

const getAuthHeaders = () => {
  const token = localStorage.getItem('token');
  return token ? { Authorization: `Bearer ${token}` } : {};
};

export const companiesService = {
  async list(opts: any = {}) {
    const { page = 0, perPage = 50 } = opts;
    const response = await fetch(`${API_BASE}/companies`);
    if (!response.ok) throw new Error('Failed to fetch companies');
    const data = await response.json();
    return data as Company[];
  },

  async get(id: string) {
    const response = await fetch(`${API_BASE}/companies/${id}`);
    if (!response.ok) throw new Error('Failed to fetch company');
    const data = await response.json();
    return data as Company;
  },

  async create(payload: CompanyInsert) {
    const response = await fetch(`${API_BASE}/companies`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    if (!response.ok) throw new Error('Failed to create company');
    const data = await response.json();
    await logActivity('create', 'companies', (data as any).id, { name: (data as any).name });
    return data as Company;
  },

  async update(id: string, updates: CompanyUpdate) {
    const response = await fetch(`${API_BASE}/companies/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(updates)
    });
    if (!response.ok) throw new Error('Failed to update company');
    const data = await response.json();
    await logActivity('update', 'companies', id, updates);
    return data as Company;
  },

  async remove(id: string) {
    const company = await this.get(id);
    const response = await fetch(`${API_BASE}/companies/${id}`, {
      method: 'DELETE'
    });
    if (!response.ok) throw new Error('Failed to delete company');
    await logActivity('delete', 'companies', id, { name: (company as any).name });
    return true;
  },

  async getStats() {
    const response = await fetch(`${API_BASE}/companies/stats`);
    if (!response.ok) throw new Error('Failed to fetch company stats');
    return response.json();
  },
};