import { supabase } from "@/integrations/supabase/client";

export const payrollService = {
  list: async (filters?: { year?: number; status?: string }) => {
    let query = supabase
      .from('payroll')
      .select('*')
      .order('year', { ascending: false });
    if (filters?.year) {
      query = query.eq('year', filters.year);
    }
    if (filters?.status) {
      query = query.eq('status', filters.status);
    }
    const { data, error } = await query;
    if (error) throw error;
    return data;
  },

  get: async (id: string) => {
    const { data, error } = await supabase
      .from('payroll')
      .select(`
        *,
        employees (
          id,
          full_name,
          employee_code,
          email,
          departments (
            id,
            name
          )
        )
      `)
      .eq('id', id)
      .single();
    if (error) throw error;
    return data;
  },

  create: async (payload: any) => {
    // Check if payroll already exists for this employee/month/year
    const { data: existing, error: checkError } = await supabase
      .from('payroll')
      .select('id')
      .eq('employee_id', payload.employee_id)
      .eq('month', payload.month)
      .eq('year', payload.year)
      .single();
    if (checkError && checkError.code !== 'PGRST116') throw checkError;
    if (existing) {
      throw new Error('Payroll already exists for this employee and period');
    }
    const { data, error } = await supabase
      .from('payroll')
      .insert(payload)
      .select()
      .single();
    if (error) throw error;
    // Log activity
    await this.logActivity('create', 'payroll', data.id, {
      employee_id: data.employee_id,
      month: data.month,
      year: data.year,
      net_salary: data.net_salary
    });
    return data;
  },

  update: async (id: string, payload: any) => {
    const { data, error } = await supabase
      .from('payroll')
      .update(payload)
      .eq('id', id)
      .select()
      .single();
    if (error) throw error;
    // Log activity
    await this.logActivity('update', 'payroll', id, payload);
    return data;
  },

  remove: async (id: string) => {
    const { data: payroll, error: fetchError } = await supabase
      .from('payroll')
      .select('employee_id, month, year, net_salary')
      .eq('id', id)
      .single();
    if (fetchError) throw fetchError;
    const { error } = await supabase
      .from('payroll')
      .delete()
      .eq('id', id);
    if (error) throw error;
    // Log activity
    await this.logActivity('delete', 'payroll', id, {
      employee_id: payroll.employee_id,
      month: payroll.month,
      year: payroll.year,
      net_salary: payroll.net_salary
    });
  },

  // Mark payroll as paid
  markAsPaid: async (id: string) => {
    const { data, error } = await supabase
      .from('payroll')
      .update({
        status: 'paid',
        paid_at: new Date().toISOString()
      })
      .eq('id', id)
      .select()
      .single();
    if (error) throw error;
    // Log activity
    await this.logActivity('mark_paid', 'payroll', id, {
      employee_id: data.employee_id,
      month: data.month,
      year: data.year,
      net_salary: data.net_salary
    });
    return data;
  },

  // Get payroll for current user
  getMyPayroll: async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) throw new Error('Not authenticated');
    const { data, error } = await supabase
      .from('payroll')
      .select('*')
      .eq('employee_id', user.id)
      .order('year', { ascending: false })
      .order('month', { ascending: false });
    if (error) throw error;
    return data;
  },

  // Generate payroll for all employees
  generatePayrollForMonth: async (month: number, year: number) => {
    // Get all active employees
    const { data: employees, error: empError } = await supabase
      .from('employees')
      .select('id, salary')
      .eq('status', 'active');
    if (empError) throw empError;
    const payrollRecords = employees
      .filter((emp: any) => emp.salary && emp.salary > 0)
      .map((employee: any) => ({
        employee_id: employee.id,
        month,
        year,
        basic_salary: employee.salary,
        deductions: 0, // Default deductions
        bonus: 0, // Default bonus
        net_salary: employee.salary // For now, net = basic
      }));
    const { data, error } = await supabase
      .from('payroll')
      .insert(payrollRecords)
      .select();
    if (error) throw error;
    // Log activity
    await this.logActivity('bulk_generate', 'payroll', 'bulk', {
      month,
      year,
      count: payrollRecords.length
    });
    return data;
  },

  // Get payroll statistics
  getPayrollStats: async (month?: number, year?: number) => {
    let query = supabase
      .from('payroll')
      .select('basic_salary, deductions, bonus, net_salary, status');
    if (month && year) {
      query = query.eq('month', month).eq('year', year);
    }
    const { data, error } = await query;
    if (error) throw error;
    const stats = {
      total: data.length,
      paid: data.filter((p: any) => p.status === 'paid').length,
      pending: data.filter((p: any) => p.status === 'pending').length,
      totalBasicSalary: data.reduce((sum: number, p: any) => sum + p.basic_salary, 0),
      totalDeductions: data.reduce((sum: number, p: any) => sum + (p.deductions || 0), 0),
      totalBonus: data.reduce((sum: number, p: any) => sum + (p.bonus || 0), 0),
      totalNetSalary: data.reduce((sum: number, p: any) => sum + p.net_salary, 0),
      avgBasicSalary: data.length > 0 ?
        data.reduce((sum: number, p: any) => sum + p.basic_salary, 0) / data.length : 0,
      avgNetSalary: data.length > 0 ?
        data.reduce((sum: number, p: any) => sum + p.net_salary, 0) / data.length : 0
    };
    return stats;
  },

  // Calculate salary components
  calculateSalary: (basicSalary: number, deductions: number = 0, bonus: number = 0) => {
    return {
      basic: basicSalary,
      deductions,
      bonus,
      net: basicSalary - deductions + bonus,
      hra: Math.round(basicSalary * 0.4), // House Rent Allowance
      conveyance: Math.min(19200, Math.round(basicSalary * 0.1)), // Conveyance Allowance
      lta: Math.round(basicSalary * 0.0833), // Leave Travel Allowance
      medical: 15000, // Medical Allowance
      providentFund: Math.round(basicSalary * 0.12), // Employee PF contribution
      gratuity: Math.round(basicSalary * 0.0481) // Gratuity
    };
  },

  // Get salary slip data
  getSalarySlip: async (employeeId: string, month: number, year: number) => {
    const { data, error } = await supabase
      .from('payroll')
      .select(`
        *,
        employees (
          id,
          full_name,
          employee_code,
          departments (
            id,
            name
          ),
          designations (
            id,
            name
          )
        )
      `)
      .eq('employee_id', employeeId)
      .eq('month', month)
      .eq('year', year)
      .single();
    if (error) throw error;
    const salaryBreakdown = this.calculateSalary(
      data.basic_salary,
      data.deductions || 0,
      data.bonus || 0
    );
    return {
      ...data,
      salaryBreakdown
    };
  },

  // Log activity
  logActivity: async (action: string, entityType: string, entityId: string, details?: any) => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;
      await supabase
        .from('activity_logs')
        .insert({
          action,
          entity_type: entityType,
          entity_id: entityId,
          user_id: user.id,
          details
        });
    } catch (error) {
      console.error('Failed to log activity:', error);
    }
  }
};
