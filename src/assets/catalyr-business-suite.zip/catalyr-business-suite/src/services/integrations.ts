import { supabase } from "@/integrations/supabase/client";
import type { Database } from "@/integrations/supabase/types";

type Integration = Database['public']['Tables']['integrations']['Row'];
type IntegrationInsert = Database['public']['Tables']['integrations']['Insert'];
type IntegrationUpdate = Database['public']['Tables']['integrations']['Update'];

export const integrationsService = {
  // Get all integrations with optional filtering
  async getIntegrations(filters?: {
    status?: string;
    integration_type?: string;
    search?: string;
  }) {
    let query = supabase
      .from('integrations')
      .select(`
        *,
        creator:profiles (
          id,
          full_name,
          email
        )
      `)
      .order('created_at', { ascending: false });

    if (filters?.status) {
      query = query.eq('status', filters.status);
    }

    if (filters?.integration_type) {
      query = query.eq('integration_type', filters.integration_type);
    }

    if (filters?.search) {
      query = query.or(`name.ilike.%${filters.search}%,description.ilike.%${filters.search}%`);
    }

    const { data, error } = await query;
    if (error) throw error;
    return data;
  },

  // Get integration by ID
  async getIntegrationById(id: string) {
    const { data, error } = await supabase
      .from('integrations')
      .select(`
        *,
        creator:profiles (
          id,
          full_name,
          email
        )
      `)
      .eq('id', id)
      .single();

    if (error) throw error;
    return data;
  },

  // Create integration
  async createIntegration(integration: IntegrationInsert) {
    const { data, error } = await supabase
      .from('integrations')
      .insert(integration)
      .select()
      .single();

    if (error) throw error;

    // Log activity
    await this.logActivity('create', 'integration', data.id, {
      name: data.name,
      integration_type: data.integration_type,
      status: data.status
    });

    return data;
  },

  // Update integration
  async updateIntegration(id: string, updates: IntegrationUpdate) {
    const { data, error } = await supabase
      .from('integrations')
      .update(updates)
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;

    // Log activity
    await this.logActivity('update', 'integration', id, updates);

    return data;
  },

  // Delete integration
  async deleteIntegration(id: string) {
    const { data: integration, error: fetchError } = await supabase
      .from('integrations')
      .select('name, integration_type, status')
      .eq('id', id)
      .single();

    if (fetchError) throw fetchError;

    const { error } = await supabase
      .from('integrations')
      .delete()
      .eq('id', id);

    if (error) throw error;

    // Log activity
    await this.logActivity('delete', 'integration', id, {
      name: integration.name,
      integration_type: integration.integration_type,
      status: integration.status
    });
  },

  // Enable integration
  async enableIntegration(id: string) {
    const { data, error } = await supabase
      .from('integrations')
      .update({
        status: 'active',
        updated_at: new Date().toISOString()
      })
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;

    // Log activity
    await this.logActivity('enable', 'integration', id, {
      name: data.name
    });

    return data;
  },

  // Disable integration
  async disableIntegration(id: string) {
    const { data, error } = await supabase
      .from('integrations')
      .update({
        status: 'inactive',
        updated_at: new Date().toISOString()
      })
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;

    // Log activity
    await this.logActivity('disable', 'integration', id, {
      name: data.name
    });

    return data;
  },

  // Test integration connection
  async testIntegration(id: string) {
    const integration = await this.getIntegrationById(id);

    // Update last tested timestamp
    await supabase
      .from('integrations')
      .update({
        last_tested_at: new Date().toISOString()
      })
      .eq('id', id);

    // Here you would implement actual integration testing logic
    // For now, we'll simulate a test result
    const testResult = {
      success: true,
      message: 'Integration test successful',
      response_time: Math.random() * 1000 + 100, // Random response time
      tested_at: new Date().toISOString()
    };

    // Update test status
    await supabase
      .from('integrations')
      .update({
        test_status: testResult.success ? 'success' : 'failed',
        last_test_result: testResult
      })
      .eq('id', id);

    // Log activity
    await this.logActivity('test', 'integration', id, {
      name: integration.name,
      test_result: testResult
    });

    return testResult;
  },

  // Sync integration data
  async syncIntegration(id: string) {
    const integration = await this.getIntegrationById(id);

    // Update last synced timestamp
    const { data, error } = await supabase
      .from('integrations')
      .update({
        last_synced_at: new Date().toISOString(),
        sync_status: 'in_progress'
      })
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;

    // Here you would implement actual sync logic based on integration type
    // For now, we'll simulate sync completion
    setTimeout(async () => {
      await supabase
        .from('integrations')
        .update({
          sync_status: 'completed',
          last_sync_result: {
            success: true,
            records_synced: Math.floor(Math.random() * 100) + 1,
            synced_at: new Date().toISOString()
          }
        })
        .eq('id', id);
    }, 2000);

    // Log activity
    await this.logActivity('sync', 'integration', id, {
      name: integration.name,
      integration_type: integration.integration_type
    });

    return data;
  },

  // Get integration statistics
  async getIntegrationStats() {
    const { data, error } = await supabase
      .from('integrations')
      .select('status, integration_type, test_status, sync_status');

    if (error) throw error;

    const stats = {
      total: data.length,
      active: data.filter(i => i.status === 'active').length,
      inactive: data.filter(i => i.status === 'inactive').length,
      error: data.filter(i => i.status === 'error').length,
      byType: data.reduce((acc, integration) => {
        acc[integration.integration_type] = (acc[integration.integration_type] || 0) + 1;
        return acc;
      }, {} as Record<string, number>),
      testSuccess: data.filter(i => i.test_status === 'success').length,
      testFailed: data.filter(i => i.test_status === 'failed').length,
      syncCompleted: data.filter(i => i.sync_status === 'completed').length,
      syncInProgress: data.filter(i => i.sync_status === 'in_progress').length,
      syncFailed: data.filter(i => i.sync_status === 'failed').length
    };

    return stats;
  },

  // Get integrations by type
  async getIntegrationsByType(integrationType: string) {
    const { data, error } = await supabase
      .from('integrations')
      .select(`
        *,
        creator:profiles (
          id,
          full_name,
          email
        )
      `)
      .eq('integration_type', integrationType)
      .order('created_at', { ascending: false });

    if (error) throw error;
    return data;
  },

  // Get failed integrations
  async getFailedIntegrations() {
    const { data, error } = await supabase
      .from('integrations')
      .select(`
        *,
        creator:profiles (
          id,
          full_name,
          email
        )
      `)
      .or('status.eq.error,test_status.eq.failed,sync_status.eq.failed')
      .order('updated_at', { ascending: false });

    if (error) throw error;
    return data;
  },

  // Reconnect integration
  async reconnectIntegration(id: string, newConfig: any) {
    const { data, error } = await supabase
      .from('integrations')
      .update({
        config: newConfig,
        status: 'active',
        test_status: null,
        sync_status: null,
        updated_at: new Date().toISOString()
      })
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;

    // Log activity
    await this.logActivity('reconnect', 'integration', id, {
      name: data.name,
      integration_type: data.integration_type
    });

    return data;
  },

  // Get integration logs
  async getIntegrationLogs(integrationId: string, limit: number = 50) {
    const { data, error } = await supabase
      .from('activity_logs')
      .select(`
        *,
        user:profiles (
          id,
          full_name,
          email
        )
      `)
      .eq('entity_type', 'integration')
      .eq('entity_id', integrationId)
      .order('created_at', { ascending: false })
      .limit(limit);

    if (error) throw error;
    return data;
  },

  // Bulk enable/disable integrations
  async bulkUpdateStatus(integrationIds: string[], status: 'active' | 'inactive') {
    const { data, error } = await supabase
      .from('integrations')
      .update({
        status,
        updated_at: new Date().toISOString()
      })
      .in('id', integrationIds)
      .select();

    if (error) throw error;

    // Log activity for each integration
    for (const integration of data) {
      await this.logActivity(status === 'active' ? 'bulk_enable' : 'bulk_disable', 'integration', integration.id, {
        name: integration.name
      });
    }

    return data;
  },

  // Get popular integration types
  async getPopularIntegrationTypes() {
    const { data, error } = await supabase
      .from('integrations')
      .select('integration_type')
      .eq('status', 'active');

    if (error) throw error;

    const typeCount = data.reduce((acc, integration) => {
      acc[integration.integration_type] = (acc[integration.integration_type] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    return Object.entries(typeCount)
      .sort(([,a], [,b]) => b - a)
      .map(([type, count]) => ({ type, count }));
  },

  // Log activity
  async logActivity(action: string, entityType: string, entityId: string, details?: any) {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      await supabase
        .from('activity_logs')
        .insert({
          action,
          entity_type: entityType,
          entity_id: entityId,
          user_id: user.id,
          details
        });
    } catch (error) {
      console.error('Failed to log activity:', error);
    }
  }
};