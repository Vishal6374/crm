
type Task = any;
type TaskInsert = any;
type TaskUpdate = any;

const API_BASE = 'http://localhost:3001/api';

export const tasksService = {
  // Get all tasks with optional filtering
  async getTasks(filters?: {
    assigned_to?: string;
    created_by?: string;
    status?: string;
    priority?: string;
    due_date?: string;
    search?: string;
  }) {
    let query = supabase
      .from('tasks')
      .select(`
        *,
        assigned_user:profiles!tasks_assigned_to_fkey (
          id,
          full_name,
          email
        ),
        creator:profiles!tasks_created_by_fkey (
          id,
          full_name,
          email
        ),
        deals (
          id,
          title
        ),
        leads (
          id,
          title
        )
      `)
      .order('created_at', { ascending: false });

    if (filters?.assigned_to) {
      query = query.eq('assigned_to', filters.assigned_to);
    }

    if (filters?.created_by) {
      query = query.eq('created_by', filters.created_by);
    }

    if (filters?.status) {
      query = query.eq('status', filters.status);
    }

    if (filters?.priority) {
      query = query.eq('priority', filters.priority);
    }

    if (filters?.due_date) {
      query = query.eq('due_date', filters.due_date);
    }

    if (filters?.search) {
      query = query.or(`title.ilike.%${filters.search}%,description.ilike.%${filters.search}%`);
    }

    const { data, error } = await query;
    if (error) throw error;
    return data;
  },

  // Get task by ID
  async getTaskById(id: string) {
    const { data, error } = await supabase
      .from('tasks')
      .select(`
        *,
        assigned_user:profiles!tasks_assigned_to_fkey (
          id,
          full_name,
          email
        ),
        creator:profiles!tasks_created_by_fkey (
          id,
          full_name,
          email
        ),
        deals (
          id,
          title
        ),
        leads (
          id,
          title
        )
      `)
      .eq('id', id)
      .single();

    if (error) throw error;
    return data;
  },

  // Create task
  async createTask(task: TaskInsert) {
    const { data, error } = await supabase
      .from('tasks')
      .insert(task)
      .select()
      .single();

    if (error) throw error;

    // Log activity
    await this.logActivity('create', 'task', data.id, {
      title: data.title,
      assigned_to: data.assigned_to,
      priority: data.priority
    });

    return data;
  },

  // Update task
  async updateTask(id: string, updates: TaskUpdate) {
    const { data, error } = await supabase
      .from('tasks')
      .update(updates)
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;

    // Log activity
    await this.logActivity('update', 'task', id, updates);

    return data;
  },

  // Delete task
  async deleteTask(id: string) {
    const { data: task, error: fetchError } = await supabase
      .from('tasks')
      .select('title, assigned_to, status')
      .eq('id', id)
      .single();

    if (fetchError) throw fetchError;

    const { error } = await supabase
      .from('tasks')
      .delete()
      .eq('id', id);

    if (error) throw error;

    // Log activity
    await this.logActivity('delete', 'task', id, {
      title: task.title,
      assigned_to: task.assigned_to,
      status: task.status
    });
  },

  // Get tasks for current user
  async getMyTasks() {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) throw new Error('Not authenticated');

    const { data, error } = await supabase
      .from('tasks')
      .select(`
        *,
        creator:profiles!tasks_created_by_fkey (
          id,
          full_name,
          email
        ),
        deals (
          id,
          title
        ),
        leads (
          id,
          title
        )
      `)
      .eq('assigned_to', user.id)
      .order('due_date', { ascending: true, nullsFirst: false })
      .order('priority', { ascending: false });

    if (error) throw error;
    return data;
  },

  // Get tasks created by current user
  async getTasksCreatedByMe() {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) throw new Error('Not authenticated');

    const { data, error } = await supabase
      .from('tasks')
      .select(`
        *,
        assigned_user:profiles!tasks_assigned_to_fkey (
          id,
          full_name,
          email
        ),
        deals (
          id,
          title
        ),
        leads (
          id,
          title
        )
      `)
      .eq('created_by', user.id)
      .order('created_at', { ascending: false });

    if (error) throw error;
    return data;
  },

  // Update task status
  async updateTaskStatus(id: string, status: string) {
    const { data, error } = await supabase
      .from('tasks')
      .update({
        status,
        updated_at: new Date().toISOString()
      })
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;

    // Log activity
    await this.logActivity('status_update', 'task', id, {
      title: data.title,
      old_status: data.status,
      new_status: status
    });

    return data;
  },

  // Assign task to user
  async assignTask(id: string, assignedTo: string) {
    const { data, error } = await supabase
      .from('tasks')
      .update({
        assigned_to: assignedTo,
        updated_at: new Date().toISOString()
      })
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;

    // Log activity
    await this.logActivity('assign', 'task', id, {
      title: data.title,
      assigned_to: assignedTo
    });

    return data;
  },

  // Get overdue tasks
  async getOverdueTasks() {
    const today = new Date().toISOString().split('T')[0];

    const { data, error } = await supabase
      .from('tasks')
      .select(`
        *,
        assigned_user:profiles!tasks_assigned_to_fkey (
          id,
          full_name,
          email
        ),
        creator:profiles!tasks_created_by_fkey (
          id,
          full_name,
          email
        )
      `)
      .not('due_date', 'is', null)
      .lt('due_date', today)
      .neq('status', 'completed')
      .order('due_date', { ascending: true });

    if (error) throw error;
    return data;
  },

  // Get tasks due today
  async getTasksDueToday() {
    const today = new Date().toISOString().split('T')[0];

    const { data, error } = await supabase
      .from('tasks')
      .select(`
        *,
        assigned_user:profiles!tasks_assigned_to_fkey (
          id,
          full_name,
          email
        ),
        creator:profiles!tasks_created_by_fkey (
          id,
          full_name,
          email
        )
      `)
      .eq('due_date', today)
      .neq('status', 'completed')
      .order('priority', { ascending: false });

    if (error) throw error;
    return data;
  },

  // Get tasks due this week
  async getTasksDueThisWeek() {
    const today = new Date();
    const weekFromNow = new Date();
    weekFromNow.setDate(today.getDate() + 7);

    const { data, error } = await supabase
      .from('tasks')
      .select(`
        *,
        assigned_user:profiles!tasks_assigned_to_fkey (
          id,
          full_name,
          email
        ),
        creator:profiles!tasks_created_by_fkey (
          id,
          full_name,
          email
        )
      `)
      .not('due_date', 'is', null)
      .gte('due_date', today.toISOString().split('T')[0])
      .lte('due_date', weekFromNow.toISOString().split('T')[0])
      .neq('status', 'completed')
      .order('due_date', { ascending: true });

    if (error) throw error;
    return data;
  },

  // Get task statistics
  async getTaskStats(userId?: string) {
    let query = supabase
      .from('tasks')
      .select('status, priority, assigned_to');

    if (userId) {
      query = query.eq('assigned_to', userId);
    }

    const { data, error } = await query;
    if (error) throw error;

    const stats = {
      total: data.length,
      completed: data.filter(t => t.status === 'completed').length,
      inProgress: data.filter(t => t.status === 'in_progress').length,
      pending: data.filter(t => t.status === 'pending').length,
      cancelled: data.filter(t => t.status === 'cancelled').length,
      highPriority: data.filter(t => t.priority === 'high').length,
      mediumPriority: data.filter(t => t.priority === 'medium').length,
      lowPriority: data.filter(t => t.priority === 'low').length,
      completionRate: data.length > 0 ?
        (data.filter(t => t.status === 'completed').length / data.length) * 100 : 0
    };

    return stats;
  },

  // Bulk update task status
  async bulkUpdateStatus(taskIds: string[], status: string) {
    const { data, error } = await supabase
      .from('tasks')
      .update({
        status,
        updated_at: new Date().toISOString()
      })
      .in('id', taskIds)
      .select();

    if (error) throw error;

    // Log activity for each task
    for (const task of data) {
      await this.logActivity('bulk_status_update', 'task', task.id, {
        title: task.title,
        new_status: status
      });
    }

    return data;
  },

  // Get tasks by deal
  async getTasksByDeal(dealId: string) {
    const { data, error } = await supabase
      .from('tasks')
      .select(`
        *,
        assigned_user:profiles!tasks_assigned_to_fkey (
          id,
          full_name,
          email
        ),
        creator:profiles!tasks_created_by_fkey (
          id,
          full_name,
          email
        )
      `)
      .eq('deal_id', dealId)
      .order('created_at', { ascending: false });

    if (error) throw error;
    return data;
  },

  // Get tasks by lead
  async getTasksByLead(leadId: string) {
    const { data, error } = await supabase
      .from('tasks')
      .select(`
        *,
        assigned_user:profiles!tasks_assigned_to_fkey (
          id,
          full_name,
          email
        ),
        creator:profiles!tasks_created_by_fkey (
          id,
          full_name,
          email
        )
      `)
      .eq('lead_id', leadId)
      .order('created_at', { ascending: false });

    if (error) throw error;
    return data;
  },

  // Log activity
  async logActivity(action: string, entityType: string, entityId: string, details?: any) {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      await supabase
        .from('activity_logs')
        .insert({
          action,
          entity_type: entityType,
          entity_id: entityId,
          user_id: user.id,
          details
        });
    } catch (error) {
      console.error('Failed to log activity:', error);
    }
  }
};