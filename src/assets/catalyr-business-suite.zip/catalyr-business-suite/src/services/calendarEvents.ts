import { supabase } from "@/integrations/supabase/client";
import type { Database } from "@/integrations/supabase/types";

type CalendarEvent = Database['public']['Tables']['calendar_events']['Row'];
type CalendarEventInsert = Database['public']['Tables']['calendar_events']['Insert'];
type CalendarEventUpdate = Database['public']['Tables']['calendar_events']['Update'];

export const calendarEventsService = {
  // Get all calendar events with optional filtering
  async getCalendarEvents(filters?: {
    user_id?: string;
    event_type?: string;
    start_date?: string;
    end_date?: string;
    search?: string;
  }) {
    let query = supabase
      .from('calendar_events')
      .select(`
        *,
        creator:profiles!calendar_events_created_by_fkey (
          id,
          full_name,
          email
        ),
        attendees:profiles (
          id,
          full_name,
          email
        )
      `)
      .order('start_time', { ascending: true });

    if (filters?.user_id) {
      query = query.eq('created_by', filters.user_id);
    }

    if (filters?.event_type) {
      query = query.eq('event_type', filters.event_type);
    }

    if (filters?.start_date) {
      query = query.gte('start_time', filters.start_date);
    }

    if (filters?.end_date) {
      query = query.lte('start_time', filters.end_date);
    }

    if (filters?.search) {
      query = query.or(`title.ilike.%${filters.search}%,description.ilike.%${filters.search}%`);
    }

    const { data, error } = await query;
    if (error) throw error;
    return data;
  },

  // Get calendar event by ID
  async getCalendarEventById(id: string) {
    const { data, error } = await supabase
      .from('calendar_events')
      .select(`
        *,
        creator:profiles!calendar_events_created_by_fkey (
          id,
          full_name,
          email
        ),
        attendees:profiles (
          id,
          full_name,
          email
        )
      `)
      .eq('id', id)
      .single();

    if (error) throw error;
    return data;
  },

  // Create calendar event
  async createCalendarEvent(event: CalendarEventInsert) {
    const { data, error } = await supabase
      .from('calendar_events')
      .insert(event)
      .select()
      .single();

    if (error) throw error;

    // Log activity
    await this.logActivity('create', 'calendar_event', data.id, {
      title: data.title,
      event_type: data.event_type,
      start_time: data.start_time
    });

    return data;
  },

  // Update calendar event
  async updateCalendarEvent(id: string, updates: CalendarEventUpdate) {
    const { data, error } = await supabase
      .from('calendar_events')
      .update(updates)
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;

    // Log activity
    await this.logActivity('update', 'calendar_event', id, updates);

    return data;
  },

  // Delete calendar event
  async deleteCalendarEvent(id: string) {
    const { data: event, error: fetchError } = await supabase
      .from('calendar_events')
      .select('title, event_type, start_time')
      .eq('id', id)
      .single();

    if (fetchError) throw fetchError;

    const { error } = await supabase
      .from('calendar_events')
      .delete()
      .eq('id', id);

    if (error) throw error;

    // Log activity
    await this.logActivity('delete', 'calendar_event', id, {
      title: event.title,
      event_type: event.event_type,
      start_time: event.start_time
    });
  },

  // Get events for current user
  async getMyCalendarEvents(startDate?: string, endDate?: string) {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) throw new Error('Not authenticated');

    let query = supabase
      .from('calendar_events')
      .select(`
        *,
        creator:profiles!calendar_events_created_by_fkey (
          id,
          full_name,
          email
        )
      `)
      .eq('created_by', user.id)
      .order('start_time', { ascending: true });

    if (startDate) {
      query = query.gte('start_time', startDate);
    }

    if (endDate) {
      query = query.lte('start_time', endDate);
    }

    const { data, error } = await query;
    if (error) throw error;
    return data;
  },

  // Get events for a specific date
  async getEventsForDate(date: string) {
    const startOfDay = `${date}T00:00:00`;
    const endOfDay = `${date}T23:59:59`;

    const { data, error } = await supabase
      .from('calendar_events')
      .select(`
        *,
        creator:profiles!calendar_events_created_by_fkey (
          id,
          full_name,
          email
        )
      `)
      .gte('start_time', startOfDay)
      .lte('start_time', endOfDay)
      .order('start_time', { ascending: true });

    if (error) throw error;
    return data;
  },

  // Get events for a specific month
  async getEventsForMonth(year: number, month: number) {
    const startDate = new Date(year, month - 1, 1);
    const endDate = new Date(year, month, 0);

    const { data, error } = await supabase
      .from('calendar_events')
      .select(`
        *,
        creator:profiles!calendar_events_created_by_fkey (
          id,
          full_name,
          email
        )
      `)
      .gte('start_time', startDate.toISOString())
      .lte('start_time', endDate.toISOString())
      .order('start_time', { ascending: true });

    if (error) throw error;
    return data;
  },

  // Get upcoming events
  async getUpcomingEvents(limit: number = 10) {
    const { data, error } = await supabase
      .from('calendar_events')
      .select(`
        *,
        creator:profiles!calendar_events_created_by_fkey (
          id,
          full_name,
          email
        )
      `)
      .gte('start_time', new Date().toISOString())
      .order('start_time', { ascending: true })
      .limit(limit);

    if (error) throw error;
    return data;
  },

  // Get events by type
  async getEventsByType(eventType: string) {
    const { data, error } = await supabase
      .from('calendar_events')
      .select(`
        *,
        creator:profiles!calendar_events_created_by_fkey (
          id,
          full_name,
          email
        )
      `)
      .eq('event_type', eventType)
      .order('start_time', { ascending: true });

    if (error) throw error;
    return data;
  },

  // Update event attendees
  async updateEventAttendees(eventId: string, attendeeIds: string[]) {
    const { data, error } = await supabase
      .from('calendar_events')
      .update({
        attendees: attendeeIds,
        updated_at: new Date().toISOString()
      })
      .eq('id', eventId)
      .select()
      .single();

    if (error) throw error;

    // Log activity
    await this.logActivity('update_attendees', 'calendar_event', eventId, {
      title: data.title,
      attendee_count: attendeeIds.length
    });

    return data;
  },

  // Mark event as completed
  async markEventCompleted(id: string) {
    const { data, error } = await supabase
      .from('calendar_events')
      .update({
        status: 'completed',
        updated_at: new Date().toISOString()
      })
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;

    // Log activity
    await this.logActivity('complete', 'calendar_event', id, {
      title: data.title,
      event_type: data.event_type
    });

    return data;
  },

  // Cancel event
  async cancelEvent(id: string, reason?: string) {
    const { data, error } = await supabase
      .from('calendar_events')
      .update({
        status: 'cancelled',
        updated_at: new Date().toISOString()
      })
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;

    // Log activity
    await this.logActivity('cancel', 'calendar_event', id, {
      title: data.title,
      reason
    });

    return data;
  },

  // Get event statistics
  async getEventStats(userId?: string) {
    let query = supabase
      .from('calendar_events')
      .select('event_type, status, start_time');

    if (userId) {
      query = query.eq('created_by', userId);
    }

    const { data, error } = await query;
    if (error) throw error;

    const now = new Date();
    const thisMonth = data.filter(e =>
      new Date(e.start_time).getMonth() === now.getMonth() &&
      new Date(e.start_time).getFullYear() === now.getFullYear()
    );

    const stats = {
      total: data.length,
      upcoming: data.filter(e => new Date(e.start_time) > now).length,
      completed: data.filter(e => e.status === 'completed').length,
      cancelled: data.filter(e => e.status === 'cancelled').length,
      thisMonth: thisMonth.length,
      byType: data.reduce((acc, event) => {
        acc[event.event_type] = (acc[event.event_type] || 0) + 1;
        return acc;
      }, {} as Record<string, number>)
    };

    return stats;
  },

  // Check for conflicting events
  async checkEventConflicts(startTime: string, endTime: string, excludeEventId?: string) {
    let query = supabase
      .from('calendar_events')
      .select('id, title, start_time, end_time')
      .eq('status', 'scheduled')
      .or(`and(start_time.lte.${endTime},end_time.gte.${startTime})`);

    if (excludeEventId) {
      query = query.neq('id', excludeEventId);
    }

    const { data, error } = await query;
    if (error) throw error;

    return data;
  },

  // Get recurring events
  async getRecurringEvents() {
    const { data, error } = await supabase
      .from('calendar_events')
      .select(`
        *,
        creator:profiles!calendar_events_created_by_fkey (
          id,
          full_name,
          email
        )
      `)
      .not('recurrence_rule', 'is', null)
      .order('start_time', { ascending: true });

    if (error) throw error;
    return data;
  },

  // Create recurring event instances
  async createRecurringInstances(eventId: string, instances: number = 10) {
    const event = await this.getCalendarEventById(eventId);

    if (!event.recurrence_rule) {
      throw new Error('Event is not recurring');
    }

    // This is a simplified implementation
    // In a real app, you'd parse the recurrence rule (RRULE) and generate instances
    const instancesData = [];
    let currentStart = new Date(event.start_time);
    let currentEnd = new Date(event.end_time);

    for (let i = 1; i <= instances; i++) {
      // Simple daily recurrence for demo
      currentStart.setDate(currentStart.getDate() + 1);
      currentEnd.setDate(currentEnd.getDate() + 1);

      instancesData.push({
        title: event.title,
        description: event.description,
        start_time: currentStart.toISOString(),
        end_time: currentEnd.toISOString(),
        event_type: event.event_type,
        location: event.location,
        recurrence_rule: null, // Individual instances don't have recurrence
        parent_event_id: eventId,
        created_by: event.created_by,
        status: 'scheduled'
      });
    }

    const { data, error } = await supabase
      .from('calendar_events')
      .insert(instancesData)
      .select();

    if (error) throw error;

    // Log activity
    await this.logActivity('create_recurring_instances', 'calendar_event', eventId, {
      instances_created: instances
    });

    return data;
  },

  // Get events by attendee
  async getEventsByAttendee(attendeeId: string) {
    const { data, error } = await supabase
      .from('calendar_events')
      .select(`
        *,
        creator:profiles!calendar_events_created_by_fkey (
          id,
          full_name,
          email
        )
      `)
      .contains('attendees', [attendeeId])
      .order('start_time', { ascending: true });

    if (error) throw error;
    return data;
  },

  // Bulk update event status
  async bulkUpdateStatus(eventIds: string[], status: string) {
    const { data, error } = await supabase
      .from('calendar_events')
      .update({
        status,
        updated_at: new Date().toISOString()
      })
      .in('id', eventIds)
      .select();

    if (error) throw error;

    // Log activity for each event
    for (const event of data) {
      await this.logActivity('bulk_status_update', 'calendar_event', event.id, {
        title: event.title,
        new_status: status
      });
    }

    return data;
  },

  // Log activity
  async logActivity(action: string, entityType: string, entityId: string, details?: any) {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      await supabase
        .from('activity_logs')
        .insert({
          action,
          entity_type: entityType,
          entity_id: entityId,
          user_id: user.id,
          details
        });
    } catch (err) {
      // Don't block main flow on logging errors
      console.warn('logActivity failed', err);
    }
  }
};