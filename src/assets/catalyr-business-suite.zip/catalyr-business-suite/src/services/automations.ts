import { supabase } from "@/integrations/supabase/client";
import type { Database } from "@/integrations/supabase/types";

type Automation = Database['public']['Tables']['automations']['Row'];
type AutomationInsert = Database['public']['Tables']['automations']['Insert'];
type AutomationUpdate = Database['public']['Tables']['automations']['Update'];

export const automationsService = {
  // Get all automations with optional filtering
  async getAutomations(filters?: {
    status?: string;
    trigger_type?: string;
    search?: string;
  }) {
    let query = supabase
      .from('automations')
      .select(`
        *,
        creator:profiles (
          id,
          full_name,
          email
        )
      `)
      .order('created_at', { ascending: false });

    if (filters?.status) {
      query = query.eq('status', filters.status);
    }

    if (filters?.trigger_type) {
      query = query.eq('trigger_type', filters.trigger_type);
    }

    if (filters?.search) {
      query = query.or(`name.ilike.%${filters.search}%,description.ilike.%${filters.search}%`);
    }

    const { data, error } = await query;
    if (error) throw error;
    return data;
  },

  // Get automation by ID
  async getAutomationById(id: string) {
    const { data, error } = await supabase
      .from('automations')
      .select(`
        *,
        creator:profiles (
          id,
          full_name,
          email
        )
      `)
      .eq('id', id)
      .single();

    if (error) throw error;
    return data;
  },

  // Create automation
  async createAutomation(automation: AutomationInsert) {
    const { data, error } = await supabase
      .from('automations')
      .insert(automation)
      .select()
      .single();

    if (error) throw error;

    // Log activity
    await this.logActivity('create', 'automation', data.id, {
      name: data.name,
      trigger_type: data.trigger_type,
      status: data.status
    });

    return data;
  },

  // Update automation
  async updateAutomation(id: string, updates: AutomationUpdate) {
    const { data, error } = await supabase
      .from('automations')
      .update(updates)
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;

    // Log activity
    await this.logActivity('update', 'automation', id, updates);

    return data;
  },

  // Delete automation
  async deleteAutomation(id: string) {
    const { data: automation, error: fetchError } = await supabase
      .from('automations')
      .select('name, trigger_type, status')
      .eq('id', id)
      .single();

    if (fetchError) throw fetchError;

    const { error } = await supabase
      .from('automations')
      .delete()
      .eq('id', id);

    if (error) throw error;

    // Log activity
    await this.logActivity('delete', 'automation', id, {
      name: automation.name,
      trigger_type: automation.trigger_type,
      status: automation.status
    });
  },

  // Enable automation
  async enableAutomation(id: string) {
    const { data, error } = await supabase
      .from('automations')
      .update({
        status: 'active',
        updated_at: new Date().toISOString()
      })
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;

    // Log activity
    await this.logActivity('enable', 'automation', id, {
      name: data.name
    });

    return data;
  },

  // Disable automation
  async disableAutomation(id: string) {
    const { data, error } = await supabase
      .from('automations')
      .update({
        status: 'inactive',
        updated_at: new Date().toISOString()
      })
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;

    // Log activity
    await this.logActivity('disable', 'automation', id, {
      name: data.name
    });

    return data;
  },

  // Execute automation manually
  async executeAutomation(id: string, triggerData?: any) {
    const automation = await this.getAutomationById(id);

    if (automation.status !== 'active') {
      throw new Error('Automation is not active');
    }

    // Update last executed timestamp
    await supabase
      .from('automations')
      .update({
        last_executed_at: new Date().toISOString(),
        execution_count: (automation.execution_count || 0) + 1
      })
      .eq('id', id);

    // Log execution
    await this.logActivity('execute', 'automation', id, {
      name: automation.name,
      trigger_data: triggerData
    });

    // Here you would implement the actual automation logic
    // For now, we'll just return success
    return {
      success: true,
      automation_id: id,
      executed_at: new Date().toISOString()
    };
  },

  // Get automation statistics
  async getAutomationStats() {
    const { data, error } = await supabase
      .from('automations')
      .select('status, trigger_type, execution_count, last_executed_at');

    if (error) throw error;

    const stats = {
      total: data.length,
      active: data.filter(a => a.status === 'active').length,
      inactive: data.filter(a => a.status === 'inactive').length,
      draft: data.filter(a => a.status === 'draft').length,
      byTriggerType: data.reduce((acc, automation) => {
        acc[automation.trigger_type] = (acc[automation.trigger_type] || 0) + 1;
        return acc;
      }, {} as Record<string, number>),
      totalExecutions: data.reduce((sum, a) => sum + (a.execution_count || 0), 0),
      recentlyExecuted: data.filter(a =>
        a.last_executed_at &&
        new Date(a.last_executed_at) > new Date(Date.now() - 7 * 24 * 60 * 60 * 1000)
      ).length
    };

    return stats;
  },

  // Get automations by trigger type
  async getAutomationsByTriggerType(triggerType: string) {
    const { data, error } = await supabase
      .from('automations')
      .select(`
        *,
        creator:profiles (
          id,
          full_name,
          email
        )
      `)
      .eq('trigger_type', triggerType)
      .eq('status', 'active')
      .order('created_at', { ascending: false });

    if (error) throw error;
    return data;
  },

  // Clone automation
  async cloneAutomation(id: string, newName?: string) {
    const original = await this.getAutomationById(id);

    const clonedAutomation: AutomationInsert = {
      name: newName || `${original.name} (Copy)`,
      description: original.description,
      trigger_type: original.trigger_type,
      trigger_config: original.trigger_config,
      actions: original.actions,
      conditions: original.conditions,
      status: 'draft',
      created_by: original.created_by
    };

    const cloned = await this.createAutomation(clonedAutomation);

    // Log activity
    await this.logActivity('clone', 'automation', cloned.id, {
      original_name: original.name,
      cloned_name: cloned.name
    });

    return cloned;
  },

  // Get automation execution history
  async getAutomationExecutionHistory(automationId: string, limit: number = 50) {
    const { data, error } = await supabase
      .from('activity_logs')
      .select(`
        *,
        user:profiles (
          id,
          full_name,
          email
        )
      `)
      .eq('entity_type', 'automation')
      .eq('entity_id', automationId)
      .eq('action', 'execute')
      .order('created_at', { ascending: false })
      .limit(limit);

    if (error) throw error;
    return data;
  },

  // Test automation conditions
  async testAutomationConditions(automationId: string, testData: any) {
    const automation = await this.getAutomationById(automationId);

    // This is a placeholder for condition evaluation logic
    // In a real implementation, you would evaluate the conditions against testData
    const result = {
      automation_id: automationId,
      conditions_met: true, // Placeholder
      test_data: testData,
      evaluated_at: new Date().toISOString()
    };

    // Log test
    await this.logActivity('test_conditions', 'automation', automationId, {
      name: automation.name,
      test_result: result
    });

    return result;
  },

  // Bulk enable/disable automations
  async bulkUpdateStatus(automationIds: string[], status: 'active' | 'inactive') {
    const { data, error } = await supabase
      .from('automations')
      .update({
        status,
        updated_at: new Date().toISOString()
      })
      .in('id', automationIds)
      .select();

    if (error) throw error;

    // Log activity for each automation
    for (const automation of data) {
      await this.logActivity(status === 'active' ? 'bulk_enable' : 'bulk_disable', 'automation', automation.id, {
        name: automation.name
      });
    }

    return data;
  },

  // Get failed automations (placeholder for error tracking)
  async getFailedAutomations() {
    // In a real implementation, you might have an error_logs table
    // For now, return empty array
    return [];
  },

  // Log activity
  async logActivity(action: string, entityType: string, entityId: string, details?: any) {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    await supabase
      .from('activity_logs')
      .insert({
        action,
        entity_type: entityType,
        entity_id: entityId,
        user_id: user.id,
        details
      });
  }
};