type Department = any;
type DepartmentInsert = any;
type DepartmentUpdate = any;

const API_BASE = 'http://localhost:3001/api';

export const departmentsService = {
  // Get all departments
  async getDepartments() {
    const { data, error } = await supabase
      .from('departments')
      .select(`
        *,
        manager:profiles (
          id,
          full_name,
          email
        ),
        employees:employees (
          id,
          full_name,
          employee_code,
          status
        )
      `)
      .order('name', { ascending: true });

    if (error) throw error;
    return data;
  },

  // Get department by ID
  async getDepartmentById(id: string) {
    const { data, error } = await supabase
      .from('departments')
      .select(`
        *,
        manager:profiles (
          id,
          full_name,
          email
        ),
        employees:employees (
          id,
          full_name,
          employee_code,
          status,
          designations (
            id,
            name
          )
        )
      `)
      .eq('id', id)
      .single();

    if (error) throw error;
    return data;
  },

  // Create department
  async createDepartment(department: DepartmentInsert) {
    const { data, error } = await supabase
      .from('departments')
      .insert(department)
      .select()
      .single();

    if (error) throw error;

    // Log activity
    await this.logActivity('create', 'department', data.id, {
      name: data.name,
      manager_id: data.manager_id
    });

    return data;
  },

  // Update department
  async updateDepartment(id: string, updates: DepartmentUpdate) {
    const { data, error } = await supabase
      .from('departments')
      .update(updates)
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;

    // Log activity
    await this.logActivity('update', 'department', id, updates);

    return data;
  },

  // Delete department
  async deleteDepartment(id: string) {
    // Check if department has employees
    const { data: employees, error: empError } = await supabase
      .from('employees')
      .select('id')
      .eq('department_id', id);

    if (empError) throw empError;

    if (employees && employees.length > 0) {
      throw new Error('Cannot delete department with active employees. Please reassign employees first.');
    }

    const { data: department, error: fetchError } = await supabase
      .from('departments')
      .select('name, manager_id')
      .eq('id', id)
      .single();

    if (fetchError) throw fetchError;

    const { error } = await supabase
      .from('departments')
      .delete()
      .eq('id', id);

    if (error) throw error;

    // Log activity
    await this.logActivity('delete', 'department', id, {
      name: department.name,
      manager_id: department.manager_id
    });
  },

  // Get department statistics
  async getDepartmentStats() {
    const { data: departments, error: deptError } = await supabase
      .from('departments')
      .select('id, name');

    if (deptError) throw deptError;

    const stats = await Promise.all(
      departments.map(async (dept) => {
        const { data: employees, error: empError } = await supabase
          .from('employees')
          .select('id, status')
          .eq('department_id', dept.id);

        if (empError) throw empError;

        return {
          id: dept.id,
          name: dept.name,
          totalEmployees: employees.length,
          activeEmployees: employees.filter(e => e.status === 'active').length,
          inactiveEmployees: employees.filter(e => e.status === 'inactive').length
        };
      })
    );

    const totalStats = {
      totalDepartments: departments.length,
      totalEmployees: stats.reduce((sum, dept) => sum + dept.totalEmployees, 0),
      activeEmployees: stats.reduce((sum, dept) => sum + dept.activeEmployees, 0),
      departments: stats
    };

    return totalStats;
  },

  // Get employees in department
  async getDepartmentEmployees(departmentId: string) {
    const { data, error } = await supabase
      .from('employees')
      .select(`
        *,
        designations (
          id,
          name
        ),
        user:profiles (
          id,
          full_name,
          email
        )
      `)
      .eq('department_id', departmentId)
      .order('full_name', { ascending: true });

    if (error) throw error;
    return data;
  },

  // Assign manager to department
  async assignManager(departmentId: string, managerId: string) {
    const { data, error } = await supabase
      .from('departments')
      .update({
        manager_id: managerId,
        updated_at: new Date().toISOString()
      })
      .eq('id', departmentId)
      .select()
      .single();

    if (error) throw error;

    // Log activity
    await this.logActivity('assign_manager', 'department', departmentId, {
      name: data.name,
      manager_id: managerId
    });

    return data;
  },

  // Remove manager from department
  async removeManager(departmentId: string) {
    const { data, error } = await supabase
      .from('departments')
      .update({
        manager_id: null,
        updated_at: new Date().toISOString()
      })
      .eq('id', departmentId)
      .select()
      .single();

    if (error) throw error;

    // Log activity
    await this.logActivity('remove_manager', 'department', departmentId, {
      name: data.name
    });

    return data;
  },

  // Get department hierarchy (if you have parent-child relationships)
  async getDepartmentHierarchy() {
    const { data, error } = await supabase
      .from('departments')
      .select(`
        *,
        manager:profiles (
          id,
          full_name
        )
      `)
      .order('name', { ascending: true });

    if (error) throw error;

    // For now, return flat structure
    // In a real implementation, you might have parent_id for hierarchy
    return data;
  },

  // Get departments with low employee count
  async getUnderstaffedDepartments(minEmployees: number = 3) {
    const stats = await this.getDepartmentStats();

    return stats.departments.filter(dept => dept.activeEmployees < minEmployees);
  },

  // Get department performance metrics
  async getDepartmentPerformance(departmentId: string) {
    // Get department info
    const department = await this.getDepartmentById(departmentId);

    // Get employee count
    const employees = await this.getDepartmentEmployees(departmentId);

    // Get recent activities (last 30 days)
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);

    const { data: activities, error: actError } = await supabase
      .from('activity_logs')
      .select('*')
      .in('user_id', employees.map(e => e.id))
      .gte('created_at', thirtyDaysAgo.toISOString());

    if (actError) throw actError;

    // Calculate metrics
    const metrics = {
      department: department.name,
      totalEmployees: employees.length,
      activeEmployees: employees.filter(e => e.status === 'active').length,
      totalActivities: activities.length,
      avgActivitiesPerEmployee: employees.length > 0 ? activities.length / employees.length : 0,
      topActivities: this.getTopActivityTypes(activities)
    };

    return metrics;
  },

  // Helper function to get top activity types
  getTopActivityTypes(activities: any[]) {
    const typeCount = activities.reduce((acc, activity) => {
      acc[activity.entity_type] = (acc[activity.entity_type] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    return Object.entries(typeCount)
      .sort(([,a], [,b]) => b - a)
      .slice(0, 5)
      .map(([type, count]) => ({ type, count }));
  },

  // Bulk update department status
  async bulkUpdateStatus(departmentIds: string[], status: 'active' | 'inactive') {
    const { data, error } = await supabase
      .from('departments')
      .update({
        status,
        updated_at: new Date().toISOString()
      })
      .in('id', departmentIds)
      .select();

    if (error) throw error;

    // Log activity for each department
    for (const department of data) {
      await this.logActivity('bulk_status_update', 'department', department.id, {
        name: department.name,
        new_status: status
      });
    }

    return data;
  },

  // Get department budget information (placeholder)
  async getDepartmentBudget(departmentId: string) {
    // In a real implementation, you might have a budgets table
    // For now, return mock data
    const department = await this.getDepartmentById(departmentId);
    const employees = await this.getDepartmentEmployees(departmentId);

    const estimatedBudget = employees.length * 50000; // Rough estimate per employee

    return {
      department: department.name,
      employeeCount: employees.length,
      estimatedMonthlyBudget: estimatedBudget,
      estimatedAnnualBudget: estimatedBudget * 12
    };
  },

  // Log activity
  async logActivity(action: string, entityType: string, entityId: string, details?: any) {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      await supabase
        .from('activity_logs')
        .insert({
          action,
          entity_type: entityType,
          entity_id: entityId,
          user_id: user.id,
          details
        });
    } catch (error) {
      console.error('Failed to log activity:', error);
    }
  }
};