type Designation = any;
type DesignationInsert = any;
type DesignationUpdate = any;

const API_BASE = 'http://localhost:3001/api';

export const designationsService = {
  // Get all designations
  async getDesignations() {
    const { data, error } = await supabase
      .from('designations')
      .select(`
        *,
        department:departments (
          id,
          name
        ),
        employees:employees (
          id,
          full_name,
          employee_code,
          status
        )
      `)
      .order('level', { ascending: true })
      .order('name', { ascending: true });

    if (error) throw error;
    return data;
  },

  // Get designation by ID
  async getDesignationById(id: string) {
    const { data, error } = await supabase
      .from('designations')
      .select(`
        *,
        department:departments (
          id,
          name
        ),
        employees:employees (
          id,
          full_name,
          employee_code,
          status,
          departments (
            id,
            name
          )
        )
      `)
      .eq('id', id)
      .single();

    if (error) throw error;
    return data;
  },

  // Create designation
  async createDesignation(designation: DesignationInsert) {
    const { data, error } = await supabase
      .from('designations')
      .insert(designation)
      .select()
      .single();

    if (error) throw error;

    // Log activity
    await this.logActivity('create', 'designation', data.id, {
      name: data.name,
      level: data.level,
      department_id: data.department_id
    });

    return data;
  },

  // Update designation
  async updateDesignation(id: string, updates: DesignationUpdate) {
    const { data, error } = await supabase
      .from('designations')
      .update(updates)
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;

    // Log activity
    await this.logActivity('update', 'designation', id, updates);

    return data;
  },

  // Delete designation
  async deleteDesignation(id: string) {
    // Check if designation has employees
    const { data: employees, error: empError } = await supabase
      .from('employees')
      .select('id')
      .eq('designation_id', id);

    if (empError) throw empError;

    if (employees && employees.length > 0) {
      throw new Error('Cannot delete designation with assigned employees. Please reassign employees first.');
    }

    const { data: designation, error: fetchError } = await supabase
      .from('designations')
      .select('name, level, department_id')
      .eq('id', id)
      .single();

    if (fetchError) throw fetchError;

    const { error } = await supabase
      .from('designations')
      .delete()
      .eq('id', id);

    if (error) throw error;

    // Log activity
    await this.logActivity('delete', 'designation', id, {
      name: designation.name,
      level: designation.level,
      department_id: designation.department_id
    });
  },

  // Get designations by department
  async getDesignationsByDepartment(departmentId: string) {
    const { data, error } = await supabase
      .from('designations')
      .select(`
        *,
        employees:employees (
          id,
          full_name,
          employee_code,
          status
        )
      `)
      .eq('department_id', departmentId)
      .order('level', { ascending: true });

    if (error) throw error;
    return data;
  },

  // Get designation hierarchy
  async getDesignationHierarchy() {
    const { data, error } = await supabase
      .from('designations')
      .select(`
        *,
        department:departments (
          id,
          name
        )
      `)
      .order('level', { ascending: true })
      .order('name', { ascending: true });

    if (error) throw error;

    // Group by level for hierarchy
    const hierarchy = data.reduce((acc, designation) => {
      if (!acc[designation.level]) {
        acc[designation.level] = [];
      }
      acc[designation.level].push(designation);
      return acc;
    }, {} as Record<number, typeof data>);

    return hierarchy;
  },

  // Get employees by designation
  async getEmployeesByDesignation(designationId: string) {
    const { data, error } = await supabase
      .from('employees')
      .select(`
        *,
        departments (
          id,
          name
        ),
        user:profiles (
          id,
          full_name,
          email
        )
      `)
      .eq('designation_id', designationId)
      .order('full_name', { ascending: true });

    if (error) throw error;
    return data;
  },

  // Get designation statistics
  async getDesignationStats() {
    const { data: designations, error: desigError } = await supabase
      .from('designations')
      .select('id, name, level, department_id');

    if (desigError) throw desigError;

    const stats = await Promise.all(
      designations.map(async (desig) => {
        const { data: employees, error: empError } = await supabase
          .from('employees')
          .select('id, status')
          .eq('designation_id', desig.id);

        if (empError) throw empError;

        return {
          id: desig.id,
          name: desig.name,
          level: desig.level,
          department_id: desig.department_id,
          totalEmployees: employees.length,
          activeEmployees: employees.filter(e => e.status === 'active').length,
          inactiveEmployees: employees.filter(e => e.status === 'inactive').length
        };
      })
    );

    const totalStats = {
      totalDesignations: designations.length,
      totalEmployees: stats.reduce((sum, desig) => sum + desig.totalEmployees, 0),
      activeEmployees: stats.reduce((sum, desig) => sum + desig.activeEmployees, 0),
      byLevel: stats.reduce((acc, desig) => {
        acc[desig.level] = (acc[desig.level] || 0) + desig.totalEmployees;
        return acc;
      }, {} as Record<number, number>),
      designations: stats
    };

    return totalStats;
  },

  // Get next level designations
  async getNextLevelDesignations(currentLevel: number) {
    const { data, error } = await supabase
      .from('designations')
      .select(`
        *,
        department:departments (
          id,
          name
        )
      `)
      .gt('level', currentLevel)
      .order('level', { ascending: true })
      .order('name', { ascending: true });

    if (error) throw error;
    return data;
  },

  // Get designations with no employees
  async getEmptyDesignations() {
    const stats = await this.getDesignationStats();
    return stats.designations.filter(desig => desig.totalEmployees === 0);
  },

  // Get designation salary ranges
  async getDesignationSalaryRanges() {
    const { data, error } = await supabase
      .from('designations')
      .select(`
        id,
        name,
        level,
        min_salary,
        max_salary,
        department:departments (
          id,
          name
        )
      `)
      .order('level', { ascending: true });

    if (error) throw error;

    return data.map(desig => ({
      ...desig,
      salaryRange: desig.min_salary && desig.max_salary ?
        `${desig.min_salary.toLocaleString()} - ${desig.max_salary.toLocaleString()}` :
        'Not specified'
    }));
  },

  // Update designation salary range
  async updateSalaryRange(id: string, minSalary?: number, maxSalary?: number) {
    const { data, error } = await supabase
      .from('designations')
      .update({
        min_salary: minSalary,
        max_salary: maxSalary,
        updated_at: new Date().toISOString()
      })
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;

    // Log activity
    await this.logActivity('update_salary_range', 'designation', id, {
      name: data.name,
      min_salary: minSalary,
      max_salary: maxSalary
    });

    return data;
  },

  // Get designation promotion paths
  async getPromotionPaths(designationId: string) {
    const currentDesignation = await this.getDesignationById(designationId);

    const nextLevels = await this.getNextLevelDesignations(currentDesignation.level);

    return {
      current: currentDesignation,
      possiblePromotions: nextLevels.filter(d => d.department_id === currentDesignation.department_id)
    };
  },

  // Bulk update designation levels
  async bulkUpdateLevels(designationIds: string[], newLevel: number) {
    const { data, error } = await supabase
      .from('designations')
      .update({
        level: newLevel,
        updated_at: new Date().toISOString()
      })
      .in('id', designationIds)
      .select();

    if (error) throw error;

    // Log activity for each designation
    for (const designation of data) {
      await this.logActivity('bulk_level_update', 'designation', designation.id, {
        name: designation.name,
        new_level: newLevel
      });
    }

    return data;
  },

  // Get designation performance metrics
  async getDesignationPerformance(designationId: string) {
    const designation = await this.getDesignationById(designationId);
    const employees = await this.getEmployeesByDesignation(designationId);

    // Get recent activities (last 30 days)
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);

    const { data: activities, error: actError } = await supabase
      .from('activity_logs')
      .select('*')
      .in('user_id', employees.map(e => e.id))
      .gte('created_at', thirtyDaysAgo.toISOString());

    if (actError) throw actError;

    const metrics = {
      designation: designation.name,
      level: designation.level,
      totalEmployees: employees.length,
      activeEmployees: employees.filter(e => e.status === 'active').length,
      totalActivities: activities.length,
      avgActivitiesPerEmployee: employees.length > 0 ? activities.length / employees.length : 0,
      topActivities: this.getTopActivityTypes(activities)
    };

    return metrics;
  },

  // Helper function to get top activity types
  getTopActivityTypes(activities: any[]) {
    const typeCount = activities.reduce((acc, activity) => {
      acc[activity.entity_type] = (acc[activity.entity_type] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    return Object.entries(typeCount)
      .sort(([,a], [,b]) => b - a)
      .slice(0, 5)
      .map(([type, count]) => ({ type, count }));
  },

  // Log activity
  async logActivity(action: string, entityType: string, entityId: string, details?: any) {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      await supabase
        .from('activity_logs')
        .insert({
          action,
          entity_type: entityType,
          entity_id: entityId,
          user_id: user.id,
          details
        });
    } catch (err) {
      // Don't block main flow on logging errors
      console.warn('logActivity failed', err);
    }
  }
};