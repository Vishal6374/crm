import { supabase } from "@/integrations/supabase/client";

export const attendanceService = {
  list: async (opts: any = {}) => {
    const { page = 0, perPage = 50, filters } = opts;
    let query = supabase
      .from('attendance')
      .select('*')
      .order('date', { ascending: false })
      .range(page * perPage, (page + 1) * perPage - 1);
    if (filters?.date_from) {
      query = query.gte('date', filters.date_from);
    }
    if (filters?.date_to) {
      query = query.lte('date', filters.date_to);
    }
    if (filters?.status) {
      query = query.eq('status', filters.status);
    }
    const { data, error } = await query;
    if (error) throw error;
    return data;
  },

  get: async (id: string) => {
    const { data, error } = await supabase.from('attendance').select('*').eq('id', id).single();
    if (error) throw error;
    return data;
  },

  create: async (payload: any) => {
    const { data, error } = await supabase.from('attendance').insert([payload]).select().single();
    if (error) throw error;
    return data;
  },

  update: async (id: string, payload: any) => {
    const { data, error } = await supabase.from('attendance').update(payload).eq('id', id).select().single();
    if (error) throw error;
    return data;
  },

  remove: async (id: string) => {
    const { error } = await supabase.from('attendance').delete().eq('id', id);
    if (error) throw error;
    return true;
  },

  // Get attendance by employee and date range
  getEmployeeAttendance: async (employeeId: string, startDate: string, endDate: string) => {
    const { data, error } = await supabase
      .from('attendance')
      .select('*')
      .eq('employee_id', employeeId)
      .gte('date', startDate)
      .lte('date', endDate)
      .order('date', { ascending: true });
    if (error) throw error;
    return data;
  },

  // Clock in/out
  clockIn: async (employeeId: string, notes?: string) => {
    const today = new Date().toISOString().split('T')[0];
    const now = new Date().toISOString();
    // Check if already clocked in today
    const { data: existing, error: checkError } = await supabase
      .from('attendance')
      .select('*')
      .eq('employee_id', employeeId)
      .eq('date', today)
      .single();
    if (checkError && checkError.code !== 'PGRST116') throw checkError;
    if (existing) {
      throw new Error('Already clocked in today');
    }
    const { data, error } = await supabase
      .from('attendance')
      .insert({
        employee_id: employeeId,
        date: today,
        check_in: now,
        status: 'present',
        notes
      })
      .select()
      .single();
    if (error) throw error;
    // Log activity
    await this.logActivity('clock_in', 'attendance', data.id, {
      employee_id: employeeId,
      date: today
    });
    return data;
  },

  clockOut: async (attendanceId: string, notes?: string) => {
    const now = new Date().toISOString();
    const { data, error } = await supabase
      .from('attendance')
      .update({
        check_out: now,
        notes
      })
      .eq('id', attendanceId)
      .select()
      .single();
    if (error) throw error;
    // Log activity
    await this.logActivity('clock_out', 'attendance', attendanceId, {
      employee_id: data.employee_id,
      date: data.date
    });
    return data;
  },

  // Mark attendance manually (for admins)
  markAttendance: async (attendance: any) => {
    const { data, error } = await supabase
      .from('attendance')
      .insert(attendance)
      .select()
      .single();
    if (error) throw error;
    // Log activity
    await this.logActivity('mark_attendance', 'attendance', data.id, {
      employee_id: data.employee_id,
      date: data.date,
      status: data.status
    });
    return data;
  },

  // Update attendance record
  updateAttendance: async (id: string, updates: any) => {
    const { data, error } = await supabase
      .from('attendance')
      .update(updates)
      .eq('id', id)
      .select()
      .single();
    if (error) throw error;
    // Log activity
    await this.logActivity('update', 'attendance', id, updates);
    return data;
  },

  // Get attendance statistics
  getAttendanceStats: async (employeeId?: string, dateRange?: { start: string; end: string }) => {
    let query = supabase
      .from('attendance')
      .select('status, date, check_in, check_out');
    if (employeeId) {
      query = query.eq('employee_id', employeeId);
    }
    if (dateRange) {
      query = query
        .gte('date', dateRange.start)
        .lte('date', dateRange.end);
    }
    const { data, error } = await query;
    if (error) throw error;
    const stats = {
      total: data.length,
      present: data.filter((att: any) => att.status === 'present').length,
      absent: data.filter((att: any) => att.status === 'absent').length,
      late: data.filter((att: any) => att.status === 'late').length,
      halfDay: data.filter((att: any) => att.status === 'half_day').length,
      attendanceRate: data.length > 0 ?
        (data.filter((att: any) => att.status === 'present' || att.status === 'half_day').length / data.length) * 100 : 0,
      avgHours: data.length > 0 ?
        data
          .filter((att: any) => att.check_in && att.check_out)
          .reduce((sum: number, att: any) => {
            const checkIn = new Date(att.check_in);
            const checkOut = new Date(att.check_out);
            const hours = (checkOut.getTime() - checkIn.getTime()) / (1000 * 60 * 60);
            return sum + hours;
          }, 0) / data.filter((att: any) => att.check_in && att.check_out).length : 0
    };
    return stats;
  },

  // Get today's attendance for current user
  getTodayAttendance: async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) throw new Error('Not authenticated');
    const today = new Date().toISOString().split('T')[0];
    const { data, error } = await supabase
      .from('attendance')
      .select('*')
      .eq('employee_id', user.id)
      .eq('date', today)
      .single();
    if (error && error.code !== 'PGRST116') throw error;
    return data;
  },

  // Bulk mark attendance (for admins)
  bulkMarkAttendance: async (attendanceRecords: any[]) => {
    const { data, error } = await supabase
      .from('attendance')
      .insert(attendanceRecords)
      .select();
    if (error) throw error;
    // Log activity for bulk operation
    await this.logActivity('bulk_mark', 'attendance', 'bulk', {
      count: attendanceRecords.length
    });
    return data;
  },

  // Log activity
  logActivity: async (action: string, entityType: string, entityId: string, details?: any) => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;
      await supabase
        .from('activity_logs')
        .insert({
          action,
          entity_type: entityType,
          entity_id: entityId,
          user_id: user.id,
          details
        });
    } catch (error) {
      console.error('Failed to log activity:', error);
    }
  }
};
