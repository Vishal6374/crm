// Future: export services here for consistent imports
// CRM Services
export { companiesService } from './companies';
export { contactsService } from './contacts';
export { leadsService } from './leads';
export { dealsService } from './deals';

// HRM Services
export { employeesService } from './employees';
export { attendanceService } from './attendance';
export { leaveRequestsService } from './leaveRequests';
export { payrollService } from './payroll';
export { documentsService } from './documents';

// Management Services
export { tasksService } from './tasks';
export { calendarEventsService } from './calendarEvents';
export { automationsService } from './automations';
export { integrationsService } from './integrations';
export { activitiesService } from './activities';

// Organization Services
export { departmentsService } from './departments';
export { designationsService } from './designations';

// Security Services
export { permissionsService } from './permissions';
export { userRolesService } from './userRoles';
