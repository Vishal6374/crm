import { apiClient } from '@/integrations/api/client';

type UserRole = any;
type UserRoleInsert = any;
type UserRoleUpdate = any;

export const userRolesService = {
  // Get all user roles
  async getUserRoles() {
    return apiClient.getUserRoles();
  },

  // Get user role by ID
  async getUserRoleById(id: string) {
    // For now, fetch all and filter - in a real implementation, add a specific endpoint
    const roles = await this.getUserRoles();
    return roles.find(role => role.id === id);
  },

  // Create user role
  async createUserRole(role: UserRoleInsert) {
    return apiClient.createUserRole(role);
  },

  // Update user role
  async updateUserRole(id: string, updates: UserRoleUpdate) {
    return apiClient.updateUserRole(id, updates);
  },

  // Delete user role
  async deleteUserRole(id: string) {
    return apiClient.deleteUserRole(id);
  },

  // Validate role data
  validateRole(name: string, description?: string): { isValid: boolean; errors: string[] } {
    const errors: string[] = [];

    if (!name || name.trim().length === 0) {
      errors.push('Role name is required');
    }

    if (name && name.length > 100) {
      errors.push('Role name must be less than 100 characters');
    }

    if (description && description.length > 500) {
      errors.push('Role description must be less than 500 characters');
    }

    return {
      isValid: errors.length === 0,
      errors
    };
  },

  // Get default roles
  async getDefaultRoles() {
    const defaultRoles = [
      { name: 'Super Admin', description: 'Full system access' },
      { name: 'Admin', description: 'Administrative access' },
      { name: 'Manager', description: 'Department management access' },
      { name: 'Employee', description: 'Basic employee access' },
      { name: 'HR', description: 'Human resources access' },
      { name: 'Finance', description: 'Financial operations access' }
    ];

    return defaultRoles;
  },

  // Create default roles
  async createDefaultRoles() {
    const defaultRoles = await this.getDefaultRoles();

    const createdRoles = [];
    for (const role of defaultRoles) {
      try {
        const created = await this.createUserRole({
          name: role.name,
          description: role.description,
          user_ids: []
        });
        createdRoles.push(created);
      } catch (error) {
        // Role might already exist, skip
        console.log(`Role ${role.name} might already exist`);
      }
    }

    return createdRoles;
  }
};
