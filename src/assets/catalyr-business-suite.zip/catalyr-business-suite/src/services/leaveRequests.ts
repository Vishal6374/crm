
import { supabase } from "@/integrations/supabase/client";
import type { Database } from "@/integrations/supabase/types";

type LeaveRequest = Database['public']['Tables']['leave_requests']['Row'];
type LeaveRequestInsert = Database['public']['Tables']['leave_requests']['Insert'];
type LeaveRequestUpdate = Database['public']['Tables']['leave_requests']['Update'];

export const leaveRequestsService = {
  // Get all leave requests with optional filtering
  async getLeaveRequests(filters?: {
    employee_id?: string;
    status?: string;
    leave_type?: string;
    date_from?: string;
    date_to?: string;
  }) {
    let query = supabase
      .from('leave_requests')
      .select(`
        *,
        employees (
          id,
          full_name,
          employee_code,
          departments (
            id,
            name
          )
        )
      `)
      .order('created_at', { ascending: false });

    if (filters?.employee_id) {
      query = query.eq('employee_id', filters.employee_id);
    }

    if (filters?.status) {
      query = query.eq('status', filters.status);
    }

    if (filters?.leave_type) {
      query = query.eq('leave_type', filters.leave_type);
    }

    if (filters?.date_from) {
      query = query.gte('start_date', filters.date_from);
    }

    if (filters?.date_to) {
      query = query.lte('end_date', filters.date_to);
    }

    const { data, error } = await query;
    if (error) throw error;
    return data;
  },

  // Get leave request by ID
  async getLeaveRequest(id: string) {
    const { data, error } = await supabase
      .from('leave_requests')
      .select(`
        *,
        employees (
          id,
          full_name,
          employee_code,
          email,
          departments (
            id,
            name
          )
        )
      `)
      .eq('id', id)
      .single();

    if (error) throw error;
    return data;
  },

  // Create new leave request
  async createLeaveRequest(leaveRequest: LeaveRequestInsert) {
    const { data, error } = await supabase
      .from('leave_requests')
      .insert(leaveRequest)
      .select()
      .single();

    if (error) throw error;

    // Log activity
    await this.logActivity('create', 'leave_requests', data.id, {
      leave_type: data.leave_type,
      start_date: data.start_date,
      end_date: data.end_date
    });

    return data;
  },

  // Update leave request
  async updateLeaveRequest(id: string, updates: LeaveRequestUpdate) {
    const { data, error } = await supabase
      .from('leave_requests')
      .update(updates)
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;

    // Log activity
    await this.logActivity('update', 'leave_requests', id, updates);

    return data;
  },

  // Approve/Reject leave request
  async approveLeaveRequest(id: string, approved: boolean, comments?: string) {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) throw new Error('Not authenticated');

    const updates: LeaveRequestUpdate = {
      status: approved ? 'approved' : 'rejected',
      approved_by: user.id,
      approved_at: new Date().toISOString()
    };

    const { data, error } = await supabase
      .from('leave_requests')
      .update(updates)
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;

    // Log activity
    await this.logActivity(approved ? 'approve' : 'reject', 'leave_requests', id, {
      approved_by: user.id,
      comments
    });

    return data;
  },

  // Delete leave request
  async deleteLeaveRequest(id: string) {
    const { data: leaveRequest, error: fetchError } = await supabase
      .from('leave_requests')
      .select('leave_type, start_date, end_date')
      .eq('id', id)
      .single();

    if (fetchError) throw fetchError;

    const { error } = await supabase
      .from('leave_requests')
      .delete()
      .eq('id', id);

    if (error) throw error;

    // Log activity
    await this.logActivity('delete', 'leave_requests', id, {
      leave_type: leaveRequest.leave_type,
      start_date: leaveRequest.start_date,
      end_date: leaveRequest.end_date
    });
  },

  // Get leave requests for current user
  async getMyLeaveRequests() {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) throw new Error('Not authenticated');

    const { data, error } = await supabase
      .from('leave_requests')
      .select('*')
      .eq('employee_id', user.id)
      .order('created_at', { ascending: false });

    if (error) throw error;
    return data;
  },

  // Get pending leave requests (for managers/admins)
  async getPendingLeaveRequests() {
    const { data, error } = await supabase
      .from('leave_requests')
      .select(`
        *,
        employees (
          id,
          full_name,
          employee_code,
          departments (
            id,
            name
          )
        )
      `)
      .eq('status', 'pending')
      .order('created_at', { ascending: true });

    if (error) throw error;
    return data;
  },

  // Calculate leave days
  calculateLeaveDays(startDate: string, endDate: string): number {
    const start = new Date(startDate);
    const end = new Date(endDate);
    const diffTime = Math.abs(end.getTime() - start.getTime());
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)) + 1; // +1 to include both start and end dates
    return diffDays;
  },

  // Get leave statistics
  async getLeaveStats(employeeId?: string, year?: number) {
    const currentYear = year || new Date().getFullYear();

    let query = supabase
      .from('leave_requests')
      .select('leave_type, status, start_date, end_date');

    if (employeeId) {
      query = query.eq('employee_id', employeeId);
    }

    // Filter by year
    const startOfYear = `${currentYear}-01-01`;
    const endOfYear = `${currentYear}-12-31`;
    query = query
      .gte('start_date', startOfYear)
      .lte('end_date', endOfYear);

    const { data, error } = await query;
    if (error) throw error;

    const stats = {
      total: data.length,
      approved: data.filter(req => req.status === 'approved').length,
      rejected: data.filter(req => req.status === 'rejected').length,
      pending: data.filter(req => req.status === 'pending').length,
      byType: data.reduce((acc, req) => {
        acc[req.leave_type] = (acc[req.leave_type] || 0) + 1;
        return acc;
      }, {} as Record<string, number>),
      totalDays: data
        .filter(req => req.status === 'approved')
        .reduce((sum, req) => sum + this.calculateLeaveDays(req.start_date, req.end_date), 0)
    };

    return stats;
  },

  // Check for leave conflicts
  async checkLeaveConflicts(employeeId: string, startDate: string, endDate: string, excludeId?: string) {
    let query = supabase
      .from('leave_requests')
      .select('id, start_date, end_date, status')
      .eq('employee_id', employeeId)
      .eq('status', 'approved')
      .or(`and(start_date.lte.${endDate},end_date.gte.${startDate})`);

    if (excludeId) {
      query = query.neq('id', excludeId);
    }

    const { data, error } = await query;
    if (error) throw error;

    return data.length > 0 ? data : null;
  },

  // Log activity
  async logActivity(action: string, entityType: string, entityId: string, details?: any) {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      await supabase
        .from('activity_logs')
        .insert({
          action,
          entity_type: entityType,
          entity_id: entityId,
          user_id: user.id,
          details
        });
    } catch (error) {
      console.error('Failed to log activity:', error);
    }
  }
};