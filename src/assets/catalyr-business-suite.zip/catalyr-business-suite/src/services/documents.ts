
import { supabase } from "@/integrations/supabase/client";
import type { Database } from "@/integrations/supabase/types";

type Document = Database['public']['Tables']['documents']['Row'];
type DocumentInsert = Database['public']['Tables']['documents']['Insert'];
type DocumentUpdate = Database['public']['Tables']['documents']['Update'];

export const documentsService = {
  // Get all documents with optional filtering
  async getDocuments(filters?: {
    employee_id?: string;
    document_type?: string;
    status?: string;
    search?: string;
  }) {
    let query = supabase
      .from('documents')
      .select(`
        *,
        employees (
          id,
          full_name,
          employee_code,
          departments (
            id,
            name
          )
        )
      `)
      .order('created_at', { ascending: false });

    if (filters?.employee_id) {
      query = query.eq('employee_id', filters.employee_id);
    }

    if (filters?.document_type) {
      query = query.eq('document_type', filters.document_type);
    }

    if (filters?.status) {
      query = query.eq('status', filters.status);
    }

    if (filters?.search) {
      query = query.or(`title.ilike.%${filters.search}%,description.ilike.%${filters.search}%`);
    }

    const { data, error } = await query;
    if (error) throw error;
    return data;
  },

  // Get document by ID
  async getDocumentById(id: string) {
    const { data, error } = await supabase
      .from('documents')
      .select(`
        *,
        employees (
          id,
          full_name,
          employee_code,
          email,
          departments (
            id,
            name
          )
        )
      `)
      .eq('id', id)
      .single();

    if (error) throw error;
    return data;
  },

  // Create document
  async createDocument(document: DocumentInsert) {
    const { data, error } = await supabase
      .from('documents')
      .insert(document)
      .select()
      .single();

    if (error) throw error;

    // Log activity
    await this.logActivity('create', 'document', data.id, {
      employee_id: data.employee_id,
      document_type: data.document_type,
      title: data.title
    });

    return data;
  },

  // Update document
  async updateDocument(id: string, updates: DocumentUpdate) {
    const { data, error } = await supabase
      .from('documents')
      .update(updates)
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;

    // Log activity
    await this.logActivity('update', 'document', id, updates);

    return data;
  },

  // Delete document
  async deleteDocument(id: string) {
    const { data: document, error: fetchError } = await supabase
      .from('documents')
      .select('employee_id, document_type, title')
      .eq('id', id)
      .single();

    if (fetchError) throw fetchError;

    const { error } = await supabase
      .from('documents')
      .delete()
      .eq('id', id);

    if (error) throw error;

    // Log activity
    await this.logActivity('delete', 'document', id, {
      employee_id: document.employee_id,
      document_type: document.document_type,
      title: document.title
    });
  },

  // Get documents for current user
  async getMyDocuments() {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) throw new Error('Not authenticated');

    const { data, error } = await supabase
      .from('documents')
      .select('*')
      .eq('employee_id', user.id)
      .order('created_at', { ascending: false });

    if (error) throw error;
    return data;
  },

  // Upload document file (placeholder - actual file upload would need storage setup)
  async uploadDocument(file: File, metadata: {
    employee_id: string;
    document_type: string;
    title: string;
    description?: string;
  }) {
    // In a real implementation, you would upload to Supabase Storage
    // For now, we'll create a document record with a placeholder file_url
    const fileUrl = `documents/${metadata.employee_id}/${Date.now()}-${file.name}`;

    const document: DocumentInsert = {
      ...metadata,
      file_url: fileUrl,
      file_size: file.size,
      mime_type: file.type,
      status: 'pending'
    };

    return await this.createDocument(document);
  },

  // Approve document
  async approveDocument(id: string, approvedBy: string, comments?: string) {
    const { data, error } = await supabase
      .from('documents')
      .update({
        status: 'approved',
        approved_by: approvedBy,
        approved_at: new Date().toISOString(),
        comments
      })
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;

    // Log activity
    await this.logActivity('approve', 'document', id, {
      employee_id: data.employee_id,
      document_type: data.document_type,
      approved_by: approvedBy
    });

    return data;
  },

  // Reject document
  async rejectDocument(id: string, rejectedBy: string, comments?: string) {
    const { data, error } = await supabase
      .from('documents')
      .update({
        status: 'rejected',
        approved_by: rejectedBy,
        approved_at: new Date().toISOString(),
        comments
      })
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;

    // Log activity
    await this.logActivity('reject', 'document', id, {
      employee_id: data.employee_id,
      document_type: data.document_type,
      rejected_by: rejectedBy
    });

    return data;
  },

  // Get document statistics
  async getDocumentStats() {
    const { data, error } = await supabase
      .from('documents')
      .select('status, document_type');

    if (error) throw error;

    const stats = {
      total: data.length,
      pending: data.filter(d => d.status === 'pending').length,
      approved: data.filter(d => d.status === 'approved').length,
      rejected: data.filter(d => d.status === 'rejected').length,
      byType: data.reduce((acc, doc) => {
        acc[doc.document_type] = (acc[doc.document_type] || 0) + 1;
        return acc;
      }, {} as Record<string, number>)
    };

    return stats;
  },

  // Get documents by type
  async getDocumentsByType(documentType: string) {
    const { data, error } = await supabase
      .from('documents')
      .select(`
        *,
        employees (
          id,
          full_name,
          employee_code
        )
      `)
      .eq('document_type', documentType)
      .order('created_at', { ascending: false });

    if (error) throw error;
    return data;
  },

  // Get expiring documents (next 30 days)
  async getExpiringDocuments(days: number = 30) {
    const futureDate = new Date();
    futureDate.setDate(futureDate.getDate() + days);

    const { data, error } = await supabase
      .from('documents')
      .select(`
        *,
        employees (
          id,
          full_name,
          employee_code,
          email
        )
      `)
      .not('expiry_date', 'is', null)
      .lte('expiry_date', futureDate.toISOString().split('T')[0])
      .gte('expiry_date', new Date().toISOString().split('T')[0])
      .eq('status', 'approved')
      .order('expiry_date', { ascending: true });

    if (error) throw error;
    return data;
  },

  // Get expired documents
  async getExpiredDocuments() {
    const today = new Date().toISOString().split('T')[0];

    const { data, error } = await supabase
      .from('documents')
      .select(`
        *,
        employees (
          id,
          full_name,
          employee_code,
          email
        )
      `)
      .not('expiry_date', 'is', null)
      .lt('expiry_date', today)
      .eq('status', 'approved')
      .order('expiry_date', { ascending: false });

    if (error) throw error;
    return data;
  },

  // Bulk approve documents
  async bulkApproveDocuments(documentIds: string[], approvedBy: string) {
    const { data, error } = await supabase
      .from('documents')
      .update({
        status: 'approved',
        approved_by: approvedBy,
        approved_at: new Date().toISOString()
      })
      .in('id', documentIds)
      .select();

    if (error) throw error;

    // Log activity for each document
    for (const doc of data) {
      await this.logActivity('bulk_approve', 'document', doc.id, {
        employee_id: doc.employee_id,
        document_type: doc.document_type,
        approved_by: approvedBy
      });
    }

    return data;
  },

  // Log activity
  async logActivity(action: string, entityType: string, entityId: string, details?: any) {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      await supabase
        .from('activity_logs')
        .insert({
          action,
          entity_type: entityType,
          entity_id: entityId,
          user_id: user.id,
          details
        });
    } catch (error) {
      console.error('Failed to log activity:', error);
    }
  }
};