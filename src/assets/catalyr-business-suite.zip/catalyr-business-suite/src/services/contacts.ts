
import { apiClient } from '@/integrations/api/client';

type Contact = any; // Define proper type later
type ContactInsert = any;
type ContactUpdate = any;

export const contactsService = {
  // Get all contacts with optional filtering
  async getContacts(filters?: {
    search?: string;
    company_id?: string;
  }) {
    return apiClient.getContacts(filters);
  },

  // Get contact by ID
  async getContact(id: string) {
    return apiClient.getContact(id);
  },

  // Create new contact
  async createContact(contact: ContactInsert) {
    return apiClient.createContact(contact);
  },

  // Update contact
  async updateContact(id: string, updates: ContactUpdate) {
    return apiClient.updateContact(id, updates);
  },

  // Delete contact
  async deleteContact(id: string) {
    return apiClient.deleteContact(id);
  },

  // Get contacts by company
  async getContactsByCompany(companyId: string) {
    return this.getContacts({ company_id: companyId });
  },

  // Get contact statistics
  async getContactStats() {
    const contacts = await this.getContacts();
    const stats = {
      total: contacts.length,
      recent: contacts.filter(contact =>
        new Date(contact.created_at) > new Date(Date.now() - 30 * 24 * 60 * 60 * 1000)
      ).length
    };
    return stats;
  }
};