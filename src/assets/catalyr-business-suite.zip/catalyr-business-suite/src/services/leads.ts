
type Lead = any;
type LeadInsert = any;
type LeadUpdate = any;

const API_BASE = 'http://localhost:3001/api';

export const leadsService = {
  // Get all leads with optional filtering
  async getLeads(filters?: {
    search?: string;
    status?: string;
    source?: string;
    assigned_to?: string;
  }) {
    const queryParams = new URLSearchParams();
    if (filters?.search) queryParams.append('search', filters.search);
    if (filters?.status) queryParams.append('status', filters.status);
    if (filters?.source) queryParams.append('source', filters.source);
    if (filters?.assigned_to) queryParams.append('assigned_to', filters.assigned_to);

    const response = await fetch(`${API_BASE}/leads?${queryParams}`);
    if (!response.ok) throw new Error('Failed to fetch leads');
    return response.json();
  },

  // Get lead by ID
  async getLead(id: string) {
    const response = await fetch(`${API_BASE}/leads/${id}`);
    if (!response.ok) throw new Error('Failed to fetch lead');
    return response.json();
  },

  // Create new lead
  async createLead(lead: LeadInsert) {
    const response = await fetch(`${API_BASE}/leads`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(lead)
    });
    if (!response.ok) throw new Error('Failed to create lead');
    return response.json();
  },

  // Update lead
  async updateLead(id: string, updates: LeadUpdate) {
    const response = await fetch(`${API_BASE}/leads/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(updates)
    });
    if (!response.ok) throw new Error('Failed to update lead');
    return response.json();
  },

  // Delete lead
  async deleteLead(id: string) {
    const lead = await this.getLead(id);
    const response = await fetch(`${API_BASE}/leads/${id}`, {
      method: 'DELETE'
    });
    if (!response.ok) throw new Error('Failed to delete lead');
    // TODO: log activity
  },

  // Convert lead to contact/company
  async convertLead(id: string, conversionData: {
    companyData?: any;
    contactData?: any;
  }) {
    // TODO: implement conversion logic
    throw new Error('Conversion not implemented yet');
  },

  // Get lead statistics
  async getLeadStats() {
    const leads = await this.getLeads();
    const stats = {
      total: leads.length,
      byStatus: leads.reduce((acc, lead) => {
        acc[lead.status] = (acc[lead.status] || 0) + 1;
        return acc;
      }, {} as Record<string, number>),
      bySource: leads.reduce((acc, lead) => {
        acc[lead.source || 'unknown'] = (acc[lead.source || 'unknown'] || 0) + 1;
        return acc;
      }, {} as Record<string, number>),
      conversionRate: leads.length > 0 ?
        (leads.filter(lead => lead.status === 'won').length / leads.length) * 100 : 0,
      recent: leads.filter(lead =>
        new Date(lead.created_at) > new Date(Date.now() - 30 * 24 * 60 * 60 * 1000)
      ).length
    };
    return stats;
  },

  // Get leads by status
  async getLeadsByStatus(status: string) {
    return this.getLeads({ status });
  }
};