
type Employee = any;
type EmployeeInsert = any;
type EmployeeUpdate = any;

const API_BASE = 'http://localhost:3001/api';

export const employeesService = {
  // Get all employees with optional filtering
  async getEmployees(filters?: {
    search?: string;
    department_id?: string;
    status?: string;
  }) {
    let query = supabase
      .from('employees')
      .select(`
        *,
        departments (
          id,
          name
        ),
        designations (
          id,
          name,
          level
        )
      `)
      .order('created_at', { ascending: false });

    if (filters?.search) {
      query = query.or(`full_name.ilike.%${filters.search}%,email.ilike.%${filters.search}%,employee_code.ilike.%${filters.search}%`);
    }

    if (filters?.department_id) {
      query = query.eq('department_id', filters.department_id);
    }

    if (filters?.status) {
      query = query.eq('status', filters.status);
    }

    const { data, error } = await query;
    if (error) throw error;
    return data;
  },

  // Get employee by ID
  async getEmployee(id: string) {
    const { data, error } = await supabase
      .from('employees')
      .select(`
        *,
        departments (
          id,
          name,
          description
        ),
        designations (
          id,
          name,
          level,
          base_salary_min,
          base_salary_max
        )
      `)
      .eq('id', id)
      .single();

    if (error) throw error;
    return data;
  },

  // Create new employee
  async createEmployee(employee: EmployeeInsert) {
    const { data, error } = await supabase
      .from('employees')
      .insert(employee)
      .select()
      .single();

    if (error) throw error;

    // Log activity
    await this.logActivity('create', 'employees', data.id, {
      name: data.full_name,
      employee_code: data.employee_code
    });

    return data;
  },

  // Update employee
  async updateEmployee(id: string, updates: EmployeeUpdate) {
    const { data, error } = await supabase
      .from('employees')
      .update(updates)
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;

    // Log activity
    await this.logActivity('update', 'employees', id, updates);

    return data;
  },

  // Delete employee
  async deleteEmployee(id: string) {
    const { data: employee, error: fetchError } = await supabase
      .from('employees')
      .select('full_name, employee_code')
      .eq('id', id)
      .single();

    if (fetchError) throw fetchError;

    const { error } = await supabase
      .from('employees')
      .delete()
      .eq('id', id);

    if (error) throw error;

    // Log activity
    await this.logActivity('delete', 'employees', id, {
      name: employee.full_name,
      employee_code: employee.employee_code
    });
  },

  // Get employees by department
  async getEmployeesByDepartment(departmentId: string) {
    const { data, error } = await supabase
      .from('employees')
      .select(`
        *,
        designations (
          id,
          name,
          level
        )
      `)
      .eq('department_id', departmentId)
      .eq('status', 'active')
      .order('full_name');

    if (error) throw error;
    return data;
  },

  // Get employee statistics
  async getEmployeeStats() {
    const { data, error } = await supabase
      .from('employees')
      .select('status, department_id, joining_date, salary');

    if (error) throw error;

    const stats = {
      total: data.length,
      active: data.filter(emp => emp.status === 'active').length,
      byDepartment: data.reduce((acc, emp) => {
        const deptId = emp.department_id || 'unassigned';
        acc[deptId] = (acc[deptId] || 0) + 1;
        return acc;
      }, {} as Record<string, number>),
      avgSalary: data.length > 0 ?
        data.reduce((sum, emp) => sum + (emp.salary || 0), 0) / data.length : 0,
      recentHires: data.filter(emp =>
        emp.joining_date &&
        new Date(emp.joining_date) > new Date(Date.now() - 90 * 24 * 60 * 60 * 1000)
      ).length
    };

    return stats;
  },

  // Update employee status
  async updateEmployeeStatus(id: string, status: string) {
    const { data, error } = await supabase
      .from('employees')
      .update({ status })
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;

    // Log activity
    await this.logActivity('status_update', 'employees', id, {
      status,
      name: data.full_name
    });

    return data;
  },

  // Get current user employee profile
  async getCurrentUserEmployee() {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) throw new Error('Not authenticated');

    const { data, error } = await supabase
      .from('employees')
      .select(`
        *,
        departments (
          id,
          name,
          description
        ),
        designations (
          id,
          name,
          level,
          base_salary_min,
          base_salary_max
        )
      `)
      .eq('user_id', user.id)
      .single();

    if (error) throw error;
    return data;
  },

  // Log activity
  async logActivity(action: string, entityType: string, entityId: string, details?: any) {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      await supabase
        .from('activity_logs')
        .insert({
          action,
          entity_type: entityType,
          entity_id: entityId,
          user_id: user.id,
          details
        });
    } catch (error) {
      console.error('Failed to log activity:', error);
    }
  }
};