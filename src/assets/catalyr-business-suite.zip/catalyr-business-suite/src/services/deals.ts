
import { supabase } from "@/integrations/supabase/client";
import type { Database } from "@/integrations/supabase/types";

type Deal = Database['public']['Tables']['deals']['Row'];
type DealInsert = Database['public']['Tables']['deals']['Insert'];
type DealUpdate = Database['public']['Tables']['deals']['Update'];

export const dealsService = {
  // Get all deals with optional filtering
  async getDeals(filters?: {
    search?: string;
    stage?: string;
    assigned_to?: string;
  }) {
    let query = supabase
      .from('deals')
      .select(`
        *,
        companies (
          id,
          name
        ),
        contacts (
          id,
          first_name,
          last_name
        )
      `)
      .order('created_at', { ascending: false });

    if (filters?.search) {
      query = query.or(`title.ilike.%${filters.search}%,notes.ilike.%${filters.search}%`);
    }

    if (filters?.stage) {
      query = query.eq('stage', filters.stage);
    }

    if (filters?.assigned_to) {
      query = query.eq('assigned_to', filters.assigned_to);
    }

    const { data, error } = await query;
    if (error) throw error;
    return data;
  },

  // Get deal by ID
  async getDeal(id: string) {
    const { data, error } = await supabase
      .from('deals')
      .select(`
        *,
        companies (
          id,
          name,
          industry,
          website,
          email,
          phone
        ),
        contacts (
          id,
          first_name,
          last_name,
          email,
          phone,
          position
        )
      `)
      .eq('id', id)
      .single();

    if (error) throw error;
    return data;
  },

  // Create new deal
  async createDeal(deal: DealInsert) {
    const { data, error } = await supabase
      .from('deals')
      .insert(deal)
      .select()
      .single();

    if (error) throw error;

    // Log activity
    await this.logActivity('create', 'deals', data.id, {
      title: data.title,
      value: data.value,
      stage: data.stage
    });

    return data;
  },

  // Update deal
  async updateDeal(id: string, updates: DealUpdate) {
    const { data, error } = await supabase
      .from('deals')
      .update(updates)
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;

    // Log activity
    await this.logActivity('update', 'deals', id, updates);

    return data;
  },

  // Delete deal
  async deleteDeal(id: string) {
    const { data: deal, error: fetchError } = await supabase
      .from('deals')
      .select('title, value, stage')
      .eq('id', id)
      .single();

    if (fetchError) throw fetchError;

    const { error } = await supabase
      .from('deals')
      .delete()
      .eq('id', id);

    if (error) throw error;

    // Log activity
    await this.logActivity('delete', 'deals', id, {
      title: deal.title,
      value: deal.value,
      stage: deal.stage
    });
  },

  // Update deal stage
  async updateDealStage(id: string, stage: string, notes?: string) {
    const updates: DealUpdate = { stage };

    if (stage === 'won' || stage === 'lost') {
      updates.closed_at = new Date().toISOString();
    }

    if (notes) {
      updates.notes = notes;
    }

    const { data, error } = await supabase
      .from('deals')
      .update(updates)
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;

    // Log activity
    await this.logActivity('stage_change', 'deals', id, {
      from_stage: data.stage,
      to_stage: stage,
      notes
    });

    return data;
  },

  // Get deals by stage
  async getDealsByStage(stage: string) {
    const { data, error } = await supabase
      .from('deals')
      .select(`
        *,
        companies (
          id,
          name
        ),
        contacts (
          id,
          first_name,
          last_name
        )
      `)
      .eq('stage', stage)
      .order('created_at', { ascending: false });

    if (error) throw error;
    return data;
  },

  // Get deal statistics
  async getDealStats() {
    const { data, error } = await supabase
      .from('deals')
      .select('stage, value, expected_close_date, created_at');

    if (error) throw error;

    const stats = {
      total: data.length,
      byStage: data.reduce((acc, deal) => {
        acc[deal.stage] = (acc[deal.stage] || 0) + 1;
        return acc;
      }, {} as Record<string, number>),
      totalValue: data.reduce((sum, deal) => sum + (deal.value || 0), 0),
      wonValue: data.filter(deal => deal.stage === 'won').reduce((sum, deal) => sum + (deal.value || 0), 0),
      conversionRate: data.length > 0 ?
        (data.filter(deal => deal.stage === 'won').length / data.length) * 100 : 0,
      avgDealSize: data.length > 0 ?
        data.reduce((sum, deal) => sum + (deal.value || 0), 0) / data.length : 0,
      upcomingClosures: data.filter(deal =>
        deal.expected_close_date &&
        new Date(deal.expected_close_date) > new Date() &&
        new Date(deal.expected_close_date) <= new Date(Date.now() + 30 * 24 * 60 * 60 * 1000)
      ).length
    };

    return stats;
  },

  // Get deals pipeline data
  async getPipelineData() {
    const { data, error } = await supabase
      .from('deals')
      .select('stage, value, expected_close_date')
      .order('expected_close_date', { ascending: true });

    if (error) throw error;

    // Group by stage and calculate metrics
    const pipeline = data.reduce((acc, deal) => {
      const stage = deal.stage;
      if (!acc[stage]) {
        acc[stage] = {
          count: 0,
          value: 0,
          avgValue: 0
        };
      }
      acc[stage].count += 1;
      acc[stage].value += deal.value || 0;
      return acc;
    }, {} as Record<string, { count: number; value: number; avgValue: number }>);

    // Calculate averages
    Object.keys(pipeline).forEach(stage => {
      pipeline[stage].avgValue = pipeline[stage].value / pipeline[stage].count;
    });

    return pipeline;
  },

  // Log activity
  async logActivity(action: string, entityType: string, entityId: string, details?: any) {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      await supabase
        .from('activity_logs')
        .insert({
          action,
          entity_type: entityType,
          entity_id: entityId,
          user_id: user.id,
          details
        });
    } catch (err) {
      // Don't block main flow on logging errors
      console.warn('logActivity failed', err);
    }
  }
};