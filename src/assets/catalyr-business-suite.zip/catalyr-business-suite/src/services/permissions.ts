import { supabase } from "@/integrations/supabase/client";
import type { Database } from "@/integrations/supabase/types";

type Permission = Database['public']['Tables']['permissions']['Row'];
type PermissionInsert = Database['public']['Tables']['permissions']['Insert'];
type PermissionUpdate = Database['public']['Tables']['permissions']['Update'];

export const permissionsService = {
  // Get all permissions
  async getPermissions() {
    const { data, error } = await supabase
      .from('permissions')
      .select(`
        *,
        role:user_roles (
          id,
          name,
          description
        )
      `)
      .order('resource', { ascending: true })
      .order('action', { ascending: true });

    if (error) throw error;
    return data;
  },

  // Get permission by ID
  async getPermissionById(id: string) {
    const { data, error } = await supabase
      .from('permissions')
      .select(`
        *,
        role:user_roles (
          id,
          name,
          description
        )
      `)
      .eq('id', id)
      .single();

    if (error) throw error;
    return data;
  },

  // Create permission
  async createPermission(permission: PermissionInsert) {
    const { data, error } = await supabase
      .from('permissions')
      .insert(permission)
      .select()
      .single();

    if (error) throw error;

    // Log activity
    await this.logActivity('create', 'permission', data.id, {
      resource: data.resource,
      action: data.action,
      role_id: data.role_id
    });

    return data;
  },

  // Update permission
  async updatePermission(id: string, updates: PermissionUpdate) {
    const { data, error } = await supabase
      .from('permissions')
      .update(updates)
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;

    // Log activity
    await this.logActivity('update', 'permission', id, updates);

    return data;
  },

  // Delete permission
  async deletePermission(id: string) {
    const { data: permission, error: fetchError } = await supabase
      .from('permissions')
      .select('resource, action, role_id')
      .eq('id', id)
      .single();

    if (fetchError) throw fetchError;

    const { error } = await supabase
      .from('permissions')
      .delete()
      .eq('id', id);

    if (error) throw error;

    // Log activity
    await this.logActivity('delete', 'permission', id, {
      resource: permission.resource,
      action: permission.action,
      role_id: permission.role_id
    });
  },

  // Get permissions by role
  async getPermissionsByRole(roleId: string) {
    const { data, error } = await supabase
      .from('permissions')
      .select('*')
      .eq('role_id', roleId)
      .order('resource', { ascending: true })
      .order('action', { ascending: true });

    if (error) throw error;
    return data;
  },

  // Get permissions by resource
  async getPermissionsByResource(resource: string) {
    const { data, error } = await supabase
      .from('permissions')
      .select(`
        *,
        role:user_roles (
          id,
          name
        )
      `)
      .eq('resource', resource)
      .order('action', { ascending: true });

    if (error) throw error;
    return data;
  },

  // Check if user has permission
  async checkUserPermission(userId: string, resource: string, action: string) {
    // Get user's roles
    const { data: userRoles, error: roleError } = await supabase
      .from('user_roles')
      .select('id')
      .contains('user_ids', [userId]);

    if (roleError) throw roleError;

    if (!userRoles || userRoles.length === 0) {
      return false;
    }

    // Check if any of user's roles has the required permission
    const { data: permissions, error: permError } = await supabase
      .from('permissions')
      .select('id')
      .in('role_id', userRoles.map(r => r.id))
      .eq('resource', resource)
      .eq('action', action);

    if (permError) throw permError;

    return permissions && permissions.length > 0;
  },

  // Get user permissions
  async getUserPermissions(userId: string) {
    // Get user's roles
    const { data: userRoles, error: roleError } = await supabase
      .from('user_roles')
      .select('id, name')
      .contains('user_ids', [userId]);

    if (roleError) throw roleError;

    if (!userRoles || userRoles.length === 0) {
      return [];
    }

    // Get all permissions for user's roles
    const { data: permissions, error: permError } = await supabase
      .from('permissions')
      .select(`
        *,
        role:user_roles (
          id,
          name
        )
      `)
      .in('role_id', userRoles.map(r => r.id))
      .order('resource', { ascending: true })
      .order('action', { ascending: true });

    if (permError) throw permError;

    return permissions || [];
  },

  // Grant permission to role
  async grantPermissionToRole(roleId: string, resource: string, action: string) {
    // Check if permission already exists
    const { data: existing, error: checkError } = await supabase
      .from('permissions')
      .select('id')
      .eq('role_id', roleId)
      .eq('resource', resource)
      .eq('action', action)
      .single();

    if (checkError && checkError.code !== 'PGRST116') throw checkError;

    if (existing) {
      throw new Error('Permission already exists for this role');
    }

    const permission: PermissionInsert = {
      role_id: roleId,
      resource,
      action
    };

    return await this.createPermission(permission);
  },

  // Revoke permission from role
  async revokePermissionFromRole(roleId: string, resource: string, action: string) {
    const { data, error } = await supabase
      .from('permissions')
      .delete()
      .eq('role_id', roleId)
      .eq('resource', resource)
      .eq('action', action)
      .select();

    if (error) throw error;

    if (data && data.length > 0) {
      // Log activity
      await this.logActivity('revoke', 'permission', data[0].id, {
        resource,
        action,
        role_id: roleId
      });
    }

    return data;
  },

  // Bulk grant permissions
  async bulkGrantPermissions(roleId: string, permissions: Array<{ resource: string; action: string }>) {
    const permissionInserts: PermissionInsert[] = permissions.map(p => ({
      role_id: roleId,
      resource: p.resource,
      action: p.action
    }));

    const { data, error } = await supabase
      .from('permissions')
      .insert(permissionInserts)
      .select();

    if (error) throw error;

    // Log activity
    await this.logActivity('bulk_grant', 'permission', 'bulk', {
      role_id: roleId,
      permissions_count: permissions.length
    });

    return data;
  },

  // Bulk revoke permissions
  async bulkRevokePermissions(roleId: string, permissions: Array<{ resource: string; action: string }>) {
    const { data, error } = await supabase
      .from('permissions')
      .delete()
      .eq('role_id', roleId)
      .in('resource', permissions.map(p => p.resource))
      .in('action', permissions.map(p => p.action))
      .select();

    if (error) throw error;

    // Log activity
    await this.logActivity('bulk_revoke', 'permission', 'bulk', {
      role_id: roleId,
      permissions_count: permissions.length
    });

    return data;
  },

  // Get permission matrix (resources x actions)
  async getPermissionMatrix() {
    const { data: permissions, error } = await supabase
      .from('permissions')
      .select(`
        resource,
        action,
        role:user_roles (
          id,
          name
        )
      `);

    if (error) throw error;

    // Group permissions by resource and action
    const matrix = permissions.reduce((acc, perm) => {
      const key = `${perm.resource}:${perm.action}`;
      if (!acc[key]) {
        acc[key] = {
          resource: perm.resource,
          action: perm.action,
          roles: []
        };
      }
      acc[key].roles.push(perm.role);
      return acc;
    }, {} as Record<string, any>);

    return Object.values(matrix);
  },

  // Get resources list
  async getResourcesList() {
    const { data, error } = await supabase
      .from('permissions')
      .select('resource')
      .order('resource', { ascending: true });

    if (error) throw error;

    // Get unique resources
    const resources = [...new Set(data.map(p => p.resource))];
    return resources;
  },

  // Get actions list
  async getActionsList() {
    const { data, error } = await supabase
      .from('permissions')
      .select('action')
      .order('action', { ascending: true });

    if (error) throw error;

    // Get unique actions
    const actions = [...new Set(data.map(p => p.action))];
    return actions;
  },

  // Clone permissions from one role to another
  async clonePermissions(fromRoleId: string, toRoleId: string) {
    const fromPermissions = await this.getPermissionsByRole(fromRoleId);

    const permissionInserts: PermissionInsert[] = fromPermissions.map(p => ({
      role_id: toRoleId,
      resource: p.resource,
      action: p.action
    }));

    const { data, error } = await supabase
      .from('permissions')
      .insert(permissionInserts)
      .select();

    if (error) throw error;

    // Log activity
    await this.logActivity('clone_permissions', 'permission', 'bulk', {
      from_role_id: fromRoleId,
      to_role_id: toRoleId,
      permissions_count: permissionInserts.length
    });

    return data;
  },

  // Get permission statistics
  async getPermissionStats() {
    const { data: permissions, error } = await supabase
      .from('permissions')
      .select('resource, action, role_id');

    if (error) throw error;

    const stats = {
      totalPermissions: permissions.length,
      uniqueResources: [...new Set(permissions.map(p => p.resource))].length,
      uniqueActions: [...new Set(permissions.map(p => p.action))].length,
      permissionsByResource: permissions.reduce((acc, p) => {
        acc[p.resource] = (acc[p.resource] || 0) + 1;
        return acc;
      }, {} as Record<string, number>),
      permissionsByAction: permissions.reduce((acc, p) => {
        acc[p.action] = (acc[p.action] || 0) + 1;
        return acc;
      }, {} as Record<string, number>)
    };

    return stats;
  },

  // Validate permission structure
  validatePermission(resource: string, action: string): boolean {
    const validResources = [
      'companies', 'contacts', 'leads', 'deals', 'employees', 'departments',
      'designations', 'attendance', 'leave_requests', 'payroll', 'documents',
      'tasks', 'calendar_events', 'automations', 'integrations', 'user_roles',
      'permissions', 'reports', 'settings'
    ];

    const validActions = ['create', 'read', 'update', 'delete', 'manage'];

    return validResources.includes(resource) && validActions.includes(action);
  },

  // Log activity
  async logActivity(action: string, entityType: string, entityId: string, details?: any) {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    await supabase
      .from('activity_logs')
      .insert({
        action,
        entity_type: entityType,
        entity_id: entityId,
        user_id: user.id,
        details
      });
  }
};