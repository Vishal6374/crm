import { supabase } from "@/integrations/supabase/client";
import type { Database } from "@/integrations/supabase/types";

type ActivityLog = Database['public']['Tables']['activity_logs']['Row'];
type ActivityLogInsert = Database['public']['Tables']['activity_logs']['Insert'];

export const activitiesService = {
  // Get all activities with optional filtering
  async getActivities(filters?: {
    user_id?: string;
    entity_type?: string;
    action?: string;
    start_date?: string;
    end_date?: string;
    limit?: number;
  }) {
    let query = supabase
      .from('activity_logs')
      .select(`
        *,
        user:profiles (
          id,
          full_name,
          email,
          avatar_url
        )
      `)
      .order('created_at', { ascending: false });

    if (filters?.user_id) {
      query = query.eq('user_id', filters.user_id);
    }

    if (filters?.entity_type) {
      query = query.eq('entity_type', filters.entity_type);
    }

    if (filters?.action) {
      query = query.eq('action', filters.action);
    }

    if (filters?.start_date) {
      query = query.gte('created_at', filters.start_date);
    }

    if (filters?.end_date) {
      query = query.lte('created_at', filters.end_date);
    }

    if (filters?.limit) {
      query = query.limit(filters.limit);
    } else {
      query = query.limit(100); // Default limit
    }

    const { data, error } = await query;
    if (error) throw error;
    return data;
  },

  // Get activities for current user
  async getMyActivities(limit: number = 50) {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) throw new Error('Not authenticated');

    const { data, error } = await supabase
      .from('activity_logs')
      .select(`
        *,
        user:profiles (
          id,
          full_name,
          email,
          avatar_url
        )
      `)
      .eq('user_id', user.id)
      .order('created_at', { ascending: false })
      .limit(limit);

    if (error) throw error;
    return data;
  },

  // Get activities by entity
  async getActivitiesByEntity(entityType: string, entityId: string) {
    const { data, error } = await supabase
      .from('activity_logs')
      .select(`
        *,
        user:profiles (
          id,
          full_name,
          email,
          avatar_url
        )
      `)
      .eq('entity_type', entityType)
      .eq('entity_id', entityId)
      .order('created_at', { ascending: false });

    if (error) throw error;
    return data;
  },

  // Log activity
  async logActivity(action: string, entityType: string, entityId: string, details?: any) {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) throw new Error('Not authenticated');

    const { data, error } = await supabase
      .from('activity_logs')
      .insert({
        action,
        entity_type: entityType,
        entity_id: entityId,
        user_id: user.id,
        details
      })
      .select()
      .single();

    if (error) throw error;
    return data;
  },

  // Get activity statistics
  async getActivityStats(userId?: string, days: number = 30) {
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - days);

    let query = supabase
      .from('activity_logs')
      .select('action, entity_type, created_at')
      .gte('created_at', startDate.toISOString());

    if (userId) {
      query = query.eq('user_id', userId);
    }

    const { data, error } = await query;
    if (error) throw error;

    const stats = {
      total: data.length,
      byAction: data.reduce((acc, log) => {
        acc[log.action] = (acc[log.action] || 0) + 1;
        return acc;
      }, {} as Record<string, number>),
      byEntityType: data.reduce((acc, log) => {
        acc[log.entity_type] = (acc[log.entity_type] || 0) + 1;
        return acc;
      }, {} as Record<string, number>),
      dailyActivity: data.reduce((acc, log) => {
        const date = new Date(log.created_at).toISOString().split('T')[0];
        acc[date] = (acc[date] || 0) + 1;
        return acc;
      }, {} as Record<string, number>)
    };

    return stats;
  },

  // Get recent activities for dashboard
  async getRecentActivities(limit: number = 10) {
    const { data, error } = await supabase
      .from('activity_logs')
      .select(`
        *,
        user:profiles (
          id,
          full_name,
          email,
          avatar_url
        )
      `)
      .order('created_at', { ascending: false })
      .limit(limit);

    if (error) throw error;
    return data;
  },

  // Delete old activities (cleanup)
  async deleteOldActivities(daysOld: number = 365) {
    const cutoffDate = new Date();
    cutoffDate.setDate(cutoffDate.getDate() - daysOld);

    const { data, error } = await supabase
      .from('activity_logs')
      .delete()
      .lt('created_at', cutoffDate.toISOString());

    if (error) throw error;
    return data;
  }
};
