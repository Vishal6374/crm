-- Seed data for testing the dashboard features

-- Insert profiles (user profiles for authentication)
INSERT INTO public.profiles (id, email, full_name, avatar_url) VALUES
('550e8400-e29b-41d4-a716-446655440001', 'john.smith@company.com', 'John Smith', NULL),
('550e8400-e29b-41d4-a716-446655440002', 'sarah.johnson@company.com', 'Sarah Johnson', NULL),
('550e8400-e29b-41d4-a716-446655440003', 'mike.davis@company.com', 'Mike Davis', NULL),
('550e8400-e29b-41d4-a716-446655440004', 'emily.chen@company.com', 'Emily Chen', NULL),
('550e8400-e29b-41d4-a716-446655440005', 'david.wilson@company.com', 'David Wilson', NULL),
('550e8400-e29b-41d4-a716-446655440006', 'lisa.brown@company.com', 'Lisa Brown', NULL),
('550e8400-e29b-41d4-a716-446655440007', 'tom.anderson@company.com', 'Tom Anderson', NULL),
('550e8400-e29b-41d4-a716-446655440008', 'anna.garcia@company.com', 'Anna Garcia', NULL);

-- Insert user roles
INSERT INTO public.user_roles (user_id, role) VALUES
('550e8400-e29b-41d4-a716-446655440001', 'super_admin'),
('550e8400-e29b-41d4-a716-446655440002', 'admin'),
('550e8400-e29b-41d4-a716-446655440003', 'sales_manager'),
('550e8400-e29b-41d4-a716-446655440004', 'sales_executive'),
('550e8400-e29b-41d4-a716-446655440005', 'employee'),
('550e8400-e29b-41d4-a716-446655440006', 'employee'),
('550e8400-e29b-41d4-a716-446655440007', 'sales_executive'),
('550e8400-e29b-41d4-a716-446655440008', 'employee');

-- Insert departments
INSERT INTO public.departments (name, description) VALUES
('Engineering', 'Software development and engineering'),
('Sales', 'Sales and business development'),
('Marketing', 'Marketing and customer acquisition'),
('HR', 'Human resources and administration'),
('Finance', 'Financial operations and accounting');

-- Insert employees (we'll need to create auth users first, but for now we'll use NULL user_id)
INSERT INTO public.employees (employee_code, full_name, email, phone, department_id, designation, joining_date, salary, status) VALUES
('EMP001', 'John Smith', 'john.smith@company.com', '+91-9876543210', (SELECT id FROM departments WHERE name = 'Engineering'), 'Senior Developer', '2023-01-15', 85000, 'active'),
('EMP002', 'Sarah Johnson', 'sarah.johnson@company.com', '+91-9876543211', (SELECT id FROM departments WHERE name = 'Sales'), 'Sales Manager', '2023-02-01', 75000, 'active'),
('EMP003', 'Mike Davis', 'mike.davis@company.com', '+91-9876543212', (SELECT id FROM departments WHERE name = 'Engineering'), 'Full Stack Developer', '2023-03-10', 70000, 'active'),
('EMP004', 'Emily Chen', 'emily.chen@company.com', '+91-9876543213', (SELECT id FROM departments WHERE name = 'Marketing'), 'Marketing Specialist', '2023-04-05', 55000, 'active'),
('EMP005', 'David Wilson', 'david.wilson@company.com', '+91-9876543214', (SELECT id FROM departments WHERE name = 'HR'), 'HR Manager', '2023-01-20', 65000, 'active'),
('EMP006', 'Lisa Brown', 'lisa.brown@company.com', '+91-9876543215', (SELECT id FROM departments WHERE name = 'Finance'), 'Accountant', '2023-05-12', 60000, 'active'),
('EMP007', 'Tom Anderson', 'tom.anderson@company.com', '+91-9876543216', (SELECT id FROM departments WHERE name = 'Sales'), 'Sales Executive', '2023-06-01', 50000, 'active'),
('EMP008', 'Anna Garcia', 'anna.garcia@company.com', '+91-9876543217', (SELECT id FROM departments WHERE name = 'Engineering'), 'DevOps Engineer', '2023-07-15', 80000, 'active');

-- Insert companies
INSERT INTO public.companies (name, industry, website, phone, email, address, city, country, notes) VALUES
('TechCorp Solutions', 'Technology', 'https://techcorp.com', '+91-9876543201', 'contact@techcorp.com', '123 Tech Street', 'Mumbai', 'India', 'Leading software solutions provider'),
('Global Industries', 'Manufacturing', 'https://globalind.com', '+91-9876543202', 'sales@globalind.com', '456 Industrial Road', 'Delhi', 'India', 'Manufacturing and distribution'),
('Innovate Labs', 'Healthcare', 'https://innovatelabs.com', '+91-9876543203', 'info@innovatelabs.com', '789 Health Avenue', 'Bangalore', 'India', 'Medical technology company'),
('DataFlow Systems', 'Technology', 'https://dataflow.com', '+91-9876543204', 'support@dataflow.com', '321 Data Lane', 'Chennai', 'India', 'Data analytics and AI solutions'),
('Green Energy Corp', 'Energy', 'https://greenenergy.com', '+91-9876543205', 'contact@greenenergy.com', '654 Green Street', 'Pune', 'India', 'Renewable energy solutions');

-- Insert contacts
INSERT INTO public.contacts (company_id, first_name, last_name, email, phone, position, notes) VALUES
((SELECT id FROM companies WHERE name = 'TechCorp Solutions'), 'Rajesh', 'Kumar', 'rajesh.kumar@techcorp.com', '+91-9876543218', 'CTO', 'Technical decision maker'),
((SELECT id FROM companies WHERE name = 'TechCorp Solutions'), 'Priya', 'Sharma', 'priya.sharma@techcorp.com', '+91-9876543219', 'CEO', 'Company founder'),
((SELECT id FROM companies WHERE name = 'Global Industries'), 'Amit', 'Patel', 'amit.patel@globalind.com', '+91-9876543220', 'Procurement Manager', 'Handles vendor relationships'),
((SELECT id FROM companies WHERE name = 'Innovate Labs'), 'Dr. Sunita', 'Verma', 'sunita.verma@innovatelabs.com', '+91-9876543221', 'Medical Director', 'Healthcare expert'),
((SELECT id FROM companies WHERE name = 'DataFlow Systems'), 'Vikram', 'Singh', 'vikram.singh@dataflow.com', '+91-9876543222', 'VP Engineering', 'Technical lead'),
((SELECT id FROM companies WHERE name = 'Green Energy Corp'), 'Meera', 'Nair', 'meera.nair@greenenergy.com', '+91-9876543223', 'Operations Director', 'Project management focus');

-- Insert leads (spread across different months for the chart)
INSERT INTO public.leads (company_name, contact_name, email, phone, source, status, notes, created_at) VALUES
('TechCorp Solutions', 'Rajesh Kumar', 'rajesh.kumar@techcorp.com', '+91-9876543218', 'Website', 'lost', 'High-value enterprise client', '2024-12-01 10:00:00+00'),
('Global Industries', 'Amit Patel', 'amit.patel@globalind.com', '+91-9876543220', 'LinkedIn', 'contacted', 'Manufacturing automation project', '2024-12-02 14:30:00+00'),
('Innovate Labs', 'Dr. Sunita Verma', 'sunita.verma@innovatelabs.com', '+91-9876543221', 'Referral', 'new', 'Healthcare software implementation', '2024-12-03 09:15:00+00'),
('DataFlow Systems', 'Vikram Singh', 'vikram.singh@dataflow.com', '+91-9876543222', 'Trade Show', 'lost', 'Big data analytics platform', '2024-12-04 16:45:00+00'),
('Green Energy Corp', 'Meera Nair', 'meera.nair@greenenergy.com', '+91-9876543223', 'Cold Call', 'lost', 'Solar panel monitoring system', '2024-12-05 11:20:00+00'),
('StartupXYZ', 'Alex Johnson', 'alex@startupxyz.com', '+91-9876543224', 'Website', 'new', 'SaaS startup looking for CRM', '2024-12-06 13:10:00+00'),
('MegaCorp', 'Jennifer Lee', 'jennifer@megacorp.com', '+91-9876543225', 'Email Campaign', 'contacted', 'Enterprise digital transformation', '2024-12-07 15:30:00+00'),
('TechStart Inc', 'Mark Thompson', 'mark@techstart.com', '+91-9876543226', 'LinkedIn', 'lost', 'Mobile app development project', '2024-12-08 10:45:00+00'),
('FinanceHub', 'Rachel Green', 'rachel@financehub.com', '+91-9876543227', 'Referral', 'new', 'Financial software integration', '2024-12-09 12:00:00+00'),
('LogisticsPro', 'Steve Rogers', 'steve@logisticspro.com', '+91-9876543228', 'Trade Show', 'contacted', 'Supply chain optimization', '2024-12-10 14:20:00+00'),
('HealthTech Solutions', 'Dr. Bruce Banner', 'bruce@healthtech.com', '+91-9876543229', 'Website', 'lost', 'Medical records system', '2024-12-11 09:30:00+00'),
('EduLearn Platform', 'Diana Prince', 'diana@edulearn.com', '+91-9876543230', 'Cold Call', 'lost', 'E-learning platform development', '2024-12-12 16:15:00+00'),
('RetailMax', 'Tony Stark', 'tony@retailmax.com', '+91-9876543231', 'Email Campaign', 'new', 'E-commerce platform upgrade', '2024-12-13 11:45:00+00'),
('CloudServices Inc', 'Natasha Romanoff', 'natasha@cloudservices.com', '+91-9876543232', 'LinkedIn', 'contacted', 'Cloud migration project', '2024-12-14 13:20:00+00'),
('AutoTech Motors', 'Clint Barton', 'clint@autotech.com', '+91-9876543233', 'Referral', 'lost', 'IoT automotive solutions', '2024-12-15 15:10:00+00'),
-- November leads
('BuildCorp', 'Wanda Maximoff', 'wanda@buildcorp.com', '+91-9876543234', 'Website', 'new', 'Construction management software', '2024-11-01 10:00:00+00'),
('FoodieApp', 'Sam Wilson', 'sam@foodieapp.com', '+91-9876543235', 'Trade Show', 'contacted', 'Food delivery platform', '2024-11-05 14:30:00+00'),
('TravelBook', 'Bucky Barnes', 'bucky@travelbook.com', '+91-9876543236', 'LinkedIn', 'lost', 'Travel booking system', '2024-11-10 09:15:00+00'),
('FitLife Gym', 'Carol Danvers', 'carol@fitlife.com', '+91-9876543237', 'Referral', 'lost', 'Fitness tracking app', '2024-11-15 16:45:00+00'),
('MusicStream', 'Peter Parker', 'peter@musicstream.com', '+91-9876543238', 'Cold Call', 'new', 'Music streaming platform', '2024-11-20 11:20:00+00'),
-- October leads
('GameDev Studio', 'Scott Lang', 'scott@gamedev.com', '+91-9876543239', 'Website', 'contacted', 'Mobile game development', '2024-10-01 13:10:00+00'),
('AgriTech Solutions', 'Hope van Dyne', 'hope@agritech.com', '+91-9876543240', 'Email Campaign', 'lost', 'Agricultural IoT platform', '2024-10-10 15:30:00+00'),
('RealEstate Pro', 'Stephen Strange', 'stephen@realestatepro.com', '+91-9876543241', 'LinkedIn', 'new', 'Property management system', '2024-10-15 10:45:00+00'),
('CryptoWallet', 'Thor Odinson', 'thor@cryptowallet.com', '+91-9876543242', 'Trade Show', 'contacted', 'Cryptocurrency wallet app', '2024-10-20 12:00:00+00'),
('VideoCall Pro', 'Loki Laufeyson', 'loki@videocall.com', '+91-9876543243', 'Referral', 'lost', 'Video conferencing platform', '2024-10-25 14:20:00+00');

-- Insert deals with different stages and values
INSERT INTO public.deals (title, company_id, contact_id, value, stage, expected_close_date, notes, created_at) VALUES
('Enterprise CRM Implementation', (SELECT id FROM companies WHERE name = 'TechCorp Solutions'), (SELECT id FROM contacts WHERE email = 'rajesh.kumar@techcorp.com'), 250000, 'won', '2024-12-15', 'Successfully closed enterprise deal', '2024-11-01 10:00:00+00'),
('Manufacturing Automation', (SELECT id FROM companies WHERE name = 'Global Industries'), (SELECT id FROM contacts WHERE email = 'amit.patel@globalind.com'), 180000, 'proposal', '2024-12-20', 'High-value manufacturing project', '2024-11-05 14:30:00+00'),
('Healthcare Software Platform', (SELECT id FROM companies WHERE name = 'Innovate Labs'), (SELECT id FROM contacts WHERE email = 'sunita.verma@innovatelabs.com'), 320000, 'negotiation', '2024-12-25', 'Medical technology implementation', '2024-11-10 09:15:00+00'),
('Data Analytics Platform', (SELECT id FROM companies WHERE name = 'DataFlow Systems'), (SELECT id FROM contacts WHERE email = 'vikram.singh@dataflow.com'), 150000, 'proposal', '2024-12-30', 'Big data analytics solution', '2024-11-15 16:45:00+00'),
('Solar Monitoring System', (SELECT id FROM companies WHERE name = 'Green Energy Corp'), (SELECT id FROM contacts WHERE email = 'meera.nair@greenenergy.com'), 95000, 'lead', '2025-01-15', 'Renewable energy monitoring', '2024-11-20 11:20:00+00'),
('SaaS CRM Integration', (SELECT c.id FROM companies c WHERE c.name = 'StartupXYZ'), NULL, 75000, 'proposal', '2024-12-18', 'Startup CRM implementation', '2024-11-25 13:10:00+00'),
('Digital Transformation', (SELECT c.id FROM companies c WHERE c.name = 'MegaCorp'), NULL, 500000, 'negotiation', '2025-01-10', 'Large enterprise transformation', '2024-11-30 15:30:00+00'),
('Mobile App Development', (SELECT c.id FROM companies c WHERE c.name = 'TechStart Inc'), NULL, 120000, 'proposal', '2024-12-22', 'Cross-platform mobile app', '2024-12-01 10:45:00+00'),
('Financial Software Integration', (SELECT c.id FROM companies c WHERE c.name = 'FinanceHub'), NULL, 85000, 'lead', '2025-01-05', 'Banking software integration', '2024-12-02 12:00:00+00'),
('Supply Chain Optimization', (SELECT c.id FROM companies c WHERE c.name = 'LogisticsPro'), NULL, 200000, 'won', '2024-12-10', 'Logistics optimization platform', '2024-11-20 14:20:00+00'),
('Medical Records System', (SELECT c.id FROM companies c WHERE c.name = 'HealthTech Solutions'), NULL, 175000, 'proposal', '2024-12-28', 'Electronic health records', '2024-12-03 09:30:00+00'),
('E-commerce Platform', (SELECT c.id FROM companies c WHERE c.name = 'RetailMax'), NULL, 135000, 'proposal', '2025-01-08', 'E-commerce solution upgrade', '2024-12-04 11:45:00+00'),
('Cloud Migration Project', (SELECT c.id FROM companies c WHERE c.name = 'CloudServices Inc'), NULL, 280000, 'negotiation', '2025-01-20', 'Full cloud infrastructure migration', '2024-12-05 13:20:00+00'),
('IoT Automotive Solutions', (SELECT c.id FROM companies c WHERE c.name = 'AutoTech Motors'), NULL, 160000, 'lead', '2025-02-01', 'Connected vehicle platform', '2024-12-06 15:10:00+00'),
('Construction Management', (SELECT c.id FROM companies c WHERE c.name = 'BuildCorp'), NULL, 110000, 'won', '2024-12-08', 'Construction project management', '2024-11-15 10:00:00+00'),
('Food Delivery Platform', (SELECT c.id FROM companies c WHERE c.name = 'FoodieApp'), NULL, 90000, 'proposal', '2024-12-24', 'Restaurant delivery system', '2024-12-07 14:30:00+00');

-- Insert tasks (some due today, some pending)
INSERT INTO public.tasks (title, description, status, due_date, priority, assigned_to, created_at) VALUES
('Follow up with TechCorp Solutions', 'Call Rajesh Kumar to discuss CRM requirements', 'pending', CURRENT_DATE, 'high', NULL, '2024-12-10 09:00:00+00'),
('Prepare proposal for Global Industries', 'Create detailed automation proposal', 'in_progress', CURRENT_DATE + INTERVAL '2 days', 'high', NULL, '2024-12-09 14:00:00+00'),
('Demo healthcare platform', 'Schedule and conduct demo for Innovate Labs', 'pending', CURRENT_DATE + INTERVAL '1 day', 'medium', NULL, '2024-12-08 11:00:00+00'),
('Data analytics requirements gathering', 'Meet with DataFlow Systems team', 'completed', CURRENT_DATE - INTERVAL '1 day', 'medium', NULL, '2024-12-05 10:00:00+00'),
('Solar monitoring system design', 'Create technical design document', 'pending', CURRENT_DATE + INTERVAL '3 days', 'low', NULL, '2024-12-07 16:00:00+00'),
('Client onboarding documentation', 'Prepare onboarding materials for new clients', 'pending', CURRENT_DATE, 'high', NULL, '2024-12-10 08:00:00+00'),
('Competitor analysis report', 'Research and analyze competitor offerings', 'in_progress', CURRENT_DATE + INTERVAL '5 days', 'medium', NULL, '2024-12-06 13:00:00+00'),
('Team meeting preparation', 'Prepare agenda for weekly team meeting', 'pending', CURRENT_DATE, 'medium', NULL, '2024-12-10 12:00:00+00');

-- Insert attendance data for this week (Monday to Friday)
-- Get employee IDs for attendance
INSERT INTO public.attendance (employee_id, date, status) VALUES
((SELECT id FROM employees WHERE employee_code = 'EMP001'), CURRENT_DATE - INTERVAL '4 days', 'present'), -- Monday
((SELECT id FROM employees WHERE employee_code = 'EMP001'), CURRENT_DATE - INTERVAL '3 days', 'present'), -- Tuesday
((SELECT id FROM employees WHERE employee_code = 'EMP001'), CURRENT_DATE - INTERVAL '2 days', 'present'), -- Wednesday
((SELECT id FROM employees WHERE employee_code = 'EMP001'), CURRENT_DATE - INTERVAL '1 day', 'late'), -- Thursday
((SELECT id FROM employees WHERE employee_code = 'EMP001'), CURRENT_DATE, 'present'), -- Friday

((SELECT id FROM employees WHERE employee_code = 'EMP002'), CURRENT_DATE - INTERVAL '4 days', 'present'),
((SELECT id FROM employees WHERE employee_code = 'EMP002'), CURRENT_DATE - INTERVAL '3 days', 'present'),
((SELECT id FROM employees WHERE employee_code = 'EMP002'), CURRENT_DATE - INTERVAL '2 days', 'absent'),
((SELECT id FROM employees WHERE employee_code = 'EMP002'), CURRENT_DATE - INTERVAL '1 day', 'present'),
((SELECT id FROM employees WHERE employee_code = 'EMP002'), CURRENT_DATE, 'present'),

((SELECT id FROM employees WHERE employee_code = 'EMP003'), CURRENT_DATE - INTERVAL '4 days', 'present'),
((SELECT id FROM employees WHERE employee_code = 'EMP003'), CURRENT_DATE - INTERVAL '3 days', 'present'),
((SELECT id FROM employees WHERE employee_code = 'EMP003'), CURRENT_DATE - INTERVAL '2 days', 'present'),
((SELECT id FROM employees WHERE employee_code = 'EMP003'), CURRENT_DATE - INTERVAL '1 day', 'present'),
((SELECT id FROM employees WHERE employee_code = 'EMP003'), CURRENT_DATE, 'present'),

((SELECT id FROM employees WHERE employee_code = 'EMP004'), CURRENT_DATE - INTERVAL '4 days', 'present'),
((SELECT id FROM employees WHERE employee_code = 'EMP004'), CURRENT_DATE - INTERVAL '3 days', 'absent'),
((SELECT id FROM employees WHERE employee_code = 'EMP004'), CURRENT_DATE - INTERVAL '2 days', 'present'),
((SELECT id FROM employees WHERE employee_code = 'EMP004'), CURRENT_DATE - INTERVAL '1 day', 'present'),
((SELECT id FROM employees WHERE employee_code = 'EMP004'), CURRENT_DATE, 'present'),

((SELECT id FROM employees WHERE employee_code = 'EMP005'), CURRENT_DATE - INTERVAL '4 days', 'present'),
((SELECT id FROM employees WHERE employee_code = 'EMP005'), CURRENT_DATE - INTERVAL '3 days', 'present'),
((SELECT id FROM employees WHERE employee_code = 'EMP005'), CURRENT_DATE - INTERVAL '2 days', 'present'),
((SELECT id FROM employees WHERE employee_code = 'EMP005'), CURRENT_DATE - INTERVAL '1 day', 'present'),
((SELECT id FROM employees WHERE employee_code = 'EMP005'), CURRENT_DATE, 'present'),

((SELECT id FROM employees WHERE employee_code = 'EMP006'), CURRENT_DATE - INTERVAL '4 days', 'present'),
((SELECT id FROM employees WHERE employee_code = 'EMP006'), CURRENT_DATE - INTERVAL '3 days', 'present'),
((SELECT id FROM employees WHERE employee_code = 'EMP006'), CURRENT_DATE - INTERVAL '2 days', 'present'),
((SELECT id FROM employees WHERE employee_code = 'EMP006'), CURRENT_DATE - INTERVAL '1 day', 'present'),
((SELECT id FROM employees WHERE employee_code = 'EMP006'), CURRENT_DATE, 'absent'),

((SELECT id FROM employees WHERE employee_code = 'EMP007'), CURRENT_DATE - INTERVAL '4 days', 'present'),
((SELECT id FROM employees WHERE employee_code = 'EMP007'), CURRENT_DATE - INTERVAL '3 days', 'present'),
((SELECT id FROM employees WHERE employee_code = 'EMP007'), CURRENT_DATE - INTERVAL '2 days', 'present'),
((SELECT id FROM employees WHERE employee_code = 'EMP007'), CURRENT_DATE - INTERVAL '1 day', 'late'),
((SELECT id FROM employees WHERE employee_code = 'EMP007'), CURRENT_DATE, 'present'),

((SELECT id FROM employees WHERE employee_code = 'EMP008'), CURRENT_DATE - INTERVAL '4 days', 'present'),
((SELECT id FROM employees WHERE employee_code = 'EMP008'), CURRENT_DATE - INTERVAL '3 days', 'present'),
((SELECT id FROM employees WHERE employee_code = 'EMP008'), CURRENT_DATE - INTERVAL '2 days', 'present'),
((SELECT id FROM employees WHERE employee_code = 'EMP008'), CURRENT_DATE - INTERVAL '1 day', 'present'),
((SELECT id FROM employees WHERE employee_code = 'EMP008'), CURRENT_DATE, 'present');

-- Insert leave requests (some pending)
INSERT INTO public.leave_requests (employee_id, leave_type, start_date, end_date, reason, status) VALUES
((SELECT id FROM employees WHERE employee_code = 'EMP001'), 'annual', CURRENT_DATE + INTERVAL '10 days', CURRENT_DATE + INTERVAL '15 days', 'Family vacation', 'pending'),
((SELECT id FROM employees WHERE employee_code = 'EMP003'), 'sick', CURRENT_DATE + INTERVAL '5 days', CURRENT_DATE + INTERVAL '6 days', 'Medical appointment', 'pending'),
((SELECT id FROM employees WHERE employee_code = 'EMP004'), 'personal', CURRENT_DATE + INTERVAL '20 days', CURRENT_DATE + INTERVAL '22 days', 'Personal matters', 'approved'),
((SELECT id FROM employees WHERE employee_code = 'EMP007'), 'annual', CURRENT_DATE - INTERVAL '5 days', CURRENT_DATE - INTERVAL '2 days', 'Previous vacation', 'approved');

-- Insert payroll data for current month
INSERT INTO public.payroll (employee_id, month, year, basic_salary, deductions, bonus, net_salary, status) VALUES
((SELECT id FROM employees WHERE employee_code = 'EMP001'), EXTRACT(MONTH FROM CURRENT_DATE), EXTRACT(YEAR FROM CURRENT_DATE), 85000, 5000, 10000, 90000, 'paid'),
((SELECT id FROM employees WHERE employee_code = 'EMP002'), EXTRACT(MONTH FROM CURRENT_DATE), EXTRACT(YEAR FROM CURRENT_DATE), 75000, 4000, 8000, 79000, 'paid'),
((SELECT id FROM employees WHERE employee_code = 'EMP003'), EXTRACT(MONTH FROM CURRENT_DATE), EXTRACT(YEAR FROM CURRENT_DATE), 70000, 3500, 7000, 73500, 'pending'),
((SELECT id FROM employees WHERE employee_code = 'EMP004'), EXTRACT(MONTH FROM CURRENT_DATE), EXTRACT(YEAR FROM CURRENT_DATE), 55000, 2500, 5000, 57500, 'pending'),
((SELECT id FROM employees WHERE employee_code = 'EMP005'), EXTRACT(MONTH FROM CURRENT_DATE), EXTRACT(YEAR FROM CURRENT_DATE), 65000, 3000, 6000, 68000, 'paid'),
((SELECT id FROM employees WHERE employee_code = 'EMP006'), EXTRACT(MONTH FROM CURRENT_DATE), EXTRACT(YEAR FROM CURRENT_DATE), 60000, 2800, 5500, 62700, 'pending'),
((SELECT id FROM employees WHERE employee_code = 'EMP007'), EXTRACT(MONTH FROM CURRENT_DATE), EXTRACT(YEAR FROM CURRENT_DATE), 50000, 2000, 4000, 52000, 'paid'),
((SELECT id FROM employees WHERE employee_code = 'EMP008'), EXTRACT(MONTH FROM CURRENT_DATE), EXTRACT(YEAR FROM CURRENT_DATE), 80000, 4500, 9000, 84500, 'pending');

-- Insert designations
INSERT INTO public.designations (name, description, department_id, level, base_salary_min, base_salary_max) VALUES
('Senior Developer', 'Senior software developer with 5+ years experience', (SELECT id FROM departments WHERE name = 'Engineering'), 'senior', 80000, 120000),
('Full Stack Developer', 'Full stack developer with frontend and backend skills', (SELECT id FROM departments WHERE name = 'Engineering'), 'mid', 60000, 90000),
('Sales Manager', 'Manager responsible for sales team and targets', (SELECT id FROM departments WHERE name = 'Sales'), 'manager', 70000, 100000),
('Sales Executive', 'Sales representative handling client relationships', (SELECT id FROM departments WHERE name = 'Sales'), 'mid', 40000, 70000),
('Marketing Specialist', 'Digital marketing and campaign management', (SELECT id FROM departments WHERE name = 'Marketing'), 'mid', 45000, 65000),
('HR Manager', 'Human resources management and administration', (SELECT id FROM departments WHERE name = 'HR'), 'manager', 55000, 80000),
('Accountant', 'Financial accounting and reporting', (SELECT id FROM departments WHERE name = 'Finance'), 'mid', 50000, 70000),
('DevOps Engineer', 'Infrastructure and deployment management', (SELECT id FROM departments WHERE name = 'Engineering'), 'senior', 75000, 110000);

-- Insert permissions
INSERT INTO public.permissions (name, description, resource, action) VALUES
('companies.read', 'View companies', 'companies', 'read'),
('companies.write', 'Create and edit companies', 'companies', 'write'),
('companies.delete', 'Delete companies', 'companies', 'delete'),
('contacts.read', 'View contacts', 'contacts', 'read'),
('contacts.write', 'Create and edit contacts', 'contacts', 'write'),
('leads.read', 'View leads', 'leads', 'read'),
('leads.write', 'Create and edit leads', 'leads', 'write'),
('deals.read', 'View deals', 'deals', 'read'),
('deals.write', 'Create and edit deals', 'deals', 'write'),
('employees.read', 'View employees', 'employees', 'read'),
('employees.write', 'Create and edit employees', 'employees', 'write'),
('attendance.read', 'View attendance records', 'attendance', 'read'),
('attendance.write', 'Manage attendance records', 'attendance', 'write'),
('payroll.read', 'View payroll information', 'payroll', 'read'),
('payroll.write', 'Manage payroll', 'payroll', 'write'),
('tasks.read', 'View tasks', 'tasks', 'read'),
('tasks.write', 'Create and edit tasks', 'tasks', 'write'),
('reports.read', 'View reports', 'reports', 'read'),
('users.admin', 'Manage users and roles', 'users', 'admin'),
('settings.admin', 'Manage system settings', 'settings', 'admin');

-- Insert role permissions
INSERT INTO public.role_permissions (role, permission_id) VALUES
('super_admin', (SELECT id FROM permissions WHERE name = 'users.admin')),
('super_admin', (SELECT id FROM permissions WHERE name = 'settings.admin')),
('admin', (SELECT id FROM permissions WHERE name = 'companies.read')),
('admin', (SELECT id FROM permissions WHERE name = 'companies.write')),
('admin', (SELECT id FROM permissions WHERE name = 'employees.read')),
('admin', (SELECT id FROM permissions WHERE name = 'employees.write')),
('admin', (SELECT id FROM permissions WHERE name = 'payroll.read')),
('admin', (SELECT id FROM permissions WHERE name = 'payroll.write')),
('sales_manager', (SELECT id FROM permissions WHERE name = 'companies.read')),
('sales_manager', (SELECT id FROM permissions WHERE name = 'companies.write')),
('sales_manager', (SELECT id FROM permissions WHERE name = 'contacts.read')),
('sales_manager', (SELECT id FROM permissions WHERE name = 'contacts.write')),
('sales_manager', (SELECT id FROM permissions WHERE name = 'leads.read')),
('sales_manager', (SELECT id FROM permissions WHERE name = 'leads.write')),
('sales_manager', (SELECT id FROM permissions WHERE name = 'deals.read')),
('sales_manager', (SELECT id FROM permissions WHERE name = 'deals.write')),
('sales_executive', (SELECT id FROM permissions WHERE name = 'companies.read')),
('sales_executive', (SELECT id FROM permissions WHERE name = 'contacts.read')),
('sales_executive', (SELECT id FROM permissions WHERE name = 'leads.read')),
('sales_executive', (SELECT id FROM permissions WHERE name = 'leads.write')),
('sales_executive', (SELECT id FROM permissions WHERE name = 'deals.read')),
('employee', (SELECT id FROM permissions WHERE name = 'companies.read')),
('employee', (SELECT id FROM permissions WHERE name = 'contacts.read')),
('employee', (SELECT id FROM permissions WHERE name = 'tasks.read')),
('employee', (SELECT id FROM permissions WHERE name = 'tasks.write'));

-- Insert sample automations
INSERT INTO public.automations (name, description, trigger_type, trigger_config, actions, is_active) VALUES
('Daily Lead Follow-up', 'Send follow-up emails to leads not contacted in 3 days', 'schedule', '{"schedule": "daily at 9:00 AM"}', '[{"type": "email", "template": "follow_up", "recipients": "leads"}]', true),
('Deal Stage Notifications', 'Notify sales team when deals move to negotiation stage', 'event', '{"event": "deal_stage_changed", "stage": "negotiation"}', '[{"type": "notification", "recipients": "sales_team"}]', true),
('Monthly Report Generation', 'Generate and email monthly sales reports', 'schedule', '{"schedule": "monthly on 1st at 8:00 AM"}', '[{"type": "generate_report", "report_type": "sales"}, {"type": "email", "recipients": "managers"}]', true);

-- Insert sample integrations
INSERT INTO public.integrations (name, type, provider, status, config) VALUES
('Gmail Integration', 'email', 'Google', 'active', '{"client_id": "sample", "scopes": ["email", "calendar"]}'),
('Outlook Calendar', 'calendar', 'Microsoft', 'inactive', '{"client_id": "sample", "scopes": ["calendar.readwrite"]}'),
('Slack Notifications', 'communication', 'Slack', 'active', '{"webhook_url": "https://hooks.slack.com/sample"}'),
('Google Drive', 'storage', 'Google', 'inactive', '{"client_id": "sample", "scopes": ["drive.file"]}');

-- Insert sample calendar events
INSERT INTO public.calendar_events (title, description, start_time, end_time, event_type, priority, attendees) VALUES
('Team Standup', 'Daily team standup meeting', '2024-12-30 09:00:00+00', '2024-12-30 09:30:00+00', 'meeting', 'high', '["550e8400-e29b-41d4-a716-446655440001", "550e8400-e29b-41d4-a716-446655440002"]'),
('Client Presentation', 'Present Q4 results to TechCorp Solutions', '2024-12-30 14:00:00+00', '2024-12-30 15:30:00+00', 'meeting', 'high', '["550e8400-e29b-41d4-a716-446655440003", "550e8400-e29b-41d4-a716-446655440004"]'),
('Project Review', 'Review automation project progress', '2024-12-31 10:00:00+00', '2024-12-31 11:00:00+00', 'meeting', 'medium', '["550e8400-e29b-41d4-a716-446655440001", "550e8400-e29b-41d4-a716-446655440005"]'),
('Training Session', 'New employee onboarding training', '2025-01-02 13:00:00+00', '2025-01-02 16:00:00+00', 'meeting', 'medium', '["550e8400-e29b-41d4-a716-446655440006", "550e8400-e29b-41d4-a716-446655440008"]');
