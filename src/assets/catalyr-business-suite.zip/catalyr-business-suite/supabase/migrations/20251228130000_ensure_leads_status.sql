-- Ensure leads table has 'status' column (idempotent)
BEGIN;

-- Add 'status' column if missing
ALTER TABLE IF EXISTS public.leads
  ADD COLUMN IF NOT EXISTS status public.lead_status NOT NULL DEFAULT 'new';

COMMIT;
