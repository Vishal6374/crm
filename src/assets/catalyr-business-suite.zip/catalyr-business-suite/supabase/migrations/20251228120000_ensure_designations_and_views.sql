-- Ensure designations table exists and provide helper view for employee-user mapping

BEGIN;

-- Create designations if not exists
CREATE TABLE IF NOT EXISTS public.designations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL UNIQUE,
  description TEXT,
  department_id UUID REFERENCES public.departments(id) ON DELETE SET NULL,
  level TEXT DEFAULT 'entry' CHECK (level IN ('entry','mid','senior','lead','manager','director','executive')),
  base_salary_min DECIMAL(12,2) DEFAULT 0,
  base_salary_max DECIMAL(12,2) DEFAULT 0,
  created_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Create a convenience view that exposes employees joined with their auth.user id
-- This helps queries that want employee info by auth user id
CREATE OR REPLACE VIEW public.employee_profiles AS
SELECT
  e.id,
  e.user_id,
  e.employee_code,
  e.full_name,
  e.email,
  e.phone,
  e.department_id,
  e.designation,
  e.joining_date,
  e.salary,
  e.status,
  e.created_at,
  e.updated_at
FROM public.employees e;

COMMIT;
