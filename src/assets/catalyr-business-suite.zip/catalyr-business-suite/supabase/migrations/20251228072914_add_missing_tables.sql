-- Add missing tables for complete CRM/ERP functionality

-- Create document_type enum
CREATE TYPE public.document_type AS ENUM ('resume', 'contract', 'certificate', 'id_proof', 'other');

-- Create permission_type enum
CREATE TYPE public.permission_type AS ENUM ('read', 'write', 'delete', 'admin');

-- Create automation_trigger_type enum
CREATE TYPE public.automation_trigger_type AS ENUM ('schedule', 'event', 'condition');

-- Create integration_type enum
CREATE TYPE public.integration_type AS ENUM ('email', 'calendar', 'communication', 'storage', 'automation', 'webhook');

-- Create integration_status enum
CREATE TYPE public.integration_status AS ENUM ('active', 'inactive', 'error');

-- Designations table (job titles/roles)
CREATE TABLE public.designations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL UNIQUE,
  description TEXT,
  department_id UUID REFERENCES public.departments(id) ON DELETE SET NULL,
  level TEXT DEFAULT 'entry' CHECK (level IN ('entry', 'mid', 'senior', 'lead', 'manager', 'director', 'executive')),
  base_salary_min DECIMAL(12,2) DEFAULT 0,
  base_salary_max DECIMAL(12,2) DEFAULT 0,
  created_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Documents table (employee documents)
CREATE TABLE public.documents (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  employee_id UUID REFERENCES public.employees(id) ON DELETE CASCADE NOT NULL,
  name TEXT NOT NULL,
  type document_type NOT NULL DEFAULT 'other',
  file_url TEXT NOT NULL,
  file_size INTEGER,
  mime_type TEXT,
  expiry_date DATE,
  is_verified BOOLEAN DEFAULT false,
  verified_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  verified_at TIMESTAMPTZ,
  notes TEXT,
  created_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Permissions table (granular permissions system)
CREATE TABLE public.permissions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL UNIQUE,
  description TEXT,
  resource TEXT NOT NULL, -- e.g., 'companies', 'employees', 'leads'
  action permission_type NOT NULL,
  created_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Role permissions junction table
CREATE TABLE public.role_permissions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  role app_role NOT NULL,
  permission_id UUID REFERENCES public.permissions(id) ON DELETE CASCADE NOT NULL,
  created_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (role, permission_id)
);

-- Automations table (workflow automation)
CREATE TABLE public.automations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  description TEXT,
  trigger_type automation_trigger_type NOT NULL,
  trigger_config JSONB NOT NULL DEFAULT '{}',
  actions JSONB NOT NULL DEFAULT '[]',
  conditions JSONB DEFAULT '[]',
  is_active BOOLEAN DEFAULT true,
  last_run TIMESTAMPTZ,
  next_run TIMESTAMPTZ,
  created_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Integrations table (third-party integrations)
CREATE TABLE public.integrations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  type integration_type NOT NULL,
  provider TEXT NOT NULL,
  status integration_status NOT NULL DEFAULT 'inactive',
  config JSONB NOT NULL DEFAULT '{}',
  api_key TEXT,
  webhook_url TEXT,
  last_sync TIMESTAMPTZ,
  error_message TEXT,
  created_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Calendar events table
CREATE TABLE public.calendar_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title TEXT NOT NULL,
  description TEXT,
  start_time TIMESTAMPTZ NOT NULL,
  end_time TIMESTAMPTZ NOT NULL,
  all_day BOOLEAN DEFAULT false,
  location TEXT,
  event_type TEXT DEFAULT 'meeting' CHECK (event_type IN ('meeting', 'task', 'reminder', 'personal', 'holiday')),
  priority TEXT DEFAULT 'medium' CHECK (priority IN ('low', 'medium', 'high')),
  status TEXT DEFAULT 'scheduled' CHECK (status IN ('scheduled', 'confirmed', 'cancelled', 'completed')),
  attendees JSONB DEFAULT '[]', -- Array of user IDs
  related_lead_id UUID REFERENCES public.leads(id) ON DELETE SET NULL,
  related_deal_id UUID REFERENCES public.deals(id) ON DELETE SET NULL,
  related_contact_id UUID REFERENCES public.contacts(id) ON DELETE SET NULL,
  related_task_id UUID REFERENCES public.tasks(id) ON DELETE SET NULL,
  created_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Enable RLS on new tables
ALTER TABLE public.designations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.documents ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.permissions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.role_permissions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.automations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.integrations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.calendar_events ENABLE ROW LEVEL SECURITY;

-- Add updated_at triggers to new tables
CREATE TRIGGER update_designations_updated_at BEFORE UPDATE ON public.designations FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_documents_updated_at BEFORE UPDATE ON public.documents FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_permissions_updated_at BEFORE UPDATE ON public.permissions FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_automations_updated_at BEFORE UPDATE ON public.automations FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_integrations_updated_at BEFORE UPDATE ON public.integrations FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_calendar_events_updated_at BEFORE UPDATE ON public.calendar_events FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- RLS Policies for Designations
CREATE POLICY "Admins can manage designations" ON public.designations
  FOR ALL USING (public.is_admin(auth.uid()));

CREATE POLICY "Employees can view designations" ON public.designations
  FOR SELECT USING (auth.uid() IS NOT NULL);

-- RLS Policies for Documents
CREATE POLICY "Users can view their own documents" ON public.documents
  FOR SELECT USING (
    employee_id IN (
      SELECT id FROM public.employees WHERE user_id = auth.uid()
    ) OR
    public.is_admin(auth.uid())
  );

CREATE POLICY "Admins can manage all documents" ON public.documents
  FOR ALL USING (public.is_admin(auth.uid()));

CREATE POLICY "HR can manage documents" ON public.documents
  FOR ALL USING (public.has_role(auth.uid(), 'admin'));

-- RLS Policies for Permissions
CREATE POLICY "Admins can manage permissions" ON public.permissions
  FOR ALL USING (public.is_admin(auth.uid()));

CREATE POLICY "Users can view permissions" ON public.permissions
  FOR SELECT USING (auth.uid() IS NOT NULL);

-- RLS Policies for Role Permissions
CREATE POLICY "Admins can manage role permissions" ON public.role_permissions
  FOR ALL USING (public.is_admin(auth.uid()));

CREATE POLICY "Users can view role permissions" ON public.role_permissions
  FOR SELECT USING (auth.uid() IS NOT NULL);

-- RLS Policies for Automations
CREATE POLICY "Admins can manage automations" ON public.automations
  FOR ALL USING (public.is_admin(auth.uid()));

CREATE POLICY "Users can view active automations" ON public.automations
  FOR SELECT USING (auth.uid() IS NOT NULL);

-- RLS Policies for Integrations
CREATE POLICY "Admins can manage integrations" ON public.integrations
  FOR ALL USING (public.is_admin(auth.uid()));

CREATE POLICY "Users can view integrations" ON public.integrations
  FOR SELECT USING (auth.uid() IS NOT NULL);

-- RLS Policies for Calendar Events
CREATE POLICY "Users can view calendar events" ON public.calendar_events
  FOR SELECT USING (auth.uid() IS NOT NULL);

CREATE POLICY "Users can manage their own events" ON public.calendar_events
  FOR ALL USING (
    created_by = auth.uid() OR
    public.is_admin(auth.uid()) OR
    attendees ? auth.uid()::text
  );

-- Bypass policies for seeding (development only)
CREATE POLICY "Allow seeding designations" ON public.designations FOR ALL USING (auth.uid() IS NULL);
CREATE POLICY "Allow seeding documents" ON public.documents FOR ALL USING (auth.uid() IS NULL);
CREATE POLICY "Allow seeding permissions" ON public.permissions FOR ALL USING (auth.uid() IS NULL);
CREATE POLICY "Allow seeding role_permissions" ON public.role_permissions FOR ALL USING (auth.uid() IS NULL);
CREATE POLICY "Allow seeding automations" ON public.automations FOR ALL USING (auth.uid() IS NULL);
CREATE POLICY "Allow seeding integrations" ON public.integrations FOR ALL USING (auth.uid() IS NULL);
CREATE POLICY "Allow seeding calendar_events" ON public.calendar_events FOR ALL USING (auth.uid() IS NULL);