-- Add policies to allow seeding operations during development
-- These policies allow operations when no user is authenticated (for seeding)

-- Bypass policies for departments
CREATE POLICY "Allow seeding departments" ON public.departments
  FOR ALL USING (auth.uid() IS NULL);

-- Bypass policies for employees
CREATE POLICY "Allow seeding employees" ON public.employees
  FOR ALL USING (auth.uid() IS NULL);

-- Bypass policies for companies
CREATE POLICY "Allow seeding companies" ON public.companies
  FOR ALL USING (auth.uid() IS NULL);

-- Bypass policies for contacts
CREATE POLICY "Allow seeding contacts" ON public.contacts
  FOR ALL USING (auth.uid() IS NULL);

-- Bypass policies for leads
CREATE POLICY "Allow seeding leads" ON public.leads
  FOR ALL USING (auth.uid() IS NULL);

-- Bypass policies for deals
CREATE POLICY "Allow seeding deals" ON public.deals
  FOR ALL USING (auth.uid() IS NULL);

-- Bypass policies for tasks
CREATE POLICY "Allow seeding tasks" ON public.tasks
  FOR ALL USING (auth.uid() IS NULL);

-- Bypass policies for attendance
CREATE POLICY "Allow seeding attendance" ON public.attendance
  FOR ALL USING (auth.uid() IS NULL);

-- Bypass policies for leave_requests
CREATE POLICY "Allow seeding leave_requests" ON public.leave_requests
  FOR ALL USING (auth.uid() IS NULL);

-- Bypass policies for payroll
CREATE POLICY "Allow seeding payroll" ON public.payroll
  FOR ALL USING (auth.uid() IS NULL);

-- Bypass policies for profiles
CREATE POLICY "Allow seeding profiles" ON public.profiles
  FOR ALL USING (auth.uid() IS NULL);

-- Bypass policies for user_roles
CREATE POLICY "Allow seeding user_roles" ON public.user_roles
  FOR ALL USING (auth.uid() IS NULL);

-- Bypass policies for activity_logs
CREATE POLICY "Allow seeding activity_logs" ON public.activity_logs
  FOR ALL USING (auth.uid() IS NULL);
