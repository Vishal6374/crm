-- Add missing fields to companies table for enhanced CRM functionality

-- Add company size field
ALTER TABLE public.companies ADD COLUMN company_size TEXT CHECK (company_size IN ('1-10', '11-50', '51-200', '200+'));

-- Add status field for company lifecycle
ALTER TABLE public.companies ADD COLUMN status TEXT NOT NULL DEFAULT 'prospect' CHECK (status IN ('active', 'prospect', 'inactive'));

-- Add assigned_to field for ownership
ALTER TABLE public.companies ADD COLUMN assigned_to UUID REFERENCES auth.users(id) ON DELETE SET NULL;

-- Add source field for lead source tracking
ALTER TABLE public.companies ADD COLUMN source TEXT;

-- Add logo_url field for company branding
ALTER TABLE public.companies ADD COLUMN logo_url TEXT;

-- Add tags field as JSONB for flexible tagging
ALTER TABLE public.companies ADD COLUMN tags JSONB DEFAULT '[]'::jsonb;

-- Update RLS policies to include new fields
-- The existing policies should work, but let's ensure assigned users can update their companies
DROP POLICY IF EXISTS "Admins and sales managers can update companies" ON public.companies;
CREATE POLICY "Admins and sales can update companies" ON public.companies FOR UPDATE USING (
  public.is_admin(auth.uid()) OR
  public.has_role(auth.uid(), 'sales_manager') OR
  public.has_role(auth.uid(), 'sales_executive') OR
  assigned_to = auth.uid() OR
  created_by = auth.uid()
);
